=== NexPilot ===
Contributors: nexdev
Requires at least: 6.6.5
Tested up to: 7.1.4
Requires PHP: 8.1
Stable tag: 1.3.12
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Independent AI connections, human-approved changes and temporary full maintenance.

== Stable 1.3.10 ==
Connection cards explain expired credentials and owner-only permission editing. Full access descriptions accurately state which changes require individual approval.

== Stable 1.3.9 ==
WooCommerce product edits now keep a stable approval revision when related products are reordered.

== Stable 1.1.1 ==
Connection package access correction. Supported runtime and client scope remain documented; native Claude execution is not newly certified by this release. Existing installed desktop bundles must be updated separately.

== Stable 1.1.0 ==
Editorial update: draft copies, draft-only connections, discoverable preview/propose/execute, SEO metadata, offline admin batch review, local PDF text/OCR interface. Qualified for the documented single-site Codex scope. OCR needs host binaries; Yoast/Rank Math integration needs site-specific QA.

== Stable 1.0.3 ==
1.0.3: signed public updates without GitHub credentials. Qualified for the documented single-site Codex scope.
Validate this update in staging before deployment.
Not an independent audit or WordPress.org directory edition. Validate each site
in staging. Full maintenance is unrestricted access. No personal credentials ship.

== Installation ==
Install on an authorized staging instance or controlled pilot.
Tools > NexPilot > Create connection.
Create a separate credential for each AI client. Read-only is the default.

== Data retention ==
Deactivation does not delete credentials, audit records or encrypted proposals.
An administrator can opt into connector-data removal on uninstall. Default is retention.
Opt-in removal deletes connector records and audit, revokes tracked temporary sessions,
and retains site content, uploads and user sandbox files. Multisite cleanup is not implemented.

== Privacy and external services ==
No model provider is contacted automatically by this plugin. Authorized MCP clients
can retrieve site data within their granted scopes and send it to the model provider
chosen in that client. Review the provider's terms and privacy policy before connecting.
Use synthetic data for testing. With approvals mode requires a separate approval per change; owner-selected Full access grants standing authorization for its selected duration.
Account access is opt-in. Account reads return limited profile fields and WooCommerce order counts. The order list adds the customer ID and billing names only when account reading is granted. The dedicated account deletion permission requires an exact proposal and approval by the connection owner for each target, even with Full access.

Optional external audit delivery is disabled unless an administrator configures
NSC_AUDIT_URL and NSC_AUDIT_KEY. It sends the site URL, timestamp, connection identifier,
event type and reference identifier to that configured HTTPS receiver. No fixed
Nexdev telemetry destination is included. Agree a retention policy for that receiver.

== Distribution and updates ==
This full edition includes administrator-approved arbitrary code and file maintenance.
It is not eligible for submission under the current WordPress.org new-plugin FAQ.
Signed public updates are enabled by default from https://nexdev-team.github.io/NexPilot-updates/.
No GitHub account or key is required. WordPress checks the signed release metadata
and verifies the downloaded ZIP before installation. To install automatically,
enable auto-updates for NexPilot in WordPress; otherwise use Update now.
Version 1.0.2 installations need a one-time manual ZIP upgrade unless their legacy
private updater is already configured. Personal AI connections remain site-local.
The optional NSC_UPDATE_CHANNEL=private server setting retains legacy private delivery.

== Changelog ==
= 1.3.12 =
- Corrected AI session instructions and bulk operation discovery to honor owner-authorized unattended maintenance.
- Approved proposal responses now explicitly identify change_execute as the next action and report that no further WordPress approval is required.

= 1.3.11 =
- Added an owner-selected option to include unrestricted maintenance in per-connection Full access for the chosen duration.
- PHP, SQL, file and WP-CLI operations use the active owner grant when enabled. Credential rotation resets this authorization.

= 1.3.10 =
- Clarified expired connection renewal, owner-only permission editing and Full access approval exceptions.

= 1.3.8 =
- Added pagination, field selection, sorting and filters across account, commerce, content and auxiliary collections, including WPForms Pro and supported WooCommerce extensions.
- Added bulk dry runs with exact target hashes, owner-configurable limits, scoped approvals, progress tracking and resumable jobs with per-item outcomes.
- Added bulk account, product, order, post, media and coupon operations, CSV updates for existing products and approved field-level reverts for supported changes.
- Added approved bulk updates for eligible inactive plugins, with verified archives and encrypted file snapshots for rollback.
- Added targeted and grouped WordPress content object-cache invalidation.

= 1.3.7 =
- Added WooCommerce order filters and optional customer details for connections with account read access. Orders omit customer details by default.
- Improved product search and detail lookup, account filters, and inventory of available plugin and theme updates.
- Added a separate permission to disclose full account email addresses. Email addresses are masked by default.
- Added dry-run previews for up to 20 account deletions. Each actual deletion still requires owner approval.
- Expanded inspection and editing for supported editorial content types and Flatsome UX Blocks, and added SEOPress metadata support.
- Improved capability discovery, proposal summaries, and error messages.
- Added PHP syntax checks for maintenance uploads and edits, protected sensitive files and options on direct reads, and required separate owner approval for unrestricted PHP, SQL, and WP-CLI operations even in Full access mode.

= 1.3.6 =
- Προστέθηκε δημόσια σελίδα συντήρησης ανεξάρτητη από το theme, με χειροκίνητο διακόπτη και χωριστό δικαίωμα ανά σύνδεση.
- Οι προτάσεις ενεργοποίησης ή απενεργοποίησης μέσω NexPilot απαιτούν ρητή έγκριση του ιδιοκτήτη. Το WordPress admin και το REST API παραμένουν διαθέσιμα.

= 1.3.5 =
- Προστέθηκε το προαιρετικό δικαίωμα Site inspection για τη λίστα προσθέτων, τα Flatsome UX Blocks και την ανάγνωση αρχείων πηγαίου κώδικα themes και plugins.
- Η επιθεώρηση είναι μόνο για ανάγνωση και ενεργοποιείται χωριστά ανά σύνδεση.

= 1.3.4 =
- Προστέθηκαν χωριστά δικαιώματα για ανάγνωση πελατών WooCommerce και χρηστών WordPress και για προτάσεις διαγραφής λογαριασμών.
- Κάθε διαγραφή απαιτεί ρητή έγκριση του ιδιοκτήτη της σύνδεσης, ακόμη και με Full access. Οι λογαριασμοί διαχειριστών προστατεύονται.

= 1.3.3 =
- Ενιαία φόρμα δικαιωμάτων και τρόπου έγκρισης ανά σύνδεση, με επιβεβαίωση αποθήκευσης ή συγκεκριμένο σφάλμα.
- Οι αλλαγές διατηρούν το υπάρχον κλειδί και τη λήξη του. Οι ασύμβατες επιλογές απορρίπτονται πριν αλλάξουν τα αποθηκευμένα δικαιώματα.

= 1.3.2 =
- Προστέθηκε το σήμα της Nexdev για τις ενημερώσεις του NexPilot στον πίνακα διαχείρισης του WordPress.

= 1.3.1 =
- Αφαιρέθηκε η παλιά ένδειξη έκδοσης από την ειδοποίηση του NexPilot. Η τρέχουσα έκδοση εμφανίζεται στην κεφαλίδα.

= 1.3.0 =
Προσχέδια blog με εικόνες WebP και ξεχωριστή επιλογή αυτόματης δημοσίευσης από τον ιδιοκτήτη της σύνδεσης. Το υπάρχον κλειδί διατηρείται. Η δημοσίευση είναι αρχικά απενεργοποιημένη.


= 1.2.2 — 31/10/2026 =
- Διορθώθηκε η απόδοση ελληνικών λέξεων στο ιστορικό αλλαγών και στις οδηγίες εγκατάστασης.
- Το κείμενο διαβάζεται ως UTF-8, χωρίς να κόβονται γράμματα στη μέση.
- Δεν αλλάζουν τα δικαιώματα, οι συνδέσεις ή ο τρόπος εγκρίσεων.

= 1.2.1 — 31/10/2026 =
- Το «View version details» εμφανίζει πληροφορίες έκδοσης και καρτέλα Changelog.
- Οι σημειώσεις προέρχονται από το υπογεγραμμένο ZIP της νεότερης έκδοσης, ώστε να διαβάζονται πριν το update.
- Προστέθηκε ευανάγνωστο ιστορικό αλλαγών στα ελληνικά.
- Δεν αλλάζουν οι συνδέσεις, τα δικαιώματα ή οι επιλογές εγκρίσεων.

= 1.2.0 — 31/10/2026 =
- Δύο επιλογές ανά σύνδεση: With approvals ή Full access χωρίς ξεχωριστό approve ανά αλλαγή.
- Διάρκεια Full access: 10 λεπτά, 1 ώρα, 8 ώρες ή μέχρι τη λήξη της σύνδεσης.
- Οι υπάρχουσες συνδέσεις παραμένουν με εγκρίσεις μέχρι να επιλέξει διαφορετικά ο ιδιοκτήτης τους.
- Διατηρούνται οι έλεγχοι δικαιωμάτων, τα αρχεία δραστηριότητας, οι έλεγχοι σύγκρουσης και η ακύρωση πρόσβασης μετά τη λήξη ή ανάκληση.

= 1.1.1 — 31/10/2026 =
- Τα πακέτα σύνδεσης ακολουθούν τα δικαιώματα που επιλέγεις, εκτός αν ορίσεις περιορισμό στη συσκευή.
- Το πακέτο Claude εμφανίζει επιλογή Read-only access on this device στις ρυθμίσεις του.
- Τα διαγνωστικά ξεχωρίζουν τον περιορισμό της συσκευής από τα δικαιώματα του WordPress.
- Τα ήδη εγκατεστημένα πακέτα σύνδεσης ενημερώνονται ξεχωριστά από το WordPress plugin.

= 1.1.0 — 31/10/2026 =
- Αντίγραφα πρόχειρων σελίδων, συνδέσεις Draft-only και αλλαγές τίτλου, περιεχομένου, slug και ταξινομιών.
- Λειτουργίες SEO metadata και ομαδικός έλεγχος προτάσεων από τον διαχειριστή.
- Τοπική ανάγνωση PDF/OCR όταν ο server διαθέτει τα απαιτούμενα εργαλεία.

= 1.0.3 =
Public signed metadata and ZIP delivery; no recipient GitHub credentials; independent public-channel trust key; daily metadata renewal.

= 1.0.2 =
Browser sign-in guide for Codex; encrypted site-local private GitHub update setup, visible status and signed download verification without installation.

= 1.0.1 =
Unified administration into setup, connections, proposals, activity and advanced settings tabs.
Connection creation is part of setup step 4. Activity uses a readable table.
Existing credentials, scopes, approvals, OAuth and data retention are preserved.

= 1.0.0 =
First private Stable: scoped security/runtime qualification, signed private updates, privacy controls and clean installation/upgrade/rollback verification. Earlier entries below describe historical versions.

= 0.2.0 =
Private local stable package for the bounded Codex desktop scope. Includes rc.3 authorization hardening, independently reviewed derivative-capability binding and verified recovery. Claude validation and distribution remain deferred.

= 0.2.0-rc.3 =
Prepared SQL identifiers and WPForms predicates; WordPress script enqueueing; validated input and static errors; bounded OAuth rate storage; queued WP-CLI authorization binding. Private candidate, not stable.
= 0.2.0-rc.2 =
NexPilot branding by Nexdev. REST target-binding fix, stateless anonymous OAuth
registration, local security and desktop regression testing. Not a stable release.

= 0.2.0-beta.1 =
Expanded beta: native resource operations, editor validation, conditional integrations,
one-use transfers and admin access, async jobs, recovery and concurrent-client tests.
