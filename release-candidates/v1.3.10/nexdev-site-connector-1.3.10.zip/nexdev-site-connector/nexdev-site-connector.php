<?php
/**
 * Plugin Name: NexPilot
 * Description: Independent AI connections, reviewable changes and time-limited maintenance access. Private edition; site-specific staging validation required.
 * Version: 1.3.10
 * Update URI: https://github.com/nexdev-team/NexPilot
 * Requires at least: 6.6.5
 * Requires PHP: 8.1
 * Author: Nexdev
 * License: GPL-2.0-or-later
 */
namespace Nexdev\SiteConnector;
if (!defined('ABSPATH')) { exit; }
define('NSC_VERSION', '1.3.10');
require_once __DIR__ . '/includes/Errors.php';
require_once __DIR__ . '/includes/Policy.php';
require_once __DIR__ . '/includes/Store.php';
require_once __DIR__ . '/includes/Maintenance.php';
Maintenance::register_site_page();
require_once __DIR__ . '/includes/Resources.php';
require_once __DIR__ . '/includes/Integrations.php';
require_once __DIR__ . '/includes/Design.php';
require_once __DIR__ . '/includes/Library.php';
require_once __DIR__ . '/includes/Files.php';
require_once __DIR__ . '/includes/Blocks.php';
require_once __DIR__ . '/includes/Transfers.php';
require_once __DIR__ . '/includes/Jobs.php';
require_once __DIR__ . '/includes/PluginBatch.php';
require_once __DIR__ . '/includes/CacheBatch.php';
require_once __DIR__ . '/includes/BulkChanges.php';
require_once __DIR__ . '/includes/Bulk.php';
require_once __DIR__ . '/includes/Access.php';
require_once __DIR__ . '/includes/Media.php';
require_once __DIR__ . '/includes/Recovery.php';
require_once __DIR__ . '/includes/Editorial.php';
require_once __DIR__ . '/includes/MediaText.php';
require_once __DIR__ . '/includes/Blog.php';
require_once __DIR__ . '/includes/Tools.php';
require_once __DIR__ . '/includes/OAuth.php';
require_once __DIR__ . '/includes/Server.php';
require_once __DIR__ . '/includes/Diagnostics.php';
require_once __DIR__ . '/includes/Setup.php';
require_once __DIR__ . '/includes/ProposalReview.php';
require_once __DIR__ . '/includes/Updater.php';
require_once __DIR__ . '/includes/Admin.php';
Updater::register();
add_action(\Nexdev\SiteConnector\Bulk::HOOK, [\Nexdev\SiteConnector\Bulk::class, 'tick']);
register_activation_hook(__FILE__, [Store::class, 'install']);
register_deactivation_hook(__FILE__, [Access::class, 'deactivate']);
register_deactivation_hook(__FILE__, [Maintenance::class, 'clear_site_page']);
add_action('rest_api_init', [Server::class, 'register']);
add_action('rest_api_init', [Diagnostics::class, 'register_routes']);
add_action('admin_enqueue_scripts', [Admin::class, 'enqueue']);
add_action('admin_menu', [Admin::class, 'menu']);
add_action('admin_post_nsc_action', [Admin::class, 'action']);

add_action('plugins_loaded', [Files::class, 'load_sandbox'], 20);

add_action('rest_api_init', [Transfers::class, 'register']);

add_action('admin_post_nsc_exchange', [Access::class, 'exchange']);
add_action('admin_post_nopriv_nsc_exchange', [Access::class, 'exchange']);

add_filter('determine_current_user', [Access::class, 'validate_session'], 99);

add_action('plugins_loaded', static function(){if((int)get_option('nsc_schema_version',0)<2)Store::install();}, 1);

add_action('admin_enqueue_scripts', [Blocks::class, 'enqueue']);
add_action('wp_ajax_nsc_editor_heartbeat', [Blocks::class, 'heartbeat']);

add_action('rest_api_init', [OAuth::class, 'register_routes']);
add_action('parse_request', [OAuth::class, 'discovery'], 0);
add_action('admin_post_nsc_oauth_authorize', [OAuth::class, 'authorize']);
add_action('admin_post_nopriv_nsc_oauth_authorize', [OAuth::class, 'authorize']);
add_filter('rest_post_dispatch', [OAuth::class, 'challenge'], 10, 3);

add_filter('wp_robots', [Editorial::class, 'robots']);
add_action('wp_head', [Editorial::class, 'head']);
add_action('admin_notices', [Admin::class, 'notices']);
add_filter('wpseo_metadesc', [Editorial::class, 'plugin_description']);
add_filter('rank_math/frontend/description', [Editorial::class, 'plugin_description']);
add_filter('wpseo_robots_array', [Editorial::class, 'plugin_robots']);
add_filter('rank_math/frontend/robots', [Editorial::class, 'plugin_robots']);
