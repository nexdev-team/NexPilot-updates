<?php
namespace Nexdev\SiteConnector;
if (!defined('ABSPATH')) { exit; }
/**
 * Guided setup panel shown at the top of Tools > NexPilot.
 * It never creates credentials and never prints a token: it only explains the steps and builds
 * connection snippets in the browser from public values (the endpoint) and placeholders.
 */
final class Setup {
 public static function enqueue(): void {
  wp_enqueue_style('nsc-setup', plugins_url('../assets/setup.css', __FILE__), [], NSC_VERSION);
  wp_enqueue_script('nsc-bundles', plugins_url('../assets/connection-bundles.js', __FILE__), [], NSC_VERSION, true);
  wp_enqueue_script('nsc-setup', plugins_url('../assets/setup.js', __FILE__), ['nsc-bundles'], NSC_VERSION, true);
  $host = (string) wp_parse_url(home_url(), PHP_URL_HOST);
  $data = [
   'endpoint' => rest_url('nexdev-connector/v1/mcp'),
   'version' => NSC_VERSION,
   'installerUrl' => plugins_url('../bridge/install-codex.mjs', __FILE__),
   'privacyUrl' => get_privacy_policy_url(),
   'allowLocalHttp' => wp_get_environment_type()==='local' && defined('NSC_ALLOW_LOCAL_HTTP') && NSC_ALLOW_LOCAL_HTTP,
   'bridgeUrl' => plugins_url('../bridge/nexdev-mcp.mjs', __FILE__),
   'siteSlug' => trim((string) preg_replace('/[^a-z0-9]+/', '-', strtolower($host)), '-'),
   'oauth' => OAuth::enabled(),
   'oauthSettingsUrl' => admin_url('tools.php?page=nsc&tab=settings'),
   'https' => wp_parse_url(rest_url('nexdev-connector/v1/mcp'), PHP_URL_SCHEME) === 'https',
   'disabled' => (bool) get_option('nsc_disabled', false),
   'accepted' => Policy::accepted(),
  ];
  wp_add_inline_script('nsc-setup', 'window.nscSetup=' . wp_json_encode($data) . ';', 'before');
 }
 public static function render(): void {
  $disabled = (bool) get_option('nsc_disabled', false);
  $accepted = Policy::accepted();
  $info = get_option('nsc_risk_accepted', []);
  echo '<div id="nsc-setup" class="nsc-setup' . ($accepted ? '' : ' nsc-locked') . '">';
  echo '<h2 class="nsc-setup-title">Set up your AI connection</h2>';

  echo '<section class="nsc-step"><h3><span class="nsc-num">1</span>Accept the agreement and turn on NexPilot</h3>';
  echo '<p class="nsc-note"><strong>Security note:</strong> an AI connected to this site can read your data and, when you approve it, change it. Use a staging site first, keep backups, and give each AI the lowest access that works. Start with <em>Read</em>. Full maintenance (PHP, SQL, files, WP-CLI) is unrestricted and is meant for short, supervised sessions only.</p>';
  if (!$accepted) {
   echo '<div class="nsc-agreement"><p><strong>Use at your own risk.</strong> NexPilot is free software released under the GPL, provided <em>as is</em>, without warranty of any kind. By turning it on you confirm that:</p><ol>';
   foreach ([
    'You are responsible for everything the AI tools you connect read, change or delete on this site, including every change you approve.',
    'The authors and Nexdev are not liable for data loss, downtime, security incidents, financial loss or any other damage arising from the use of this plugin, to the maximum extent permitted by law.',
    'You will use a staging site or keep verified backups, and you will read each proposed change before you approve it.',
    'Data that an AI tool reads from this site may be sent to that tool’s provider. You are responsible for complying with privacy and data-protection laws (for example the GDPR) for your customers’ personal data.',
    'Full maintenance gives unrestricted access to your site and server. You will open it only briefly, and only for AI tools you trust.',
   ] as $line) { echo '<li>' . esc_html($line) . '</li>'; }
   echo '</ol><form method="post" action="' . esc_url(admin_url('admin-post.php')) . '">';
   wp_nonce_field('nsc_action');
   echo '<input type="hidden" name="action" value="nsc_action"><input type="hidden" name="operation" value="accept_risk">';
   echo '<label><input type="checkbox" name="accept_risk_confirm" value="1" required> I have read and accept this agreement and I use NexPilot at my own risk.</label> ';
   submit_button('Accept and turn on NexPilot', 'primary', 'submit', false);
   echo '</form></div>';
  } else {
   $when = isset($info['time']) ? gmdate('Y-m-d H:i', (int) $info['time']) . ' UTC' : '';
   echo '<p>Agreement accepted by user #' . esc_html((string) ($info['user'] ?? '?')) . ' on ' . esc_html($when) . '.</p>';
   Admin::form('withdraw_risk', '', 'Withdraw acceptance (blocks all connections)');
  }
  echo '<p>Status: <strong>' . esc_html($disabled ? 'Disabled (all connections are blocked)' : 'Enabled') . '</strong></p>';
  Admin::form($disabled ? 'enable' : 'disable', '', $disabled ? 'Enable connector' : 'Disable all connections');
  echo '<p id="nsc-https-warning" class="nsc-warn" hidden>This site is not using HTTPS. The bridge and most AI apps refuse plain HTTP. Use HTTPS (or a local test site with the local-development override).</p>';
  echo '</section>';

  echo '<section class="nsc-step"><h3><span class="nsc-num">2</span>Choose your AI tool</h3>';
  echo '<input type="search" id="nsc-tool-search" class="regular-text" placeholder="Search your AI tool…" aria-label="Search your AI tool">';
  echo '<div id="nsc-tools" class="nsc-chips" role="group" aria-label="AI tools"></div>';
  echo '<noscript><p class="nsc-warn">JavaScript is needed for this guide. You can still create a connection below and follow docs for your AI tool.</p></noscript>';
  echo '</section>';

  echo '<section class="nsc-step"><h3><span class="nsc-num">3</span>Choose how to connect</h3>';
  echo '<p id="nsc-methods-empty" class="description">Choose your AI tool in step 2 to see its connection methods.</p>';
  echo '<div id="nsc-methods" role="radiogroup" aria-label="Connection method"></div>';
  echo '<div id="nsc-token-create">';Admin::create_connection();
  echo '<div id="nsc-created-key" class="nsc-note" hidden><p>Connection key generated. Copy it once into your AI app when it asks. It stays on this page only until you leave.</p><input id="nsc-created-key-value" type="password" readonly autocomplete="off" aria-label="Generated connection key"><button id="nsc-copy-key" type="button" class="button">Copy connection key</button></div><p id="nsc-create-status" role="status"></p></div>';
  echo '</section>';

  echo '<section class="nsc-step"><h3><span class="nsc-num">4</span>Connect your AI tool</h3>';
  echo '<p id="nsc-guide-empty" class="description">Choose an AI tool and a connection method above to see the setup instructions.</p>';
  echo '<div id="nsc-guide" hidden>';
  echo '<div id="nsc-quick-connect"></div><p><button id="nsc-show-name" type="button" class="button-link">Change server name (optional)</button></p><label class="nsc-check"><input id="nsc-f-readonly" type="checkbox" checked> Use read-only access on this device</label><p id="nsc-device-access" role="status"></p><p class="description">Updating the WordPress plugin does not update an installed desktop bundle. For an existing Claude connection, install the new bundle, check its Read-only access setting, restart the connection and refresh its tools. Keep the same active connection key.</p><details id="nsc-manual-connect"><summary>Manual configuration</summary><div class="nsc-fields"><label>Server name in your AI tool <input id="nsc-f-name" type="text" maxlength="40"></label>';
  echo '<label>Bridge file path <input id="nsc-f-bridge" type="text" placeholder="/absolute/path/to/nexdev-mcp.mjs"></label>';
  echo '<label>Token file path <input id="nsc-f-token" type="text" placeholder="/absolute/path/to/site.token"></label>';
  echo '</div>';
  echo '<ol id="nsc-steps"></ol><div id="nsc-snippets"></div></details>';
  echo '</div>';

  echo '</section>';

  echo '<section class="nsc-step"><h3><span class="nsc-num">5</span>Test and troubleshoot</h3>';
  echo '<p>After connecting, ask your AI: <em>“Use NexPilot to read the site info.”</em> If it does not work:</p>';
  echo '<ul class="nsc-list"><li>Run the connection test below. It checks the storage lock, HTTPS, headers and the authorization header on your host.</li>';
  echo '<li>Check the credential is not expired or revoked in the Connections tab (credentials expire after 30 days).</li>';
  echo '<li>Bridge errors: use Node.js 20+, an absolute path, an HTTPS endpoint, and a token file readable only by you (<code>chmod 600</code>).</li>';
  echo '<li>A 401 or 403 from a host or security plugin: allow the <code>Authorization</code> header and the <code>/wp-json/nexdev-connector/</code> path.</li></ul>';
  Admin::form('connection_test', '', 'Run connection test');
  Admin::form('diagnostics', '', 'Run read-only integration checks');
  echo '</section></div>';
 }
}
