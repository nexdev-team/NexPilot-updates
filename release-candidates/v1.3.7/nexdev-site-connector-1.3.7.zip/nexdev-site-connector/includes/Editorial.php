<?php
namespace Nexdev\SiteConnector;

/** Narrow editorial writes. Arbitrary/private plugin metadata is deliberately excluded. */
final class Editorial {
 public const META = ['_nsc_description','_nsc_noindex','_nsc_schema','_yoast_wpseo_title','_yoast_wpseo_metadesc','_yoast_wpseo_meta-robots-noindex','rank_math_title','rank_math_description','rank_math_robots','_seopress_titles_title','_seopress_titles_desc','_seopress_robots_index'];
 public static function operations(): array {
  return [
   'content_draft'=>['scope'=>'content','arguments'=>['id'=>'integer'],'description'=>'Copy a post/page/block into a new draft; never unpublish the source. Returns draft id.'],
   'post_meta_update'=>['scope'=>'content','arguments'=>['id'=>'integer','fields'=>'object: allowlisted SEO meta keys'],'keys'=>self::META],
   'term_seo_update'=>['scope'=>'content','arguments'=>['taxonomy'=>'category|post_tag','id'=>'integer','fields'=>'object: description, noindex']],
   'robots_type_update'=>['scope'=>'maintenance','arguments'=>['post_type'=>'post|page|wp_block','noindex'=>'boolean']],
  ];
 }
 public static function validate(string $op,array $a): void {
  $keys=match($op){'content_draft'=>['id'],'post_meta_update'=>['id','fields'],'term_seo_update'=>['taxonomy','id','fields'],'robots_type_update'=>['post_type','noindex']};
  Policy::fields($a,$keys,$keys);
  if(isset($a['id']))Policy::id($a['id']);
  if($op==='robots_type_update'){
   if(!in_array($a['post_type'],['post','page','wp_block'],true)||!is_bool($a['noindex']))throw new ValidationError('Invalid post type or noindex boolean.');
  }elseif($op!=='content_draft'){
   if(!is_array($a['fields'])||!$a['fields'])throw new ValidationError('Nonempty fields object required.');
   if($op==='term_seo_update'&&!in_array($a['taxonomy'],['category','post_tag'],true))throw new ValidationError('Invalid taxonomy.');
   Policy::fields($a['fields'],$op==='post_meta_update'?self::META:['description','noindex']);
   foreach($a['fields'] as $k=>$v){
    if(in_array($k,['_nsc_noindex','noindex'],true)){if(!is_bool($v))throw new ValidationError('noindex must be boolean.');}
    elseif($k==='_nsc_schema'){
     if(!is_array($v)||array_is_list($v)||($v['@context']??null)!=='https://schema.org'||!is_string($v['@type']??null))throw new ValidationError('Schema must be a JSON object with https://schema.org context and @type.');
    }elseif($k==='rank_math_robots'){
     if(!is_array($v)||!array_is_list($v)||array_diff($v,['index','noindex','follow','nofollow','noarchive','nosnippet','noimageindex'])||in_array('index',$v,true)&&in_array('noindex',$v,true))throw new ValidationError('Invalid robots directives.');
    }elseif(!is_string($v)||strlen($v)>4096)throw new ValidationError('SEO text must be at most 4096 bytes.');
    if($k==='_yoast_wpseo_meta-robots-noindex'&&!in_array($v,['0','1','2'],true))throw new ValidationError('Yoast noindex must be 0, 1 or 2.');
    if($k==='_seopress_robots_index'&&!in_array($v,['','yes'],true))throw new ValidationError('SEOPress noindex must be yes or an empty string.');
   }
  }
  if(strlen(Policy::canonical($a))>32768)throw new ValidationError('Editorial operation too large.');
 }
 public static function draft_guard(array $client,string $op,array $a): void {
  if($op==='blog_create'){Blog::snapshot($a,$client);return;}
  if(empty($client['draft_only']))return;
  if($op==='content_draft')return;
  if($op==='content_create'){
   if(($a['fields']['status']??'draft')!=='draft')throw new ConnectorError('Draft-only connection cannot publish.');return;
  }
  if(in_array($op,['content_update','post_meta_update','blocks_batch'],true)){
   $ids=$op==='blocks_batch'?array_column($a['targets'],'id'):[$a['id']];
   foreach($ids as $id)if(Tools::content($id,false,$a['type']??null)['status']!=='draft')throw new ConnectorError('Draft-only connection: use content_draft first, then edit the returned draft id.');
   if(isset($a['fields']['status'])&&$a['fields']['status']!=='draft')throw new ConnectorError('Draft-only connection cannot publish.');return;
  }
  throw new ConnectorError('Operation unavailable in draft-only mode. An administrator must change the connection policy for live, taxonomy or maintenance writes.');
 }
 public static function snapshot(string $op,array $a): array {
  if($op==='robots_type_update')$data=['rules'=>get_option('nsc_robots_types',[])];
  elseif($op==='term_seo_update'){
   $term=get_term($a['id'],$a['taxonomy']);if(!$term||is_wp_error($term)||!current_user_can('edit_term',$a['id']))throw new ConnectorError('Term unavailable.');
   $data=['term'=>(array)$term,'description'=>get_term_meta($a['id'],'_nsc_description',true),'noindex'=>get_term_meta($a['id'],'_nsc_noindex',true)];
  }else{
   $data=['content'=>Tools::content($a['id'])];
   $keys=$op==='content_draft'?self::META:array_keys($a['fields']);
   foreach($keys as $key)$data['meta'][$key]=get_post_meta($a['id'],$key,false);
  }
  return $data+['revision'=>Policy::fingerprint($data)];
 }
 public static function apply(string $op,array $a): array {
  self::snapshot($op,$a); // Enforce capabilities again at the write boundary.
  if($op==='content_draft'){
   $p=get_post($a['id']);$id=wp_insert_post(wp_slash(['post_type'=>$p->post_type,'post_status'=>'draft','post_title'=>$p->post_title,'post_content'=>$p->post_content,'post_excerpt'=>$p->post_excerpt,'post_author'=>get_current_user_id()]),true);
   if(is_wp_error($id)||!$id)throw new ConnectorError('Draft creation failed.');
   foreach(self::META as $key)foreach(get_post_meta($a['id'],$key,false) as $value)add_post_meta($id,$key,wp_slash($value));
   foreach(['category','post_tag'] as $tax)if(is_object_in_taxonomy($p->post_type,$tax)){
    $terms=wp_get_object_terms($a['id'],$tax,['fields'=>'ids']);if(is_wp_error($terms)||is_wp_error(wp_set_object_terms($id,$terms,$tax)))throw new ConnectorError('Draft taxonomy copy failed; inspect created drafts.');
   }
   update_post_meta($id,'_nsc_source_id',$a['id']);return Tools::content($id)+['source_id'=>$a['id'],'note'=>'Separate draft; no automatic merge into source. Review and publish manually.'];
  }
  if($op==='post_meta_update'){
   foreach(array_keys($a['fields']) as $key){
    // Honor explicit plugin auth callbacks. The adapter itself grants only this fixed SEO allowlist.
    $subtype=get_post_type($a['id']);
    if((has_filter('auth_post_meta_'.$key)||has_filter('auth_post_meta_'.$key.'_for_'.$subtype))&&!current_user_can('edit_post_meta',$a['id'],$key))throw new ConnectorError('Metadata permission denied.');
   }
   foreach($a['fields'] as $key=>$value){
    $result=update_post_meta($a['id'],$key,wp_slash($value));
    if($result===false&&get_post_meta($a['id'],$key,true)!==(is_bool($value)?($value?'1':''):$value))throw new ConnectorError('Metadata update failed; inspect the resource.');
   }
  }elseif($op==='term_seo_update'){
   foreach($a['fields'] as $key=>$value){$meta='_nsc_'.$key;update_term_meta($a['id'],$meta,wp_slash($value));if(get_term_meta($a['id'],$meta,true)!==(is_bool($value)?($value?'1':''):$value))throw new ConnectorError('Term SEO update failed.');}
  }else{$rules=get_option('nsc_robots_types',[]);$rules[$a['post_type']]=$a['noindex'];update_option('nsc_robots_types',$rules,false);}
  return self::snapshot($op,$a);
 }
 public static function seo_plugin(): bool {return defined('WPSEO_VERSION')||defined('RANK_MATH_VERSION');}
 private static function current_meta(string $key): mixed {
  if(is_singular())return get_post_meta(get_queried_object_id(),$key,true);
  if(is_category()||is_tag())return get_term_meta(get_queried_object_id(),$key,true);
  return '';
 }
 public static function robots(array $robots): array {
  $rules=get_option('nsc_robots_types',[]);
  if(self::current_meta('_nsc_noindex')||(is_singular()&&!empty($rules[get_post_type()]))){unset($robots['index']);$robots['noindex']=true;}
  return $robots;
 }
 public static function plugin_robots(array $robots): array {
  $native=self::robots([]);if(!empty($native['noindex'])){unset($robots['noindex']);$robots['index']='noindex';}return $robots;
 }
 public static function plugin_description(string $description): string {
  $custom=self::current_meta('_nsc_description');return is_string($custom)&&$custom!==''?$custom:$description;
 }
 public static function head(): void {
  if(self::seo_plugin())return;
  $description=self::current_meta('_nsc_description');if(is_string($description)&&$description!=='')echo '<meta name="description" content="'.esc_attr($description).'">'."\n";
  $schema=self::current_meta('_nsc_schema');if(is_array($schema)&&$schema)echo '<script type="application/ld+json">'.wp_json_encode($schema,JSON_HEX_TAG|JSON_HEX_AMP|JSON_HEX_APOS|JSON_HEX_QUOT|JSON_UNESCAPED_UNICODE).'</script>'."\n";
 }
}
