<?php
namespace Nexdev\SiteConnector;
/** Native WordPress/WooCommerce REST controllers own field validation and permissions. */
final class Resources {
 public static function operations(): array {
  return [
   'content_create'=>['content','POST','/wp/v2/{type}',false],
   'content_delete'=>['content','DELETE','/wp/v2/{type}/{id}',true],
   'order_create'=>['commerce','POST','/wc/v3/orders',false],
   'order_update'=>['commerce','PUT','/wc/v3/orders/{id}',true],
   'order_delete'=>['commerce','DELETE','/wc/v3/orders/{id}',true],
   'product_create'=>['commerce','POST','/wc/v3/products',false],
   'product_delete'=>['commerce','DELETE','/wc/v3/products/{id}',true],
   'product_edit'=>['commerce','PUT','/wc/v3/products/{id}',true],
   'variation_create'=>['commerce','POST','/wc/v3/products/{parent}/variations',false],
   'variation_update'=>['commerce','PUT','/wc/v3/products/{parent}/variations/{id}',true],
   'variation_delete'=>['commerce','DELETE','/wc/v3/products/{parent}/variations/{id}',true],
   'coupon_create'=>['commerce','POST','/wc/v3/coupons',false],
   'coupon_update'=>['commerce','PUT','/wc/v3/coupons/{id}',true],
   'coupon_delete'=>['commerce','DELETE','/wc/v3/coupons/{id}',true],
   'refund_create'=>['maintenance','POST','/wc/v3/orders/{parent}/refunds',false],
   'customer_create'=>['maintenance','POST','/wc/v3/customers',false],
   'customer_update'=>['maintenance','PUT','/wc/v3/customers/{id}',true],
   'customer_delete'=>['accounts_delete','DELETE','/wc/v3/customers/{id}',true],
   'term_create'=>['content','POST','/wp/v2/{taxonomy}',false],
   'term_update'=>['content','POST','/wp/v2/{taxonomy}/{id}',true],
   'term_delete'=>['content','DELETE','/wp/v2/{taxonomy}/{id}',true],
   'media_update'=>['content','POST','/wp/v2/media/{id}',true],
   'media_delete'=>['content','DELETE','/wp/v2/media/{id}',true],
   'user_create'=>['maintenance','POST','/wp/v2/users',false],
   'user_update'=>['maintenance','POST','/wp/v2/users/{id}',true],
   'user_delete'=>['accounts_delete','DELETE','/wp/v2/users/{id}',true],
   'settings_update'=>['maintenance','POST','/wp/v2/settings',true],
   'plugin_install'=>['maintenance','POST','/wp/v2/plugins',false],
   'plugin_update'=>['maintenance','POST','/wp/v2/plugins/{plugin}',true],
   'plugin_delete'=>['maintenance','DELETE','/wp/v2/plugins/{plugin}',true],
  ];
 }
 public static function account_deletion(string $op): bool {return in_array($op,['customer_delete','user_delete'],true);}
 private static function deletable_account(string $op,int $id): \WP_User {
  $user=get_user_by('id',$id);
  if(!$user||$id===get_current_user_id()||is_super_admin($id)||user_can($user,'manage_options')||user_can($user,'manage_woocommerce')||user_can($user,'edit_users')||user_can($user,'delete_users'))throw new ConnectorError('Account unavailable or protected from connector deletion.');
  if($op==='customer_delete'&&!in_array('customer',$user->roles,true))throw new ConnectorError('The target is not a WooCommerce customer.');
  return $user;
 }
 public static function validate(string $op,array $a): void {
  $def=self::operations()[$op];$keys=['fields'];preg_match_all('/\{(\w+)\}/',$def[2],$m);$keys=array_merge($keys,$m[1]);
  Policy::fields($a,$keys,$keys);
  if(!is_array($a['fields']))throw new ValidationError('fields must be an object.');
  // REST body parameters take precedence over URL captures. Never allow a second target.
  if(array_intersect(array_keys($a['fields']),['id','product_id','order_id','plugin']))throw new ValidationError('Route identifiers must not appear in fields.');
  foreach(['id','parent'] as $key)if(array_key_exists($key,$a))Policy::id($a[$key]);
  if(self::account_deletion($op)){
   Policy::fields($a['fields'],['force','reassign'],['force']);
   if($a['fields']['force']!==true)throw new ValidationError('Permanent deletion requires explicit force: true.');
   if(isset($a['fields']['reassign'])&&Policy::id($a['fields']['reassign'])===$a['id'])throw new ValidationError('Reassignment must target a different account.');
  }
  if(isset($a['type'])&&!in_array($a['type'],['posts','pages'],true))throw new ValidationError('type must be posts or pages.');
  if(isset($a['taxonomy'])&&!in_array($a['taxonomy'],['categories','tags'],true))throw new ValidationError('Unsupported taxonomy.');
  if(isset($a['plugin'])&&!preg_match('~^[a-zA-Z0-9_-]+/[a-zA-Z0-9_.-]+$~D',$a['plugin']))throw new ValidationError('Invalid plugin identifier.');
  if(strlen(Policy::canonical($a))>131072)throw new ValidationError('Operation too large.');
 }
 public static function route(string $op,array $a): string {
  return preg_replace_callback('/\{(\w+)\}/',static fn($m)=>(string)$a[$m[1]],self::operations()[$op][2]);
 }
 public static function request(string $method,string $route,array $params=[]): array {
  $data=self::native_response($method,$route,$params)->get_data();
  return is_array($data)?$data:['value'=>$data];
 }
 private static function native_response(string $method,string $route,array $params): \WP_REST_Response {
  $req=new \WP_REST_Request($method,$route);$req->set_body_params($params);
  if($method==='GET')$req->set_query_params($params);
  $res=rest_do_request($req);
  if($res->is_error()||$res->get_status()>=400)throw new ConnectorError('Native API rejected operation. Verify fields and permissions.');
  return $res;
 }
 public static function product_collection(array $params): array {
  $response=self::native_response('GET','/wc/v3/products',$params+['_fields'=>'id']);
  $headers=array_change_key_case($response->get_headers(),CASE_LOWER);
  return ['items'=>$response->get_data(),'total'=>(int)($headers['x-wp-total']??0)];
 }
 public static function snapshot(string $op,array $a): array {
  $def=self::operations()[$op];
  if(self::account_deletion($op)){
   $user=self::deletable_account($op,$a['id']);
   $data=self::account_read(self::route($op,$a),[],$op==='customer_delete');
   $data['roles']=array_values($user->roles);
   return ['data'=>$data,'revision'=>Policy::fingerprint($data)];
  }
  $data=$def[3]?self::request('GET',self::route($op,$a),['context'=>'edit']):null;
  // Creating refunds/variations must also bind approval to the current parent state.
  if(in_array($op,['refund_create','variation_create'],true))$data=self::request('GET','/wc/v3/'.($op==='refund_create'?'orders':'products').'/'.$a['parent'],['context'=>'edit']);
  return ['data'=>$data,'revision'=>Policy::fingerprint($data)];
 }
 public static function apply(string $op,array $a): array {
  self::validate($op,$a);
  if(self::account_deletion($op))self::deletable_account($op,$a['id']);
  $result=self::request(self::operations()[$op][1],self::route($op,$a),$a['fields']);
  if(self::account_deletion($op))return ['id'=>$a['id'],'deleted'=>true];
  return self::redact($result);
 }
 public static function redact(array $data): array {
  foreach($data as $k=>&$v){
   if(preg_match('/password|secret|token|application_password/i',(string)$k))$v='[REDACTED]';
   elseif(is_array($v))$v=self::redact($v);
  }return $data;
 }
 /** Commerce-scope reads must not expose customer personal data (billing, shipping, IP, notes, coupon e-mail lists). */
 public static function redact_pii(array $data): array {
  foreach($data as $k=>&$v){
   if(is_string($k)&&preg_match('/^(billing|shipping|customer_ip_address|customer_user_agent|customer_note|email_restrictions|used_by|order_key|payment_url|transaction_id|meta_data)$/D',$k))$v='[REDACTED: customer data]';
   elseif(is_array($v))$v=self::redact_pii($v);
  }return $data;
 }
 public static function read(array $client,string $route,array $params): array {
  // No arbitrary plugin routes: a GET route is not necessarily side-effect-free.
  if($route==='/wp/v2/plugins'&&(Policy::allowed($client,'site_inspection')||!Policy::allowed($client,'maintenance'))){
   Policy::require_scope($client,'site_inspection');
   Policy::fields($params,['search']);
   if(isset($params['search'])&&(!is_string($params['search'])||strlen($params['search'])>200))throw new ValidationError('Plugin search must be text up to 200 bytes.');
   $fields=array_fill_keys(['plugin','name','status','version'],true);
   $data=array_map(static fn(array $plugin)=>array_intersect_key($plugin,$fields),self::request('GET',$route,$params+['_fields'=>implode(',',array_keys($fields))]));
   return ['data'=>$data,'revision'=>Policy::fingerprint($data)];
  }
  if(preg_match('~^/(?:wp/v2/users|wc/v3/customers)(?:/[1-9][0-9]*)?$~D',$route)&&(Policy::allowed($client,'accounts_read')||!Policy::allowed($client,'maintenance'))){
   Policy::require_scope($client,'accounts_read');
   $data=self::account_read($route,$params,str_starts_with($route,'/wc/'));
   return ['data'=>$data,'revision'=>Policy::fingerprint($data)];
  }
  if(preg_match('~^/wp/v2/(posts|pages|categories|tags|media|blocks|block-types|templates|template-parts)(/[a-zA-Z0-9_./%-]+)?$~D',$route))Policy::require_scope($client,'read');
  elseif(preg_match('~^/wc/v3/(products|orders|coupons)(/[a-zA-Z0-9_/-]+)?$~D',$route))Policy::require_scope($client,'commerce');
  elseif(preg_match('~^/wp/v2/(users|settings|plugins|themes)(/[a-zA-Z0-9_./%-]+)?$~D',$route)||preg_match('~^/wc/v3/customers(/[0-9]+)?$~D',$route))Policy::maintenance($client);
  else throw new ValidationError('Route is not in the native read allowlist.');
  if(str_contains($route,'..')||str_contains($route,'%'))throw new ValidationError('Ambiguous route.');
  // Pagination cannot be bypassed with per_page=-1.
  $params['per_page']=min(50,max(1,(int)($params['per_page']??20)));
  $data=self::request('GET',$route,$params);
  $out=self::redact($data);
  if(preg_match('~^/wc/v3/(orders|coupons)~',$route))$out=self::redact_pii($out);
  return ['data'=>$out,'revision'=>Policy::fingerprint($data)];
 }
 public static function plugins_list(): array {
  require_once ABSPATH.'wp-admin/includes/plugin.php';
  $updates=get_site_transient('update_plugins');$auto=(array)get_site_option('auto_update_plugins',[]);$items=[];
  foreach(get_plugins() as $file=>$plugin){
   $update=$updates->response[$file]??null;
   $items[]=['plugin'=>$file,'name'=>$plugin['Name'],'status'=>is_plugin_active_for_network($file)?'network-active':(is_plugin_active($file)?'active':'inactive'),'version'=>$plugin['Version'],'update_available'=>is_object($update),'new_version'=>$update->new_version??null,'requires_php'=>$update->requires_php??($plugin['RequiresPHP']??''),'auto_update'=>in_array($file,$auto,true),'folder_ok'=>!str_contains($file,'\\')&&is_file(WP_PLUGIN_DIR.'/'.$file)];
  }
  $issues=[];
  foreach(new \DirectoryIterator(WP_PLUGIN_DIR) as $entry){
   if($entry->isDot()||$entry->isLink())continue;
   if(str_contains($entry->getFilename(),'\\')){$issues[]=$entry->getFilename();continue;}
   if(!$entry->isDir()||!is_readable($entry->getPathname()))continue;
   $checked=0;
   foreach(new \DirectoryIterator($entry->getPathname()) as $child){
    if(++$checked>200)break;
    if(str_contains($child->getFilename(),'\\')){$issues[]=$entry->getFilename();break;}
   }
  }
  $issues=array_values(array_unique($issues));
  foreach($items as &$item)if(in_array(explode('/',$item['plugin'],2)[0],$issues,true))$item['folder_ok']=false;
  unset($item);
  return ['items'=>$items,'total'=>count($items),'folders_with_invalid_names'=>$issues];
 }
 public static function themes_list(): array {
  $updates=get_site_transient('update_themes');$items=[];
  foreach(wp_get_themes() as $slug=>$theme){
   $update=$updates->response[$slug]??null;
   $items[]=['theme'=>$slug,'name'=>$theme->get('Name'),'version'=>$theme->get('Version'),'active'=>$slug===get_stylesheet(),'parent'=>$theme->parent()?$theme->get_template():null,'update_available'=>is_array($update),'new_version'=>$update['new_version']??null];
  }
  return $items;
 }
 public static function users_query(array $client,array $args): array {
  if(!current_user_can('list_users'))throw new ConnectorError('WordPress does not permit listing users.');
  $page=min(10000,$args['page']??1);$limit=min(50,$args['per_page']??20);
  $orderby=$args['orderby']??'registered';
  if(!in_array($orderby,['id','registered'],true))throw new ValidationError('Unsupported user ordering.');
  $query=['number'=>$limit,'paged'=>$page,'count_total'=>true,'orderby'=>$orderby==='id'?'ID':['registered'=>'DESC','ID'=>'DESC'],'order'=>'ASC'];
  if(isset($args['role'])){
   if(!wp_roles()->is_role($args['role']))throw new ValidationError('Unknown site role.');
   $query['role']=$args['role'];
  }
  foreach(['registered_after'=>'after','registered_before'=>'before'] as $input=>$key)if(isset($args[$input])){
   $parsed=\DateTimeImmutable::createFromFormat('!Y-m-d',$args[$input]);
   if(!$parsed||$parsed->format('Y-m-d')!==$args[$input])throw new ValidationError('Registration dates must use YYYY-MM-DD.');
   $query['date_query'][0][$key]=$args[$input];
   $query['date_query'][0]['inclusive']=true;
  }
  if(isset($args['registered_after'],$args['registered_before'])&&$args['registered_after']>$args['registered_before'])throw new ValidationError('The registration date range is reversed.');
  if(isset($args['email_glob'])){
   $pattern=$args['email_glob'];
   if(strlen($pattern)>200||!preg_match('/^\*?[A-Za-z0-9._+@-]+\*?$/D',$pattern))throw new ValidationError('Email search accepts plain text and optional * at either end.');
   $query['search']=$pattern;$query['search_columns']=['user_email'];
  }
  if(isset($args['has_name'])){
   $query['meta_query']=['relation'=>$args['has_name']?'OR':'AND'];
   foreach(['first_name','last_name'] as $key){
    $query['meta_query'][]=$args['has_name']?['key'=>$key,'value'=>'','compare'=>'!=']:['relation'=>'OR',['key'=>$key,'compare'=>'NOT EXISTS'],['key'=>$key,'value'=>'']];
   }
  }
  $woo=function_exists('wc_get_orders');$filter_orders=isset($args['has_orders']);
  if($filter_orders&&!$woo)throw new ConnectorError('WooCommerce is required to filter by order history.');
  $show_email=Policy::allowed($client,'accounts_email');
  $result=new \WP_User_Query($query);$items=[];
  foreach($result->get_results() as $user){
   $count=$woo?self::customer_order_count((int)$user->ID):null;
   if($filter_orders&&(($count>0)!==$args['has_orders']))continue;
   $items[]=['id'=>$user->ID,'first_name'=>$user->first_name,'last_name'=>$user->last_name,'registered'=>$user->user_registered,'roles'=>array_values($user->roles),'orders_count'=>$count,'email'=>$show_email?$user->user_email:($user->user_email!==''?'***@***':null)];
  }
  $total=(int)$result->get_total();
  return ['items'=>$items,'total'=>$filter_orders?null:$total,'candidate_total'=>$total,'page'=>$page,'per_page'=>$limit,'next'=>$page*$limit<$total?$page+1:null];
 }
 public static function users_delete_preview(array $ids): array {
  if(!$ids||count($ids)>20)throw new ValidationError('Select between 1 and 20 exact account IDs.');
  foreach($ids as $id)Policy::id($id);
  if(count($ids)!==count(array_unique($ids)))throw new ValidationError('Account IDs must be unique.');
  sort($ids,SORT_NUMERIC);$eligible=[];$skipped=[];
  foreach($ids as $id){
   try{
    $target=self::snapshot('user_delete',['id'=>$id,'fields'=>['force'=>true]]);
    $eligible[]=$target['data']+['revision'=>$target['revision']];
   }catch(ConnectorError $e){$skipped[]=['id'=>$id,'reason'=>$e->getMessage()];}
  }
  return ['dry_run'=>true,'count'=>count($ids),'batch_hash'=>Policy::fingerprint($ids),'eligible'=>$eligible,'skipped'=>$skipped];
 }
 private static function customer_order_count(int $id): int {
  $orders=wc_get_orders(['customer_id'=>$id,'limit'=>1,'paginate'=>true,'return'=>'ids','type'=>'shop_order']);
  return (int)$orders->total;
 }
 private static function account_read(string $route,array $query,bool $woo): array {
  $single=ctype_digit(basename($route));
  Policy::fields($query,$single?[]:['page','per_page']);
  $fields=$woo?['id','first_name','last_name']:['id','name','first_name','last_name','roles'];
  $params=['context'=>'edit','_fields'=>implode(',',$fields)];
  if(!$single)$params+=['page'=>min(10000,Policy::id($query['page']??1)),'per_page'=>min(50,Policy::id($query['per_page']??20)),'orderby'=>'id','order'=>'asc'];
  if($woo&&!function_exists('wc_get_orders'))throw new ConnectorError('WooCommerce is unavailable.');
  $data=self::request('GET',$route,$params);
  $project=static function(array $account)use($woo,$fields): array {
   $account=array_intersect_key($account,array_flip($fields));
   if($woo){
    $account['orders_count']=self::customer_order_count(Policy::id($account['id']??null));
   }
   return $account;
  };
  return $single?$project($data):array_map($project,$data);
 }
}
