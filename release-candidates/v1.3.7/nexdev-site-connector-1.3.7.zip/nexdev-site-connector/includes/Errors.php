<?php
namespace Nexdev\SiteConnector;
// Only these explicitly authored messages are safe to expose over MCP.
class ConnectorError extends \RuntimeException {}
class ValidationError extends \InvalidArgumentException {}
final class PermissionError extends ConnectorError {
 public function __construct(public readonly string $scope,public readonly bool $window_required=false) {
  parent::__construct($window_required?'Maintenance window is closed. A human administrator must open it.':'Required permission is unavailable: '.$scope.'.');
 }
}
final class ArgumentsError extends ValidationError {
 public function __construct(public readonly array $supported_args,bool $missing) {
  parent::__construct($missing?'Missing required argument.':'Unknown argument.');
 }
}

class RateLimitError extends ConnectorError {}
