=== NexPilot ===
Contributors: nexdev
Requires at least: 6.6.5
Tested up to: 7.1.4
Requires PHP: 8.1
Stable tag: 1.2.1
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Independent AI connections, human-approved changes and temporary full maintenance.

== Stable 1.1.1 ==
Connection package access correction. Supported runtime and client scope remain documented; native Claude execution is not newly certified by this release. Existing installed desktop bundles must be updated separately.

== Stable 1.1.0 ==
Editorial update: draft copies, draft-only connections, discoverable preview/propose/execute, SEO metadata, offline admin batch review, local PDF text/OCR interface. Qualified for the documented single-site Codex scope. OCR needs host binaries; Yoast/Rank Math integration needs site-specific QA.

== Stable 1.0.3 ==
1.0.3: signed public updates without GitHub credentials. Qualified for the documented single-site Codex scope.
Validate this update in staging before deployment.
Not an independent audit or WordPress.org directory edition. Validate each site
in staging. Full maintenance is unrestricted access. No personal credentials ship.

== Installation ==
Install on an authorized staging instance or controlled pilot.
Tools > NexPilot > Create connection.
Create a separate credential for each AI client. Read-only is the default.

== Data retention ==
Deactivation does not delete credentials, audit records or encrypted proposals.
An administrator can opt into connector-data removal on uninstall. Default is retention.
Opt-in removal deletes connector records and audit, revokes tracked temporary sessions,
and retains site content, uploads and user sandbox files. Multisite cleanup is not implemented.

== Privacy and external services ==
No model provider is contacted automatically by this plugin. Authorized MCP clients
can retrieve site data within their granted scopes and send it to the model provider
chosen in that client. Review the provider's terms and privacy policy before connecting.
Use synthetic data for testing. With approvals mode requires a separate approval per change; owner-selected Full access grants standing authorization for its selected duration.

Optional external audit delivery is disabled unless an administrator configures
NSC_AUDIT_URL and NSC_AUDIT_KEY. It sends the site URL, timestamp, connection identifier,
event type and reference identifier to that configured HTTPS receiver. No fixed
Nexdev telemetry destination is included. Agree a retention policy for that receiver.

== Distribution and updates ==
This full edition includes administrator-approved arbitrary code and file maintenance.
It is not eligible for submission under the current WordPress.org new-plugin FAQ.
Signed public updates are enabled by default from https://nexdev-team.github.io/NexPilot-updates/.
No GitHub account or key is required. WordPress checks the signed release metadata
and verifies the downloaded ZIP before installation. To install automatically,
enable auto-updates for NexPilot in WordPress; otherwise use Update now.
Version 1.0.2 installations need a one-time manual ZIP upgrade unless their legacy
private updater is already configured. Personal AI connections remain site-local.
The optional NSC_UPDATE_CHANNEL=private server setting retains legacy private delivery.

== Changelog ==

= 1.2.1 — 31/10/2026 =
- Το «View version details» εμφανίζει πληροφορίες έκδοσης και καρτέλα Changelog.
- Οι σημειώσεις προέρχονται από το υπογεγραμμένο ZIP της νεότερης έκδοσης, ώστε να διαβάζονται πριν το update.
- Προστέθηκε ευανάγνωστο ιστορικό αλλαγών στα ελληνικά.
- Δεν αλλάζουν οι συνδέσεις, τα δικαιώματα ή οι επιλογές εγκρίσεων.

= 1.2.0 — 31/10/2026 =
- Δύο επιλογές ανά σύνδεση: With approvals ή Full access χωρίς ξεχωριστό approve ανά αλλαγή.
- Διάρκεια Full access: 10 λεπτά, 1 ώρα, 8 ώρες ή μέχρι τη λήξη της σύνδεσης.
- Οι υπάρχουσες συνδέσεις παραμένουν με εγκρίσεις μέχρι να επιλέξει διαφορετικά ο ιδιοκτήτης τους.
- Διατηρούνται οι έλεγχοι δικαιωμάτων, τα αρχεία δραστηριότητας, οι έλεγχοι σύγκρουσης και η ακύρωση πρόσβασης μετά τη λήξη ή ανάκληση.

= 1.1.1 — 31/10/2026 =
- Τα πακέτα σύνδεσης ακολουθούν τα δικαιώματα που επιλέγεις, εκτός αν ορίσεις περιορισμό στη συσκευή.
- Το πακέτο Claude εμφανίζει επιλογή Read-only access on this device στις ρυθμίσεις του.
- Τα διαγνωστικά ξεχωρίζουν τον περιορισμό της συσκευής από τα δικαιώματα του WordPress.
- Τα ήδη εγκατεστημένα πακέτα σύνδεσης ενημερώνονται ξεχωριστά από το WordPress plugin.

= 1.1.0 — 31/10/2026 =
- Αντίγραφα πρόχειρων σελίδων, συνδέσεις Draft-only και αλλαγές τίτλου, περιεχομένου, slug και ταξινομιών.
- Λειτουργίες SEO metadata και ομαδικός έλεγχος προτάσεων από τον διαχειριστή.
- Τοπική ανάγνωση PDF/OCR όταν ο server διαθέτει τα απαιτούμενα εργαλεία.

= 1.0.3 =
Public signed metadata and ZIP delivery; no recipient GitHub credentials; independent public-channel trust key; daily metadata renewal.

= 1.0.2 =
Browser sign-in guide for Codex; encrypted site-local private GitHub update setup, visible status and signed download verification without installation.

= 1.0.1 =
Unified administration into setup, connections, proposals, activity and advanced settings tabs.
Connection creation is part of setup step 4. Activity uses a readable table.
Existing credentials, scopes, approvals, OAuth and data retention are preserved.

= 1.0.0 =
First private Stable: scoped security/runtime qualification, signed private updates, privacy controls and clean installation/upgrade/rollback verification. Earlier entries below describe historical versions.

= 0.2.0 =
Private local stable package for the bounded Codex desktop scope. Includes rc.3 authorization hardening, independently reviewed derivative-capability binding and verified recovery. Claude validation and distribution remain deferred.

= 0.2.0-rc.3 =
Prepared SQL identifiers and WPForms predicates; WordPress script enqueueing; validated input and static errors; bounded OAuth rate storage; queued WP-CLI authorization binding. Private candidate, not stable.
= 0.2.0-rc.2 =
NexPilot branding by Nexdev. REST target-binding fix, stateless anonymous OAuth
registration, local security and desktop regression testing. Not a stable release.

= 0.2.0-beta.1 =
Expanded beta: native resource operations, editor validation, conditional integrations,
one-use transfers and admin access, async jobs, recovery and concurrent-client tests.
