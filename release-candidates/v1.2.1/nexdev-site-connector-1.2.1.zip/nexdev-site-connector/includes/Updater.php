<?php
namespace Nexdev\SiteConnector;

/** Signed public updates by default; owner-configured private channel retained for transition. */
final class Updater {
 const API = 'https://api.github.com/repos/nexdev-team/NexPilot';
 const SLUG = 'nexdev-site-connector';
 const PLUGIN = self::SLUG . '/nexdev-site-connector.php';
 const MAX_BYTES = 16777216;
 // Public trust anchor, verified by the owner before private distribution. Never a credential.
 const PUBLIC_KEY = "y4Ev9AI0kpJiMEpR2pOtDnUP8XDQcxpq3ZxoSDGowog=";
 const PUBLIC_BASE = 'https://nexdev-team.github.io/NexPilot-updates';
 const PUBLIC_REPOSITORY = 'nexdev-team/NexPilot-updates';
 const PUBLIC_CHANNEL_KEY = 'IqIbvYYMJWVxeblr6KCxn6S91wElM9jW9dX0djpjA9s=';
 public static function public_mode(): bool {return !defined('NSC_UPDATE_CHANNEL')||NSC_UPDATE_CHANNEL==='public';}
 private static function cache_key(): string {return self::public_mode()?'nsc_signed_public_update_v2':'nsc_signed_update_v1';}
 private static function public_key_for_channel(): string {return defined('NSC_PUBLIC_UPDATE_KEY')?NSC_PUBLIC_UPDATE_KEY:self::PUBLIC_CHANNEL_KEY;}
 private static function archive_url(array $manifest): string {return self::public_mode()?self::PUBLIC_BASE.'/'.self::SLUG.'-'.$manifest['version'].'.zip':self::API.'/releases/assets/'.$manifest['asset_id'];}
 private static function public_get(string $url,int $limit): string {
  if(!preg_match('~^'.preg_quote(self::PUBLIC_BASE,'~').'/(?:nexpilot-update\.json|nexdev-site-connector-[1-9][0-9]*\.[0-9]+\.[0-9]+\.zip)$~D',$url))throw new \RuntimeException('Public update destination rejected.');
  // Fixed HTTPS distribution origin, no credentials, redirects, site identifier or telemetry.
  $response=wp_safe_remote_get($url,['timeout'=>60,'redirection'=>0,'sslverify'=>true,'limit_response_size'=>$limit,'user-agent'=>'NexPilot/'.NSC_VERSION,'headers'=>['Accept'=>'application/octet-stream']]);
  if(is_wp_error($response)||wp_remote_retrieve_response_code($response)!==200)throw new \RuntimeException('Public update service unavailable.');
  $body=wp_remote_retrieve_body($response);if(strlen($body)>=$limit)throw new \RuntimeException('Public update response exceeds limit.');return $body;
 }
 private static function archive_bytes(array $manifest): string {return self::public_mode()?self::public_get(self::archive_url($manifest),self::MAX_BYTES+1):self::api('/releases/assets/'.$manifest['asset_id'],true,self::MAX_BYTES+1);}

 public static function register(): void {
  add_filter('update_plugins_github.com', [self::class, 'update'], 10, 4);
  add_filter('upgrader_pre_download', [self::class, 'download'], 10, 4);
  add_filter('plugins_api', [self::class, 'information'], 10, 3);
 }
 private static function token(): string {
  if (!defined('NSC_UPDATE_TOKEN_FILE')) {
   $record=Store::get('updater_credential');
   $value=$record['token']??'';
   if(!is_string($value)||!preg_match('/^[A-Za-z0-9_.-]{20,4096}$/D',$value))throw new \RuntimeException('Updater is not configured.');
   return $value;
  }
  clearstatcache(true, NSC_UPDATE_TOKEN_FILE);
  $path = realpath(NSC_UPDATE_TOKEN_FILE);
  $root = realpath(ABSPATH);
  if (!$path || !$root || !is_file($path) || is_link(NSC_UPDATE_TOKEN_FILE) || str_starts_with($path, $root . DIRECTORY_SEPARATOR) || (fileperms($path) & 0077)) throw new \RuntimeException('Private updater credentials required outside the web root.');
  $roots=[$root];
  if(defined('WP_CONTENT_DIR')&&realpath(WP_CONTENT_DIR))$roots[]=realpath(WP_CONTENT_DIR);
  if(!empty($_SERVER['DOCUMENT_ROOT'])&&realpath($_SERVER['DOCUMENT_ROOT']))$roots[]=realpath($_SERVER['DOCUMENT_ROOT']);
  foreach($roots as $public_root)if($path===$public_root||str_starts_with($path,$public_root.DIRECTORY_SEPARATOR)||str_starts_with(NSC_UPDATE_TOKEN_FILE,$public_root.DIRECTORY_SEPARATOR))throw new \RuntimeException('Updater credentials must be outside public WordPress roots.');
  for($parent=dirname(NSC_UPDATE_TOKEN_FILE);$parent!==dirname($parent);$parent=dirname($parent))if(is_link($parent))throw new \RuntimeException('Use a canonical private credential path without symbolic links.');
  $token = trim((string)file_get_contents($path));
  if (!preg_match('/^[A-Za-z0-9_.-]{20,4096}$/D', $token)) throw new \RuntimeException('Invalid updater credential.');
  return $token;
 }
 private static function api(string $path, bool $binary = false, int $limit = 262144, ?string $credential = null): string {
  $response = wp_safe_remote_get(self::API . $path, ['timeout'=>30, 'redirection'=>0, 'sslverify'=>true,
   'limit_response_size'=>$limit, 'headers'=>['Authorization'=>'Bearer '.($credential??self::token()), 'Accept'=>$binary?'application/octet-stream':'application/vnd.github+json', 'X-GitHub-Api-Version'=>'2022-11-28']]);
  if (is_wp_error($response)) throw new \RuntimeException('Update service unavailable.');
  $status = wp_remote_retrieve_response_code($response);
  if ($binary && $status === 302) {
   $url = wp_remote_retrieve_header($response, 'location');
   $u = wp_parse_url($url);
   if (!is_array($u) || ($u['scheme']??'') !== 'https' || ($u['host']??'') !== 'release-assets.githubusercontent.com' || isset($u['user']) || isset($u['pass']) || isset($u['port']) || isset($u['fragment'])) throw new \RuntimeException('Unsafe asset destination.');
   // Never forward the GitHub credential to the asset host or follow additional redirects.
   $response = wp_safe_remote_get($url, ['timeout'=>60,'redirection'=>0,'sslverify'=>true,'limit_response_size'=>$limit]);
   if (is_wp_error($response)) throw new \RuntimeException('Update download unavailable.');
   $status = wp_remote_retrieve_response_code($response);
  }
  if ($status !== 200) throw new \RuntimeException('Update request rejected.');
  $body = wp_remote_retrieve_body($response);
  if (strlen($body) >= $limit) throw new \RuntimeException('Update response exceeds limit.');
  return $body;
 }
 public static function public_key(): string {return defined('NSC_UPDATE_PUBLIC_KEY')?NSC_UPDATE_PUBLIC_KEY:self::PUBLIC_KEY;}
 private static function admin_guard(): void {
  if(!current_user_can('update_plugins'))throw new \RuntimeException('Update administrator access required.');
  if(!is_ssl()&&!(wp_get_environment_type()==='local'&&defined('NSC_ALLOW_LOCAL_HTTP')&&NSC_ALLOW_LOCAL_HTTP))throw new \RuntimeException('HTTPS is required for update settings.');
 }
 private static function last_status(): array {
  $last=get_option('nsc_update_status',[]);
  return is_array($last)&&($last['installed']??null)===NSC_VERSION&&($last['channel']??null)===(self::public_mode()?'public':'private')?$last:[];
 }
 public static function configuration(): array {
  if(self::public_mode()){
   $last=self::last_status();
   return ['configured'=>true,'managed'=>false,'channel'=>'public','public_key_sha256'=>hash('sha256',(string)base64_decode(self::public_key_for_channel(),true)),'last'=>is_array($last)?$last:[]];
  }
  $configured=false;
  try{self::token();$configured=true;}catch(\Throwable $e){}
  $last=self::last_status();
  return ['configured'=>$configured,'managed'=>defined('NSC_UPDATE_TOKEN_FILE'),'channel'=>'private','public_key_sha256'=>hash('sha256',(string)base64_decode(self::public_key(),true)),'last'=>is_array($last)?$last:[]];
 }
 public static function save_credential(string $credential): void {
  self::admin_guard();
  if(self::public_mode())throw new \RuntimeException('Public updates do not use GitHub credentials.');
  if(defined('NSC_UPDATE_TOKEN_FILE'))throw new \RuntimeException('Updates are managed by the server configuration.');
  $credential=trim($credential);
  if(!preg_match('/^github_pat_[A-Za-z0-9_]{20,4080}$/D',$credential))throw new \RuntimeException('Use the fine-grained GitHub update key from the linked setup page.');
  try{$manifest=self::release(false,$credential);}catch(\Throwable $e){throw new \RuntimeException('GitHub connection could not be verified. Check repository access, approval, credential expiry and the signed release.');}
  Store::locked(static function()use($credential){
   Store::put('updater_credential','update_credential',['token'=>$credential,'saved_by'=>get_current_user_id(),'saved_at'=>time()]);
   Store::audit('human:'.get_current_user_id(),'updater.connected');
  });
  delete_transient('nsc_signed_update_v1');
  self::record_status($manifest,false);
 }
 public static function disconnect(): void {
  self::admin_guard();
  if(defined('NSC_UPDATE_TOKEN_FILE'))throw new \RuntimeException('Updates are managed by the server configuration.');
  Store::locked(static function(){Store::delete('updater_credential');Store::audit('human:'.get_current_user_id(),'updater.disconnected');});
  delete_transient('nsc_signed_update_v1');delete_option('nsc_update_status');
 }
 private static function record_status(array $manifest,bool $download): array {
  $state=version_compare($manifest['version'],NSC_VERSION,'>')?'available':(version_compare($manifest['version'],NSC_VERSION,'=')?'current':'ahead');
  $status=['channel'=>self::public_mode()?'public':'private','state'=>$state,'installed'=>NSC_VERSION,'latest'=>$manifest['version'],'checked_at'=>time(),'signature_verified'=>true,'download_verified'=>$download];
  update_option('nsc_update_status',$status,false);return $status;
 }
 /** Verify metadata and optionally the real signed archive. Does not install or replace plugin files. */
 public static function check(bool $verify_download=false): array {
  self::admin_guard();$path=null;
  try{
   if(!self::public_mode())self::token();$manifest=self::release(false);
   if($verify_download){
    $bytes=self::archive_bytes($manifest);
    $path=wp_tempnam('nexpilot-check.zip');
    if(!$path||file_put_contents($path,$bytes)!==strlen($bytes))throw new \RuntimeException('Cannot stage update check.');
    self::check_archive($path,$manifest);
   }
   return self::record_status($manifest,$verify_download);
  }catch(\Throwable $e){
   $status=['channel'=>self::public_mode()?'public':'private','state'=>'unavailable','installed'=>NSC_VERSION,'checked_at'=>time(),'signature_verified'=>false,'download_verified'=>false];
   update_option('nsc_update_status',$status,false);return $status;
  }finally{if($path&&is_file($path))unlink($path);}
 }
 /** Verify the exact signed bytes before interpreting any release-controlled fields. */
 public static function verify(string $envelope, string $public, int $now, bool $public_channel=false): array {
  $e = json_decode($envelope, true, 16, JSON_THROW_ON_ERROR);
  $payload = $e['payload']??null;
  $sig = base64_decode($e['signature']??'', true);
  $key = base64_decode($public, true);
  if (!is_string($payload) || strlen($payload)>16384 || $sig===false || $key===false || strlen($sig)!==64 || strlen($key)!==32 || !sodium_crypto_sign_verify_detached($sig,$payload,$key)) throw new \RuntimeException('Update signature rejected.');
  $m = json_decode($payload,true,16,JSON_THROW_ON_ERROR);
  if (($m['format']??null)!==($public_channel?2:1) || ($m['repository']??'')!==($public_channel?self::PUBLIC_REPOSITORY:'nexdev-team/NexPilot') || ($public_channel&&($m['channel']??'')!=='public') || ($m['slug']??'')!==self::SLUG
   || !is_string($m['version']??null) || !preg_match('/^[1-9][0-9]*\.[0-9]+\.[0-9]+$/D',$m['version'])
   || ($m['tag']??'')!=='v'.$m['version'] || !is_int($m['asset_id']??null) || $m['asset_id']<1
   || !is_int($m['bytes']??null) || $m['bytes']<1 || $m['bytes']>self::MAX_BYTES
   || !is_string($m['sha256']??null) || !preg_match('/^[a-f0-9]{64}$/D',$m['sha256'])
   || !is_int($m['issued_at']??null) || !is_int($m['expires_at']??null)
   || $m['issued_at']>$now+300 || $m['expires_at']<=$now || $m['expires_at']<=$m['issued_at'] || $m['expires_at']-$m['issued_at']>30*DAY_IN_SECONDS) throw new \RuntimeException('Update manifest rejected.');
  return $m;
 }
 private static function release(bool $require_newer = true, ?string $credential = null): array {
  if(self::public_mode()){
   if($credential!==null)throw new \RuntimeException('Public updates do not use credentials.');
   $m=self::verify(self::public_get(self::PUBLIC_BASE.'/nexpilot-update.json',32768),self::public_key_for_channel(),time(),true);
   if($require_newer&&!version_compare($m['version'],NSC_VERSION,'>'))throw new \RuntimeException('Newer public Stable release required.');
   return $m;
  }
  $r=json_decode(self::api('/releases/latest',false,262144,$credential),true,32,JSON_THROW_ON_ERROR);
  if (!empty($r['draft']) || !empty($r['prerelease'])) throw new \RuntimeException('Stable release required.');
  $manifest=null;
  foreach(($r['assets']??[]) as $a) if(($a['name']??'')==='nexpilot-update.json' && is_int($a['id']??null)) $manifest=$a['id'];
  if (!$manifest) throw new \RuntimeException('Signed release manifest missing.');
  $m=self::verify(self::api('/releases/assets/'.$manifest,true,32768,$credential),self::public_key(),time());
  if (($r['tag_name']??'')!==$m['tag'] || ($require_newer && !version_compare($m['version'],NSC_VERSION,'>'))) throw new \RuntimeException('Release version rejected.');
  foreach(($r['assets']??[]) as $a) if(($a['id']??null)===$m['asset_id'] && ($a['size']??null)===$m['bytes'] && ($a['name']??'')===self::SLUG.'-'.$m['version'].'.zip') return $m;
  throw new \RuntimeException('Signed asset is not part of this release.');
 }
 public static function update($update, array $data, string $file, array $locales) {
  if ($file!==self::PLUGIN) return $update;
  try {
   if(!self::public_mode())self::token();
   $m=get_transient(self::cache_key());
   if (!is_array($m)) { $m=self::release(!self::public_mode()); set_transient(self::cache_key(),$m,300); }
   $newer=version_compare($m['version'],NSC_VERSION,'>');
   if ($m['expires_at']<=time() || (!self::public_mode()&&!$newer)) return false;
   $home=self::public_mode()?'https://github.com/'.self::PUBLIC_REPOSITORY:'https://github.com/nexdev-team/NexPilot';
   return ['id'=>$home,'slug'=>self::SLUG,'version'=>$m['version'],'url'=>$home,'package'=>$newer?self::archive_url($m):''];
  } catch (\Throwable $e) { return false; }
 }
 /** Read plugin details only from the authenticated archive, never from arbitrary HTML. */
 public static function information($result,string $action,$args) {
  if($action!=='plugin_information'||!is_object($args)||($args->slug??'')!==self::SLUG)return $result;
  $path=null;
  try{
   $m=self::release(false);$key='nsc_plugin_info_'.(self::public_mode()?'public_':'private_').substr($m['sha256'],0,20);
   $notes=get_transient($key);
   if(!is_array($notes)||!is_string($notes['readme']??null)||!is_string($notes['header']??null)){
    $bytes=self::archive_bytes($m);
    if(!function_exists('wp_tempnam'))require_once ABSPATH.'wp-admin/includes/file.php';
    $path=wp_tempnam('nexpilot-details.zip');
    if(!$path||file_put_contents($path,$bytes)!==strlen($bytes))throw new \RuntimeException('Cannot read release notes.');
    self::check_archive($path,$m);$zip=new \ZipArchive();
    if($zip->open($path)!==true)throw new \RuntimeException('Cannot open release notes.');
    try{$notes=['readme'=>$zip->getFromName(self::SLUG.'/readme.txt',262145),'header'=>$zip->getFromName(self::PLUGIN,8192)];}finally{$zip->close();}
    if(!is_string($notes['readme'])||strlen($notes['readme'])>262144||!is_string($notes['header']))throw new \RuntimeException('Release notes unavailable.');
    set_transient($key,$notes,min(300,max(1,$m['expires_at']-time())));
   }
   $fields=['requires'=>'Requires at least','requires_php'=>'Requires PHP'];$meta=[];
   foreach($fields as $field=>$label){preg_match('/^ \* '.preg_quote($label,'/').': ([^\r\n]+)/m',$notes['header'],$match);$meta[$field]=$match[1]??'';}
   preg_match('/^Tested up to: ([^\r\n]+)/m',$notes['readme'],$match);$meta['tested']=$match[1]??'';
   foreach($meta as $field=>$value)$meta[$field]=preg_match('/^[0-9]+(?:\.[0-9]+){0,3}$/D',trim($value))?trim($value):'';
   $sections=self::readme_sections($notes['readme']);
   return (object)(['name'=>'NexPilot','slug'=>self::SLUG,'version'=>$m['version'],'author'=>'Nexdev','homepage'=>self::PUBLIC_BASE.'/','download_link'=>self::archive_url($m),'external'=>true,'sections'=>[
    'description'=>'<p>Σύνδεση εργαλείων AI με το WordPress. Οι παρακάτω πληροφορίες προέρχονται από το υπογεγραμμένο πακέτο της έκδοσης '.esc_html($m['version']).'.</p>',
    'installation'=>self::notes_html($sections['installation']??'Tools → NexPilot για δημιουργία σύνδεσης.'),
    'changelog'=>self::notes_html($sections['changelog']??'Δεν έχουν καταχωριστεί σημειώσεις αλλαγών για αυτή την έκδοση.')
   ]]+$meta);
  }catch(\Throwable $e){return new \WP_Error('nsc_plugin_details_unavailable','Οι πληροφορίες έκδοσης NexPilot δεν μπόρεσαν να επαληθευτούν. Δοκιμάστε ξανά αργότερα.');}
  finally{if($path&&is_file($path))unlink($path);}
 }
 private static function readme_sections(string $readme): array {
  $sections=[];$section='';
  foreach(preg_split('/\R/',$readme) as $line){
   if(preg_match('/^==\s*(.+?)\s*==$/',$line,$match)){$section=strtolower(trim($match[1]));continue;}
   if($section!=='')$sections[$section]=($sections[$section]??'').$line."\n";
  }
  return $sections;
 }
 private static function notes_html(string $text): string {
  $html='';$list=false;
  foreach(preg_split('/\R/',trim($text)) as $line){
   $line=trim($line);$bullet=preg_match('/^[-*]\s+(.+)$/',$line,$item);
   if($list&&!$bullet){$html.='</ul>';$list=false;}
   if($bullet){if(!$list){$html.='<ul>';$list=true;}$html.='<li>'.esc_html($item[1]).'</li>';}
   elseif(preg_match('/^=\s*(.+?)\s*=$/',$line,$heading))$html.='<h3>'.esc_html($heading[1]).'</h3>';
   elseif($line!=='')$html.='<p>'.esc_html($line).'</p>';
  }
  return $html.($list?'</ul>':'');
 }
 public static function check_archive(string $path, array $m): void {
  if (filesize($path)!==$m['bytes'] || !hash_equals($m['sha256'],hash_file('sha256',$path))) throw new \RuntimeException('Update integrity rejected.');
  $z=new \ZipArchive();
  if ($z->open($path)!==true) throw new \RuntimeException('Invalid update ZIP.');
  try {
   if ($z->numFiles>400) throw new \RuntimeException('Excessive ZIP entries.');
   $total=0;$seen=[];
   for($i=0;$i<$z->numFiles;$i++) {
    $s=$z->statIndex($i);$name=$s['name'];$total+=$s['size'];
    $z->getExternalAttributesIndex($i,$ops,$attr);
    if (!str_starts_with($name,self::SLUG.'/') || str_contains($name,'\\') || str_contains($name,"\0") || preg_match('~(^|/)\.\.?(/|$)~',$name) || isset($seen[strtolower($name)]) || (($attr>>16)&0170000)===0120000 || $total>self::MAX_BYTES*4) throw new \RuntimeException('Unsafe update ZIP.');
    $seen[strtolower($name)]=true;
   }
   $header=$z->getFromName(self::PLUGIN);
   if (!is_string($header) || !preg_match('/^ \* Version: ([^\r\n]+)$/m',$header,$v) || $v[1]!==$m['version']) throw new \RuntimeException('ZIP version mismatch.');
  } finally { $z->close(); }
 }
 public static function download($reply, string $package, $upgrader, array $extra=[]) {
  $ours=($extra['plugin']??'')===self::PLUGIN || str_starts_with($package,self::API.'/releases/assets/') || str_starts_with($package,self::PUBLIC_BASE.'/');
  if (!$ours) return $reply;
  // Explicit administrator ZIP upload/rollback is separate from remote automatic updates.
  if (!preg_match('~^[a-z][a-z0-9+.-]*://~i',$package) && is_file($package) && current_user_can('update_plugins')) return $reply;
  $path=null;
  try {
   // Ignore preexisting local overrides for this plugin: every installation must verify fresh signed metadata.
   $m=self::release();
   if ($package!==self::archive_url($m)) throw new \RuntimeException('Update package mismatch.');
   $bytes=self::archive_bytes($m);
   $path=wp_tempnam('nexpilot-update.zip');
   if (!$path || file_put_contents($path,$bytes)!==strlen($bytes)) throw new \RuntimeException('Cannot stage update.');
   self::check_archive($path,$m);
   return $path;
  } catch (\Throwable $e) {
   if ($path && is_file($path)) unlink($path);
   return new \WP_Error('nsc_update_rejected','NexPilot update could not be authenticated. Verify updater configuration and the signed release.');
  }
 }
}
