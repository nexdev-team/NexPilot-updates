<?php
namespace Nexdev\SiteConnector;
/** New articles and bundled covers only; permissions are changed in the administrator UI. */
final class Blog {
 public static function configure(string $id,bool $enabled,bool $automatic): void {
  if(!current_user_can('manage_options'))throw new ConnectorError('Administrator required.');
  $c=Store::get($id);
  if(!$c||!isset($c['hash'])||!Policy::allowed($c,'read')||!empty($c['oauth_only']))throw new ConnectorError('Active token connection required.');
  if((int)$c['user_id']!==get_current_user_id())throw new ConnectorError('Only the connection owner can change blog permissions.');
  if($enabled&&array_diff($c['scopes'],['read','blog']))throw new ConnectorError('Restricted blog access requires a read-only connection.');
  $c['scopes']=array_values(array_diff($c['scopes'],['blog']));if($enabled)$c['scopes'][]='blog';
  $c['blog_auto_publish']=$enabled&&$automatic;$c['blog_granted_by']=get_current_user_id();
  if($enabled){$c['draft_only']=!$automatic;$c['approval_mode']='manual';$c['approval_until']=0;$c['approval_grant']='';}
  $c['blog_policy_revision']=bin2hex(random_bytes(16));
  Store::audit('human:'.get_current_user_id(),'blog.permission.changed',$id);
  Store::put($id,'client',$c); // Preserve credential hash and expiry.
 }
 public static function validate(array $a): void {
  Policy::fields($a,['request_key','title','content','excerpt','status','image'],['request_key','title','content','status','image']);
  if(!is_string($a['request_key'])||!preg_match('/^[a-zA-Z0-9_-]{16,80}$/D',$a['request_key']))throw new ValidationError('Unique request_key required.');
  foreach(['title'=>300,'content'=>60000,'excerpt'=>2000] as $k=>$limit)if(isset($a[$k])&&(!is_string($a[$k])||strlen($a[$k])>$limit||!preg_match('//u',$a[$k])))throw new ValidationError('Invalid article text.');
  if(trim($a['title'])===''||trim($a['content'])===''||!in_array($a['status'],['draft','publish'],true))throw new ValidationError('Title, content and draft/publish status required.');
  if(!is_array($a['image']))throw new ValidationError('WebP cover required.');
  Policy::fields($a['image'],['base64','sha256','alt'],['base64','sha256','alt']);$i=$a['image'];
  if(!is_string($i['base64'])||strlen($i['base64'])>200000||!is_string($i['sha256'])||!is_string($i['alt'])||strlen($i['alt'])>500)throw new ValidationError('Invalid cover.');
  $b=base64_decode($i['base64'],true);$s=$b===false?false:@getimagesizefromstring($b);
  if(!$b||strlen($b)>150000||!$s||$s[0]!==1000||$s[1]!==1000||($s['mime']??'')!=='image/webp'||!hash_equals(hash('sha256',$b),$i['sha256']))throw new ValidationError('Cover must be 1000 × 1000 WebP, maximum 150 kB, with matching SHA256.');
 }
 private static function key(array $c,string $request): string {return 'blog_'.substr(hash('sha256',$c['id'].':'.$request),0,48);}
 public static function receipt(array $c,string $request): array {return Store::get(self::key($c,$request))??['state'=>'not_started'];}
 public static function snapshot(array $a,array $c): array {
  Policy::require_scope($c,'blog');
  if($a['status']==='publish'&&(!self::publishing($c)))throw new ConnectorError('Publishing is disabled in NexPilot.');
  $d=['receipt'=>self::receipt($c,$a['request_key']),'site'=>home_url(),'credential'=>$c['hash'],'owner'=>$c['user_id'],'policy'=>$c['blog_policy_revision']??'','automatic'=>self::publishing($c)];
  return ['revision'=>Policy::fingerprint($d),'state'=>$d['receipt']['state'],'target_status'=>$a['status'],'automatic'=>$d['automatic']&&$a['status']==='publish'];
 }
 public static function publishing(array $c): bool {return Policy::allowed($c,'blog')&&empty($c['draft_only'])&&!empty($c['blog_auto_publish'])&&(int)($c['blog_granted_by']??0)===(int)$c['user_id'];}
 public static function automatic(array $c,array $p): bool {return $p['operation']==='blog_create'&&$p['arguments']['status']==='publish'&&self::publishing($c)&&!empty($p['before']['automatic']);}
 public static function apply(array $a,array $c): array {
  self::validate($a);self::snapshot($a,$c);
  if(!current_user_can('edit_posts')||!current_user_can('upload_files')||($a['status']==='publish'&&!current_user_can('publish_posts')))throw new ConnectorError('WordPress article/media permissions missing.');
  $key=self::key($c,$a['request_key']);if(Store::get($key))throw new ConnectorError('Request already attempted; inspect receipt before any retry.');
  $r=['state'=>'running','post_id'=>null,'media_id'=>null,'requested_status'=>$a['status']];Store::put($key,'blog_receipt',$r,true);$tmp=null;
  try{
   $post=wp_insert_post(wp_slash(['post_type'=>'post','post_status'=>'draft','post_title'=>sanitize_text_field($a['title']),'post_content'=>wp_kses_post($a['content']),'post_excerpt'=>sanitize_textarea_field($a['excerpt']??''),'post_author'=>$c['user_id']]),true);
   if(is_wp_error($post)||!$post)throw new ConnectorError('Draft creation failed.');
   $r['post_id']=(int)$post;Store::put($key,'blog_receipt',$r);
   if(get_post($post)->post_status!=='draft')throw new ConnectorError('Unexpected article status; inspect WordPress hooks.');
   require_once ABSPATH.'wp-admin/includes/file.php';require_once ABSPATH.'wp-admin/includes/media.php';require_once ABSPATH.'wp-admin/includes/image.php';
   $tmp=wp_tempnam('nexpilot-cover.webp');if(!$tmp||file_put_contents($tmp,base64_decode($a['image']['base64'],true))===false)throw new ConnectorError('Cover staging failed.');
   $media=media_handle_sideload(['name'=>'nexpilot-'.substr(hash('sha256',$a['request_key']),0,16).'.webp','tmp_name'=>$tmp],$post);
   if(is_wp_error($media)||!$media)throw new ConnectorError('Cover upload failed.');
   $r['media_id']=(int)$media;Store::put($key,'blog_receipt',$r);
   update_post_meta($media,'_wp_attachment_image_alt',sanitize_text_field($a['image']['alt']));
   if(!set_post_thumbnail($post,$media))throw new ConnectorError('Cover assignment failed.');
   if($a['status']==='publish'){$result=wp_update_post(['ID'=>$post,'post_status'=>'publish'],true);if(is_wp_error($result)||!$result)throw new ConnectorError('Publication failed.');}
   if(get_post($post)->post_status!==$a['status']||(int)get_post_thumbnail_id($post)!==(int)$media)throw new ConnectorError('Article verification failed.');
   $r['state']='done';$r['status']=$a['status'];$r['edit_url']=get_edit_post_link($post,'raw');$r['url']=get_permalink($post);Store::put($key,'blog_receipt',$r);return $r;
  }catch(\Throwable $e){$r['state']='uncertain';Store::put($key,'blog_receipt',$r);throw $e;}
  finally{if($tmp&&is_file($tmp))unlink($tmp);}
 }
}
