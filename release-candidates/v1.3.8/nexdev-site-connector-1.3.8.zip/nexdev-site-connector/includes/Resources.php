<?php
namespace Nexdev\SiteConnector;
/** Native WordPress/WooCommerce REST controllers own field validation and permissions. */
final class Resources {
 public static function operations(): array {
  return [
   'content_create'=>['content','POST','/wp/v2/{type}',false],
   'content_delete'=>['content','DELETE','/wp/v2/{type}/{id}',true],
   'order_create'=>['commerce','POST','/wc/v3/orders',false],
   'order_update'=>['commerce','PUT','/wc/v3/orders/{id}',true],
   'order_delete'=>['commerce','DELETE','/wc/v3/orders/{id}',true],
   'product_create'=>['commerce','POST','/wc/v3/products',false],
   'product_delete'=>['commerce','DELETE','/wc/v3/products/{id}',true],
   'product_edit'=>['commerce','PUT','/wc/v3/products/{id}',true],
   'variation_create'=>['commerce','POST','/wc/v3/products/{parent}/variations',false],
   'variation_update'=>['commerce','PUT','/wc/v3/products/{parent}/variations/{id}',true],
   'variation_delete'=>['commerce','DELETE','/wc/v3/products/{parent}/variations/{id}',true],
   'coupon_create'=>['commerce','POST','/wc/v3/coupons',false],
   'coupon_update'=>['commerce','PUT','/wc/v3/coupons/{id}',true],
   'coupon_delete'=>['commerce','DELETE','/wc/v3/coupons/{id}',true],
   'refund_create'=>['maintenance','POST','/wc/v3/orders/{parent}/refunds',false],
   'customer_create'=>['maintenance','POST','/wc/v3/customers',false],
   'customer_update'=>['maintenance','PUT','/wc/v3/customers/{id}',true],
   'customer_delete'=>['accounts_delete','DELETE','/wc/v3/customers/{id}',true],
   'term_create'=>['content','POST','/wp/v2/{taxonomy}',false],
   'term_update'=>['content','POST','/wp/v2/{taxonomy}/{id}',true],
   'term_delete'=>['content','DELETE','/wp/v2/{taxonomy}/{id}',true],
   'media_update'=>['content','POST','/wp/v2/media/{id}',true],
   'media_delete'=>['content','DELETE','/wp/v2/media/{id}',true],
   'user_create'=>['maintenance','POST','/wp/v2/users',false],
   'user_update'=>['maintenance','POST','/wp/v2/users/{id}',true],
   'user_delete'=>['accounts_delete','DELETE','/wp/v2/users/{id}',true],
   'settings_update'=>['maintenance','POST','/wp/v2/settings',true],
   'plugin_install'=>['maintenance','POST','/wp/v2/plugins',false],
   'plugin_update'=>['maintenance','POST','/wp/v2/plugins/{plugin}',true],
   'plugin_delete'=>['maintenance','DELETE','/wp/v2/plugins/{plugin}',true],
  ];
 }
 public static function account_deletion(string $op): bool {return in_array($op,['customer_delete','user_delete'],true);}
 private static function deletable_account(string $op,int $id): \WP_User {
  $user=get_user_by('id',$id);
  if(!$user||$id===get_current_user_id()||is_super_admin($id)||array_intersect(['administrator','shop_manager'],$user->roles)||user_can($user,'manage_options')||user_can($user,'manage_woocommerce')||user_can($user,'edit_users')||user_can($user,'delete_users'))throw new ConnectorError('Account unavailable or protected from connector deletion.');
  if($op==='customer_delete'&&!in_array('customer',$user->roles,true))throw new ConnectorError('The target is not a WooCommerce customer.');
  return $user;
 }
 public static function validate(string $op,array $a): void {
  $def=self::operations()[$op];$keys=['fields'];preg_match_all('/\{(\w+)\}/',$def[2],$m);$keys=array_merge($keys,$m[1]);
  Policy::fields($a,$keys,$keys);
  if(!is_array($a['fields']))throw new ValidationError('fields must be an object.');
  // REST body parameters take precedence over URL captures. Never allow a second target.
  if(array_intersect(array_keys($a['fields']),['id','product_id','order_id','plugin']))throw new ValidationError('Route identifiers must not appear in fields.');
  foreach(['id','parent'] as $key)if(array_key_exists($key,$a))Policy::id($a[$key]);
  if(self::account_deletion($op)){
   Policy::fields($a['fields'],['force','reassign'],['force']);
   if($a['fields']['force']!==true)throw new ValidationError('Permanent deletion requires explicit force: true.');
   if(isset($a['fields']['reassign'])&&Policy::id($a['fields']['reassign'])===$a['id'])throw new ValidationError('Reassignment must target a different account.');
  }
  if(isset($a['type'])&&!in_array($a['type'],['posts','pages'],true))throw new ValidationError('type must be posts or pages.');
  if(isset($a['taxonomy'])&&!in_array($a['taxonomy'],['categories','tags'],true))throw new ValidationError('Unsupported taxonomy.');
  if(isset($a['plugin'])&&!preg_match('~^[a-zA-Z0-9_-]+/[a-zA-Z0-9_.-]+$~D',$a['plugin']))throw new ValidationError('Invalid plugin identifier.');
  if(strlen(Policy::canonical($a))>131072)throw new ValidationError('Operation too large.');
 }
 public static function route(string $op,array $a): string {
  return preg_replace_callback('/\{(\w+)\}/',static fn($m)=>(string)$a[$m[1]],self::operations()[$op][2]);
 }
 public static function request(string $method,string $route,array $params=[]): array {
  $data=self::native_response($method,$route,$params)->get_data();
  return is_array($data)?$data:['value'=>$data];
 }
 private static function native_response(string $method,string $route,array $params,bool $allowPageError=false): \WP_REST_Response {
  $req=new \WP_REST_Request($method,$route);$req->set_body_params($params);
  if($method==='GET')$req->set_query_params($params);
  $res=rest_do_request($req);
  if($res->is_error()||$res->get_status()>=400){
   $error=$res->get_data();
   if(!$allowPageError||($error['code']??null)!=='rest_post_invalid_page_number')throw new ConnectorError('Native API rejected operation. Verify fields and permissions.');
  }
  return $res;
 }
 public static function product_collection(array $params): array {
  $response=self::native_response('GET','/wc/v3/products',$params+['_fields'=>'id']);
  $headers=array_change_key_case($response->get_headers(),CASE_LOWER);
  return ['items'=>$response->get_data(),'total'=>(int)($headers['x-wp-total']??0)];
 }
 public static function snapshot(string $op,array $a): array {
  $def=self::operations()[$op];
  if(self::account_deletion($op)){
   $user=self::deletable_account($op,$a['id']);
   $data=self::account_read(self::route($op,$a),[],$op==='customer_delete');
   $data['roles']=array_values($user->roles);
   return ['data'=>$data,'revision'=>Policy::fingerprint($data)];
  }
  $data=$def[3]?self::request('GET',self::route($op,$a),['context'=>'edit']):null;
  // Creating refunds/variations must also bind approval to the current parent state.
  if(in_array($op,['refund_create','variation_create'],true))$data=self::request('GET','/wc/v3/'.($op==='refund_create'?'orders':'products').'/'.$a['parent'],['context'=>'edit']);
  return ['data'=>$data,'revision'=>Policy::fingerprint($data)];
 }
 public static function apply(string $op,array $a): array {
  self::validate($op,$a);
  if(self::account_deletion($op))self::deletable_account($op,$a['id']);
  $result=self::request(self::operations()[$op][1],self::route($op,$a),$a['fields']);
  if(self::account_deletion($op))return ['id'=>$a['id'],'deleted'=>true];
  return self::redact($result);
 }
 public static function redact(array $data): array {
  foreach($data as $k=>&$v){
   if(preg_match('/password|secret|token|application_password/i',(string)$k))$v='[REDACTED]';
   elseif(is_array($v))$v=self::redact($v);
  }return $data;
 }
 /** Commerce-scope reads must not expose customer personal data (billing, shipping, IP, notes, coupon e-mail lists). */
 public static function redact_pii(array $data): array {
  foreach($data as $k=>&$v){
   if(is_string($k)&&preg_match('/^(billing|shipping|customer_ip_address|customer_user_agent|customer_note|email_restrictions|used_by|order_key|payment_url|transaction_id|meta_data)$/D',$k))$v='[REDACTED: customer data]';
   elseif(is_array($v))$v=self::redact_pii($v);
  }return $data;
 }
 public static function read(array $client,string $route,array $params): array {
  // No arbitrary plugin routes: a GET route is not necessarily side-effect-free.
  if($route==='/wp/v2/plugins'&&(Policy::allowed($client,'site_inspection')||!Policy::allowed($client,'maintenance'))){
   Policy::require_scope($client,'site_inspection');
   Policy::fields($params,['search','status','orderby','order','fields','page','per_page']);
   $columns=['plugin','name','status','version'];
   $fields=array_fill_keys($columns,true);
   $native=array_intersect_key($params,['search'=>true]);
   $data=array_map(static fn(array $plugin)=>array_intersect_key($plugin,$fields),self::request('GET',$route,$native+['_fields'=>implode(',',$columns)]));
   $controls=array_diff_key($params,['search'=>true]);
   $list=Tools::list_rows($data,$controls,$columns,$columns,['plugin','name'],['status'],'plugin');
   return ['data'=>$controls?$list['items']:$data,'revision'=>Policy::fingerprint($controls?$list['items']:$data)]+$list;
  }
  if(preg_match('~^/(?:wp/v2/users|wc/v3/customers)(?:/[1-9][0-9]*)?$~D',$route)&&(Policy::allowed($client,'accounts_read')||!Policy::allowed($client,'maintenance'))){
   Policy::require_scope($client,'accounts_read');
   $woo=str_starts_with($route,'/wc/');
   if(ctype_digit(basename($route))){
    $data=self::account_read($route,$params,$woo);
    return ['data'=>$data,'revision'=>Policy::fingerprint($data)];
   }
   Policy::fields($params,self::USER_QUERY_KEYS);
   if($woo){
    if(!function_exists('wc_get_orders'))throw new ConnectorError('WooCommerce is unavailable.');
    if(isset($params['role'])&&$params['role']!=='customer')throw new ValidationError('The customers route only lists customer accounts.');
    $params['role']='customer';
   }
   $list=self::users_query($client,$params+['orderby'=>'id','order'=>'asc','fields'=>$woo?'id,first_name,last_name,orders_count':'id,name,first_name,last_name,roles']);
   return ['data'=>$list['items'],'revision'=>Policy::fingerprint($list['items'])]+$list;
  }
  if(preg_match('~^/wp/v2/(posts|pages|categories|tags|media|blocks|block-types|templates|template-parts)(/[a-zA-Z0-9_./%-]+)?$~D',$route))Policy::require_scope($client,'read');
  elseif(preg_match('~^/wc/v3/(products|orders|coupons)(/[a-zA-Z0-9_/-]+)?$~D',$route))Policy::require_scope($client,'commerce');
  elseif(preg_match('~^/wp/v2/(users|settings|plugins|themes)(/[a-zA-Z0-9_./%-]+)?$~D',$route)||preg_match('~^/wc/v3/customers(/[0-9]+)?$~D',$route))Policy::maintenance($client);
  else throw new ValidationError('Route is not in the native read allowlist.');
  if(str_contains($route,'..')||str_contains($route,'%'))throw new ValidationError('Ambiguous route.');
  if(($route==='/wp/v2/media'&&array_key_exists('empty_alt',$params))||($route==='/wc/v3/coupons'&&array_key_exists('expired_before',$params))){
   $list=BulkChanges::collection($route==='/wp/v2/media'?'media_bulk_update':'coupons_delete',$params);
   return ['data'=>$list['items'],'revision'=>Policy::fingerprint($list['items'])]+$list;
  }
  $unpaged=match(true){
   preg_match('~^/wp/v2/block-types(?:/[a-z0-9-]+)?$~D',$route)===1=>['name','title'],
   $route==='/wp/v2/themes'=>['stylesheet','name'],
   in_array($route,['/wp/v2/templates','/wp/v2/template-parts'],true)=>['id','slug','title'],
   $route==='/wp/v2/plugins'=>['plugin','name','status','version'],
   default=>null,
  };
  if($unpaged!==null){
   $controls=array_intersect_key($params,array_fill_keys(['fields','search','orderby','order','page','per_page'],true));
   if($route==='/wp/v2/plugins')unset($controls['search']);
   $out=self::redact(self::request('GET',$route,array_diff_key($params,$controls)));
   if(array_is_list($out)&&!array_filter($out,static fn($row)=>!is_array($row))){
    $columns=$unpaged;
    foreach($out as $row)$columns=array_merge($columns,array_keys($row));
    $columns=array_values(array_unique($columns));
    $list=Tools::list_rows($out,$controls,$columns,$unpaged,$unpaged,[],$unpaged[0]);
    $data=$controls?$list['items']:$out;
    return ['data'=>$data,'revision'=>Policy::fingerprint($data)]+$list;
   }
  }
  // Native controllers validate route-specific filters. Project only after redaction.
  $fields=$params['fields']??null;
  unset($params['fields']);
  if($fields!==null&&(!is_string($fields)||strlen($fields)>500||!preg_match('/^[a-zA-Z0-9_ -]+(?:,[a-zA-Z0-9_ -]+)*$/D',$fields)))throw new ValidationError('fields must be comma-separated field names.');
  $page=Policy::id($params['page']??1);
  $limit=min(100,Policy::id($params['per_page']??20));
  $params['per_page']=$limit;
  $response=self::native_response('GET',$route,$params,$page>1);
  if($response->is_error()){
   $params['page']=1;
   $first=self::native_response('GET',$route,$params);
   $headers=array_change_key_case($first->get_headers(),CASE_LOWER);
   $total=(int)($headers['x-wp-total']??0);
   if($page<=ceil($total/$limit))throw new ConnectorError('Native list changed during pagination. Read the page again.');
   return ['data'=>[],'revision'=>Policy::fingerprint([])]+Tools::pagination(['per_page'=>$limit],[],$total,$page,$limit);
  }
  $data=$response->get_data();
  if(!is_array($data))$data=['value'=>$data];
  $out=self::redact($data);
  if(preg_match('~^/wc/v3/(orders|coupons)~',$route))$out=self::redact_pii($out);
  $headers=array_change_key_case($response->get_headers(),CASE_LOWER);
  $isCollection=isset($headers['x-wp-total'])&&array_is_list($out);
  if($fields!==null){
   $selected=array_fill_keys(array_map('trim',explode(',',$fields)),true);
   $out=$isCollection?array_map(static fn(array $row)=>array_intersect_key($row,$selected),$out):array_intersect_key($out,$selected);
  }
  $result=['data'=>$out,'revision'=>Policy::fingerprint($data)];
  return $isCollection?$result+Tools::pagination(['per_page'=>$limit],$out,(int)$headers['x-wp-total'],$page,$limit):$result;
 }
 public static function plugins_list(): array {
  require_once ABSPATH.'wp-admin/includes/plugin.php';
  $updates=get_site_transient('update_plugins');$auto=(array)get_site_option('auto_update_plugins',[]);$items=[];
  foreach(get_plugins() as $file=>$plugin){
   $update=$updates->response[$file]??null;
   $items[]=['plugin'=>$file,'name'=>$plugin['Name'],'status'=>is_plugin_active_for_network($file)?'network-active':(is_plugin_active($file)?'active':'inactive'),'version'=>$plugin['Version'],'update_available'=>is_object($update),'new_version'=>$update->new_version??null,'requires_php'=>$update->requires_php??($plugin['RequiresPHP']??''),'auto_update'=>in_array($file,$auto,true),'folder_ok'=>!str_contains($file,'\\')&&is_file(WP_PLUGIN_DIR.'/'.$file)];
  }
  $issues=[];
  foreach(new \DirectoryIterator(WP_PLUGIN_DIR) as $entry){
   if($entry->isDot()||$entry->isLink())continue;
   if(str_contains($entry->getFilename(),'\\')){$issues[]=$entry->getFilename();continue;}
   if(!$entry->isDir()||!is_readable($entry->getPathname()))continue;
   $checked=0;
   foreach(new \DirectoryIterator($entry->getPathname()) as $child){
    if(++$checked>200)break;
    if(str_contains($child->getFilename(),'\\')){$issues[]=$entry->getFilename();break;}
   }
  }
  $issues=array_values(array_unique($issues));
  foreach($items as &$item)if(in_array(explode('/',$item['plugin'],2)[0],$issues,true))$item['folder_ok']=false;
  unset($item);
  return ['items'=>$items,'total'=>count($items),'folders_with_invalid_names'=>$issues];
 }
 public static function themes_list(): array {
  $updates=get_site_transient('update_themes');$items=[];
  foreach(wp_get_themes() as $slug=>$theme){
   $update=$updates->response[$slug]??null;
   $items[]=['theme'=>$slug,'name'=>$theme->get('Name'),'version'=>$theme->get('Version'),'active'=>$slug===get_stylesheet(),'parent'=>$theme->parent()?$theme->get_template():null,'update_available'=>is_array($update),'new_version'=>$update['new_version']??null];
  }
  return $items;
 }
 public const USER_QUERY_KEYS=['registered_after','registered_before','email_glob','role','has_orders','has_name','orderby','order','search','fields','page','per_page'];
 private const USER_FIELDS=['id','name','first_name','last_name','registered','roles','orders_count','email'];
 public static function users_query(array $client,array $args): array {
  if(!current_user_can('list_users'))throw new ConnectorError('WordPress does not permit listing users.');
  foreach(['registered_after','registered_before','email_glob','role','orderby','order','search','fields'] as $key){
   if(array_key_exists($key,$args)&&!is_string($args[$key]))throw new ValidationError('Invalid account query text.');
  }
  foreach(['has_orders','has_name'] as $key){
   if(array_key_exists($key,$args)&&!is_bool($args[$key]))throw new ValidationError('Invalid account query flag.');
  }
  $page=min(10000,Policy::id($args['page']??1));$limit=min(100,Policy::id($args['per_page']??20));
  $orderby=$args['orderby']??'registered';
  if(!in_array($orderby,['id','registered','name'],true))throw new ValidationError('Unsupported user ordering.');
  $order=strtoupper($args['order']??($orderby==='registered'?'desc':'asc'));
  if(!in_array($order,['ASC','DESC'],true))throw new ValidationError('Order must be asc or desc.');
  $fields=Tools::fields_selection($args['fields']??null,self::USER_FIELDS,array_values(array_diff(self::USER_FIELDS,['name'])));
  $sort=['registered'=>'registered','name'=>'display_name','id'=>'ID'][$orderby];
  $query=['number'=>$limit,'paged'=>$page,'count_total'=>true,'orderby'=>[$sort=>$order,'ID'=>$order]];
  if(isset($args['role'])){
   if(!wp_roles()->is_role($args['role']))throw new ValidationError('Unknown site role.');
   $query['role']=$args['role'];
  }
  foreach(['registered_after'=>'after','registered_before'=>'before'] as $input=>$key)if(isset($args[$input])){
   $value=$args[$input];
   $format=strlen($value)===10?'Y-m-d':'Y-m-d\TH:i:s\Z';
   $parsed=\DateTimeImmutable::createFromFormat('!'.$format,$value,new \DateTimeZone('UTC'));
   if(!$parsed||$parsed->format($format)!==$value)throw new ValidationError('Registration dates must use YYYY-MM-DD or YYYY-MM-DDTHH:MM:SSZ.');
   $query['date_query'][0][$key]=strlen($value)===10?$value:$parsed->format('Y-m-d H:i:s');
   $query['date_query'][0]['inclusive']=true;
  }
  if(isset($args['registered_after'],$args['registered_before'])&&$args['registered_after']>$args['registered_before'])throw new ValidationError('The registration date range is reversed.');
  if(isset($args['search'],$args['email_glob']))throw new ValidationError('Use either search or email_glob.');
  if(isset($args['search'])){
   if(trim($args['search'])===''||strlen($args['search'])>200)throw new ValidationError('Account search must be 1 to 200 bytes.');
   $query['search']='*'.$args['search'].'*';$query['search_columns']=['display_name'];
  }
  if(isset($args['email_glob'])){
   $pattern=$args['email_glob'];
   if(strlen($pattern)>200||!preg_match('/^\*?[A-Za-z0-9._+@-]+\*?$/D',$pattern))throw new ValidationError('Email search accepts plain text and optional * at either end.');
   $query['search']=$pattern;$query['search_columns']=['user_email'];
  }
  if(isset($args['has_name'])){
   $query['meta_query']=['relation'=>$args['has_name']?'OR':'AND'];
   foreach(['first_name','last_name'] as $key){
    $query['meta_query'][]=$args['has_name']?['key'=>$key,'value'=>'','compare'=>'!=']:['relation'=>'OR',['key'=>$key,'compare'=>'NOT EXISTS'],['key'=>$key,'value'=>'']];
   }
  }
  $woo=function_exists('wc_get_orders');
  $result=new \WP_User_Query();
  if(isset($args['has_orders'])){
   if(!$woo)throw new ConnectorError('WooCommerce is required to filter by order history.');
   $predicate=self::order_history_predicate($args['has_orders']);
   $filter=static function(\WP_User_Query $candidate)use($result,$predicate): void {
    if($candidate===$result)$candidate->query_where.=' AND '.$predicate;
   };
   add_action('pre_user_query',$filter);
   try{$result->prepare_query($query);$result->query();}
   finally{remove_action('pre_user_query',$filter);}
  }else{$result->prepare_query($query);$result->query();}
  global $wpdb;
  if($wpdb->last_error)throw new ConnectorError('Account query failed.');
  $show_email=Policy::allowed($client,'accounts_email');$items=[];
  foreach($result->get_results() as $user){
   $row=['id'=>$user->ID,'name'=>$user->display_name,'first_name'=>$user->first_name,'last_name'=>$user->last_name,'registered'=>$user->user_registered,'roles'=>array_values($user->roles),'email'=>$show_email?$user->user_email:($user->user_email!==''?'***@***':null)];
   if(isset($fields['orders_count']))$row['orders_count']=$woo?self::customer_order_count((int)$user->ID):null;
   $items[]=array_intersect_key($row,$fields);
  }
  $total=(int)$result->get_total();
  return Tools::pagination(['per_page'=>$limit],$items,$total,$page,$limit);
 }
 private static function order_history_predicate(bool $has_orders): string {
  global $wpdb;
  // Include all order statuses for history, including trash. Refund rows are not orders.
  $hpos=class_exists(\Automattic\WooCommerce\Utilities\OrderUtil::class)&&\Automattic\WooCommerce\Utilities\OrderUtil::custom_orders_table_usage_is_enabled();
  $exists=$hpos
   ?$wpdb->prepare("SELECT 1 FROM %i AS nsc_orders WHERE nsc_orders.customer_id = {$wpdb->users}.ID AND nsc_orders.type = %s",$wpdb->prefix.'wc_orders','shop_order')
   :$wpdb->prepare("SELECT 1 FROM %i AS nsc_orders JOIN %i AS nsc_owner ON nsc_owner.post_id = nsc_orders.ID WHERE nsc_orders.post_type = %s AND nsc_owner.meta_key = %s AND nsc_owner.meta_value = CAST({$wpdb->users}.ID AS CHAR)",$wpdb->posts,$wpdb->postmeta,'shop_order','_customer_user');
  return ($has_orders?'EXISTS':'NOT EXISTS').' ('.$exists.')';
 }
 public static function users_delete_preview(array $client,array $args): array {
  if(array_key_exists('ids',$args)===array_key_exists('filter',$args))throw new ValidationError('Supply exactly one of ids or filter.');
  $cap=Bulk::limits($client)['per_batch'];
  $ids=array_key_exists('ids',$args)?$args['ids']:[];
  if(!is_array($ids)||!array_is_list($ids))throw new ValidationError('ids must be a list of account IDs.');
  if(array_key_exists('filter',$args)){
   Policy::require_scope($client,'accounts_read');
   $filter=$args['filter'];
   if(!is_array($filter)||!$filter)throw new ValidationError('Account deletion preview requires a nonempty filter.');
   Policy::fields($filter,['registered_after','registered_before','email_glob','role','has_orders','has_name','search']);
   $page=1;
   do {
    $matches=self::users_query($client,$filter+['fields'=>'id','per_page'=>min(100,$cap),'orderby'=>'id','page'=>$page]);
    if($matches['total']>$cap)throw new ValidationError('Account deletion preview cap is '.$cap.' accounts per batch.');
    $ids=array_merge($ids,array_column($matches['items'],'id'));
    $page=$matches['next'];
   }while($page!==null);
   if(count($ids)!==$matches['total']||count($ids)!==count(array_unique($ids)))throw new ConnectorError('Account selection changed. Run the dry run again.');
  }
  if(count($ids)>$cap)throw new ValidationError('Account deletion preview cap is '.$cap.' accounts per call.');
  if(isset($args['ids'])&&!$ids)throw new ValidationError('Select at least one exact account ID.');
  foreach($ids as $id)Policy::id($id);
  if(count($ids)!==count(array_unique($ids)))throw new ValidationError('Account IDs must be unique.');
  sort($ids,SORT_NUMERIC);$eligible=[];$skipped=[];
  foreach($ids as $id){
   $item=self::account_delete_item($client,$id);
   if(isset($item['reason']))$skipped[]=$item;
   else $eligible[]=$item;
  }
  $byId=array_column(array_merge($eligible,$skipped),null,'id');
  $sample=array_map(static fn($id)=>array_diff_key($byId[$id],['revision'=>true]),array_slice($ids,0,5));
  return ['dry_run'=>true,'count'=>count($ids),'sample'=>$sample,'batch_hash'=>Policy::fingerprint($ids),'reversible'=>false,'eligible'=>$eligible,'skipped'=>$skipped];
 }
 public static function account_delete_item(array $client,int $id): array {
  clean_user_cache($id);
  $user=get_user_by('id',$id);
  if($id===(int)$client['user_id'])return ['id'=>$id,'reason'=>'Account owns this connection.'];
  if(!$user)return ['id'=>$id,'reason'=>'Account does not exist.'];
  if(is_super_admin($id)||array_intersect(['administrator','shop_manager'],$user->roles)||user_can($user,'manage_options')||user_can($user,'manage_woocommerce')||user_can($user,'edit_users')||user_can($user,'delete_users'))return ['id'=>$id,'reason'=>'Account has a protected role or capability.'];
  if(function_exists('wc_get_orders')&&self::has_order_history($id))return ['id'=>$id,'reason'=>'Account has WooCommerce orders.'];
  if(!current_user_can('delete_user',$id))return ['id'=>$id,'reason'=>'WordPress does not allow the owner to delete this account.'];
  $data=['id'=>$id,'name'=>$user->display_name,'first_name'=>$user->first_name,'last_name'=>$user->last_name,'registered'=>$user->user_registered,'roles'=>array_values($user->roles)];
  return $data+['revision'=>Policy::fingerprint([$data,$user->user_login,$user->user_email])];
 }
 private static function has_order_history(int $id): bool {
  global $wpdb;
  $predicate=self::order_history_predicate(true);
  $match=$wpdb->get_var($wpdb->prepare("SELECT ID FROM {$wpdb->users} WHERE ID = %d AND ".$predicate,$id));
  if($wpdb->last_error)throw new \RuntimeException('Account order history could not be verified.');
  return $match!==null;
 }
 private static function customer_order_count(int $id): int {
  $orders=wc_get_orders(['customer_id'=>$id,'limit'=>1,'paginate'=>true,'return'=>'ids','type'=>'shop_order']);
  return (int)$orders->total;
 }
 private static function account_read(string $route,array $query,bool $woo): array {
  Policy::fields($query,[]);
  $fields=$woo?['id','first_name','last_name']:['id','name','first_name','last_name','roles'];
  $params=['context'=>'edit','_fields'=>implode(',',$fields)];
  if($woo&&!function_exists('wc_get_orders'))throw new ConnectorError('WooCommerce is unavailable.');
  $data=self::request('GET',$route,$params);
  $project=static function(array $account)use($woo,$fields): array {
   $account=array_intersect_key($account,array_flip($fields));
   if($woo){
    $account['orders_count']=self::customer_order_count(Policy::id($account['id']??null));
   }
   return $account;
  };
  return $project($data);
 }
}
