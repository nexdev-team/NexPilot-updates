<?php
namespace Nexdev\SiteConnector;

/** Core WordPress object-cache invalidation. Provider/CDN caches have separate semantics. */
final class CacheBatch {
 private const GROUPS=['posts','post_meta','post-queries','terms','term_meta','term-queries','general'];
 public static function select(array $client,array $args): array {
  if(array_key_exists('ids',$args)===array_key_exists('filter',$args))throw new ValidationError('Supply exactly one of ids or filter.');
  if(array_key_exists('ids',$args)){
   $ids=$args['ids'];
   if(!is_array($ids)||!array_is_list($ids)||!$ids)throw new ValidationError('Select exact post IDs.');
   foreach($ids as $id)Policy::id($id);
  }else{
   $filter=$args['filter'];
   if(!is_array($filter))throw new ValidationError('Cache filter must be an object.');
   Policy::fields($filter,['urls','all']);
   if($filter===['all'=>true])return ['all'];
   if(array_keys($filter)!==['urls']||!is_array($filter['urls'])||!array_is_list($filter['urls'])||!$filter['urls'])throw new ValidationError('Select a nonempty URL list or all.');
   if(count($filter['urls'])>Bulk::limits($client)['per_batch'])throw new ValidationError('URL count exceeds the bulk cap.');
   $ids=[];
   foreach($filter['urls'] as $url)$ids[]=self::url_id($url);
  }
  $cap=Bulk::limits($client)['per_batch'];
  if(count($ids)>$cap)throw new ValidationError('Cache purge cap is '.$cap.' items per batch.');
  if(count($ids)!==count(array_unique($ids)))throw new ValidationError('Select each cache target only once.');
  sort($ids,SORT_NUMERIC);
  return $ids;
 }
 private static function url_id(mixed $url): int {
  if(!is_string($url)||strlen($url)>2048||preg_match('/[[:space:]\\\\]/',$url))throw new ValidationError('Invalid cache target URL.');
  $parts=wp_parse_url($url);$home=wp_parse_url(home_url('/'));
  if(!$parts||!isset($parts['scheme'],$parts['host'])||isset($parts['user'])||isset($parts['pass'])||isset($parts['fragment']))throw new ValidationError('Use absolute site URLs without credentials or fragments.');
  foreach(['scheme','host','port'] as $key)if(strtolower((string)($parts[$key]??''))!==strtolower((string)($home[$key]??'')))throw new ValidationError('Cache URL must use the current site origin.');
  $id=url_to_postid($url);
  if(!$id)throw new ValidationError('Cache URL must resolve to a WordPress post or page.');
  return $id;
 }
 public static function current(int|string $id): ?array {
  if($id==='all'){
   if(is_multisite()||!wp_cache_supports('flush_group')||(wp_using_ext_object_cache()&&(!defined('NSC_OBJECT_CACHE_SITE_ISOLATED')||NSC_OBJECT_CACHE_SITE_ISOLATED!==true)))return null;
   return ['backend'=>'wordpress_object_cache','groups'=>self::GROUPS];
  }
  $post=get_post($id);
  return $post&&is_post_publicly_viewable($post)&&current_user_can('edit_post',$id)?['backend'=>'wordpress_object_cache','post_id'=>$id,'permalink'=>get_permalink($id)]:null;
 }
 public static function target(int|string $id): array {
  $state=self::current($id);
  if(!$state)return ['id'=>$id,'reason'=>'Object cache target is unavailable or the cache backend is not site-isolated.'];
  return ['id'=>$id,'before'=>$state,'after'=>[],'revision'=>Policy::fingerprint($state)];
 }
 public static function apply(int|string $id): bool {
  if(!self::current($id))return false;
  if($id==='all'){
   $ok=true;
   foreach(self::GROUPS as $group)if(!wp_cache_flush_group($group))$ok=false;
   return $ok;
  }
  if(!empty($GLOBALS['_wp_suspend_cache_invalidation']))return false;
  clean_post_cache($id);
  return true;
 }
}
