<?php
namespace Nexdev\SiteConnector;
final class Admin {
 private const SCOPE_LABELS=['content'=>'Edit content','commerce'=>'WooCommerce operations','accounts_read'=>'Read WooCommerce customers and WordPress users','accounts_email'=>'Show full email addresses in account queries (also requires account read access)','accounts_delete'=>'Propose account deletions (each requires owner approval)','site_maintenance'=>'Propose public site maintenance changes (owner approval required)','site_inspection'=>'Inspect plugins, Flatsome UX Blocks and theme/plugin source (source may contain secrets)','maintenance'=>'Allow temporary full maintenance'];
 public static function enqueue(string $hook): void {
  if ($hook !== 'tools_page_nsc' || !current_user_can('manage_options')) return;
  Setup::enqueue();
  wp_enqueue_script('nsc-blocks-review', plugins_url('../assets/blocks-review.js', __FILE__), [], NSC_VERSION, true);
  wp_add_inline_script('nsc-blocks-review', 'window.nscBlocksEditor=' . wp_json_encode(admin_url('post.php')) . ';', 'before');
 }
 public static function notices(): void {
  if(!current_user_can('manage_options'))return;
  $count=0;foreach(Store::all('proposal') as $p)if(($p['state']??'')==='pending'&&$p['expires']>time())$count++;
  if($count)echo '<div class="notice notice-info"><p>'.esc_html($count.' NexPilot changes await review.').' <a href="'.esc_url(admin_url('tools.php?page=nsc&tab=proposals')).'">Review proposed changes</a></p></div>';
 }
 public static function menu(): void {add_management_page('NexPilot','NexPilot','manage_options','nsc',[self::class,'page']);}
 private static function guard(): void {if(!current_user_can('manage_options'))wp_die('Administrator access required.',403);}
 public static function form(string $action,string $id='',string $button='Submit'): void {
  echo '<form method="post" action="'.esc_url(admin_url('admin-post.php')).'" style="display:inline-block;margin:4px">';
  wp_nonce_field('nsc_action');echo '<input type="hidden" name="action" value="nsc_action"><input type="hidden" name="operation" value="'.esc_attr($action).'"><input type="hidden" name="id" value="'.esc_attr($id).'">';
  submit_button($button,'secondary','submit',false);echo '</form>';
 }
 public static function page(): void {
  self::guard();
  echo '<style>.wrap pre{max-width:100%;overflow:auto;white-space:pre-wrap;overflow-wrap:anywhere}.wrap code{overflow-wrap:anywhere}.wrap input{max-width:100%}.wrap details{box-sizing:border-box;min-width:0}.wrap form{max-width:100%}</style>';
  echo '<div class="wrap"><h1>NexPilot <small>'.esc_html(NSC_VERSION).'</small></h1><div class="notice notice-warning inline"><p>Signed public updates. Validate each site in staging before deployment. Full maintenance grants unrestricted WordPress access.</p></div>';
  $tabs = ['setup'=>'Set up a connection', 'connections'=>'Connections', 'proposals'=>'Proposed changes', 'activity'=>'Activity', 'settings'=>'Advanced settings'];
  $requested = $_GET['tab'] ?? 'setup';
  $tab = is_string($requested) && isset($tabs[$requested]) ? $requested : 'setup';
  echo '<nav class="nav-tab-wrapper nsc-tabs" aria-label="NexPilot sections">';
  foreach ($tabs as $key=>$label) {
   echo '<a class="nav-tab'.($key===$tab?' nav-tab-active':'').'" '.($key===$tab?'aria-current="page" ':'').'href="'.esc_url(admin_url('tools.php?page=nsc&tab='.$key)).'">'.esc_html($label).'</a>';
  }
  echo '</nav><div class="nsc-panel">';
  if ($tab === 'setup') Setup::render();
  elseif ($tab === 'connections') self::connections();
  elseif ($tab === 'proposals') self::proposals();
  elseif ($tab === 'activity') self::activity();
  else self::settings();
  echo '</div></div>';
 }
 public static function create_connection(): void {
  echo '<h4 id="nsc-create">Create connection</h4><form method="post" action="'.esc_url(admin_url('admin-post.php')).'">';wp_nonce_field('nsc_action');
  echo '<input type="hidden" name="action" value="nsc_action"><input type="hidden" name="operation" value="create"><label>Connection name <input id="nsc-client-label" required maxlength="80" name="label" placeholder="My AI tool"></label><p>Read access is included.</p>';
  foreach(self::SCOPE_LABELS as $v=>$label)echo '<label style="display:block"><input type="checkbox" name="scopes[]" value="'.esc_attr($v).'">'.esc_html($label).'</label>';
  echo '<p><label><input type="checkbox" name="draft_only" value="1" checked> Draft-only: edit drafts and create draft copies; publishing and other writes are blocked.</label></p>';
  self::access_mode_fields();
  submit_button('Generate connection key');echo '</form>';
 }
 private static function access_mode_fields(bool $full=false): void {
  echo '<fieldset><legend><strong>Approval mode</strong></legend><p><label><input type="radio" name="approval_mode" value="manual"'.($full?'':' checked').'> With approvals — review every change in WordPress</label><br><label><input type="radio" name="approval_mode" value="full"'.($full?' checked':'').'> Full access — no approval for each change during the selected period</label></p>';
  echo '<label>Full access duration <select name="approval_duration">'.($full?'<option value="keep" selected>Keep current expiration</option>':'').'<option value="10">10 minutes</option><option value="60"'.($full?'':' selected').'>1 hour</option><option value="480">8 hours</option><option value="expiry">Until this connection expires</option></select></label><p class="description">Full access permits changes within the selected scopes without individual review, including code, files and SQL when maintenance is allowed. Choose only for a trusted client. Activity is recorded. Only the connection owner can change this mode; expiry returns to approvals. Draft-only must be off. Full mode uses server block validation without a native editor review.</p></fieldset>';
 }
 private static function access_settings(bool $allow_keep=false): array {
  $mode=$_POST['approval_mode']??'manual';$duration=$_POST['approval_duration']??'60';
  if(!is_string($mode)||!in_array($mode,['manual','full'],true)||!is_string($duration)||(!in_array($duration,['10','60','480','expiry'],true)&&!($allow_keep&&$duration==='keep')))throw new ValidationError('Invalid approval mode or duration.');
  return [$mode,$duration];
 }
 private static function set_access_mode(array $record,string $mode,string $duration): array {
  Policy::require_scope($record,'read');
  if((int)$record['user_id']!==get_current_user_id())throw new ConnectorError('Only the connection owner can change its approval mode.');
  $record=self::approval_record($record,$mode,$duration);
  Access::revoke_sessions($record['id']);
  Store::audit('human:'.get_current_user_id(),'approval_mode.'.$mode,$record['id']);
  Store::put($record['id'],'client',$record);return $record;
 }
 private static function approval_record(array $record,string $mode,string $duration): array {
  if($mode==='full'){
   if(!empty($record['draft_only'])||!array_intersect(['content','commerce','maintenance'],$record['scopes']))throw new ConnectorError('Full access needs a write scope and Draft-only off.');
   $record['approval_mode']='full';$record['approval_grant']=bin2hex(random_bytes(16));$record['approval_granted_by']=get_current_user_id();
   if($duration!=='keep'){
    $record['approval_until']=min($record['expires'],$duration==='expiry'?$record['expires']:time()+(int)$duration*60);
    if(in_array('maintenance',$record['scopes'],true))$record['maintenance_until']=$record['approval_until'];
   }
  }else{$record['approval_mode']='manual';$record['approval_until']=0;$record['approval_grant']='';$record['maintenance_until']=0;}
  return $record;
 }
 private static function connections(): void {
  echo '<section class="nsc-step"><h2>Connections</h2><p>Each AI tool has its own access, credential and expiry. Credentials expire after 30 days.</p>';
  echo '<p><a class="button button-primary" href="'.esc_url(admin_url('tools.php?page=nsc&tab=setup#nsc-create')).'">Add a connection</a></p>';
  $connections=Store::all('client');
  if(!$connections)echo '<p>No connections yet. Use the setup guide to create your first connection.</p>';
  $receipt=$_GET['nsc_permission_result']??'';
  $feedback=is_string($receipt)&&preg_match('/^[a-f0-9]{24}$/D',$receipt)?get_transient('nsc_permissions_'.get_current_user_id().'_'.$receipt):false;
  foreach($connections as $c){
   echo '<div class="nsc-connection" id="nsc-connection-'.esc_attr($c['id']).'"><strong>'.esc_html($c['label']).'</strong> <code>'.esc_html($c['id']).'</code><p>'.esc_html(implode(', ',$c['scopes'])).' | '.esc_html($c['revoked']?'Revoked':'Expires '.gmdate('Y-m-d H:i',$c['expires']).' UTC').'</p>';
   if(is_array($feedback)&&$feedback['id']===$c['id']){
    echo '<div role="'.($feedback['ok']?'status':'alert').'" class="notice notice-'.($feedback['ok']?'success':'error').' inline"><p>'.esc_html($feedback['message']).'</p></div>';
   }
   if(!$c['revoked']){
    $full=Policy::full_access($c);$oauth=!empty($c['oauth_only']);
    echo '<p>Write policy: '.esc_html(!empty($c['draft_only'])?'Draft-only':'Live changes allowed within permissions').'</p>';
    echo '<p><strong>Approval mode: '.esc_html($full?'Full access until '.gmdate('Y-m-d H:i',$c['approval_until']).' UTC':'With approvals').'</strong></p>';
    if(!$oauth)self::form('rotate',$c['id'],'Rotate credential');
    self::form('revoke',$c['id'],'Revoke connection');
    if(in_array('maintenance',$c['scopes'],true)){
     self::form('open',$c['id'],'Open full maintenance for 10 minutes');self::form('close',$c['id'],'Close maintenance');
     echo '<p>Maintenance until: '.esc_html($c['maintenance_until']?gmdate('Y-m-d H:i:s',$c['maintenance_until']).' UTC':'closed').'</p>';
    }
    if((int)$c['user_id']===get_current_user_id()&&Policy::allowed($c,'read')){
     self::connection_permissions_form($c,$full,$oauth);
     if(array_intersect(['accounts_delete','commerce','content'],$c['scopes']))self::bulk_limits_form($c);
    }
   }
   echo '</div>';
  }
  echo '</section>';
 }
 private static function bulk_limits_form(array $client): void {
  $limits=Bulk::limits($client);
  echo '<details><summary>Bulk operation limits</summary><form method="post" action="'.esc_url(admin_url('admin-post.php')).'">';
  wp_nonce_field('nsc_action');
  echo '<input type="hidden" name="action" value="nsc_action"><input type="hidden" name="operation" value="bulk_limits"><input type="hidden" name="id" value="'.esc_attr($client['id']).'">';
  echo '<p><label>Items per batch <input required type="number" name="per_batch" min="1" max="1000" value="'.esc_attr((string)$limits['per_batch']).'"></label></p>';
  echo '<p><label>Items per rolling hour <input required type="number" name="per_hour" min="1" max="10000" value="'.esc_attr((string)$limits['per_hour']).'"></label></p>';
  submit_button('Save bulk limits','secondary');echo '</form></details>';
 }
 private static function connection_permissions_form(array $c,bool $full,bool $oauth): void {
  echo '<form method="post" action="'.esc_url(admin_url('admin-post.php')).'">';wp_nonce_field('nsc_action');
  echo '<input type="hidden" name="action" value="nsc_action"><input type="hidden" name="operation" value="connection_permissions"><input type="hidden" name="id" value="'.esc_attr($c['id']).'"><input type="hidden" name="permission_revision" value="'.esc_attr(Policy::fingerprint($c)).'">';
  if($oauth)echo '<p>Browser sign-in scopes are managed by OAuth consent. Reconnect to change those scopes.</p>';
  else{
   echo '<fieldset><legend><strong>Permissions</strong></legend><p>Read access is included. Select the permissions to keep on this connection.</p>';
   foreach(self::SCOPE_LABELS as $scope=>$label){
    echo '<label style="display:block"><input type="checkbox" name="scopes[]" value="'.esc_attr($scope).'"'.(in_array($scope,$c['scopes'],true)?' checked':'').'> '.esc_html($label).'</label>';
   }
   echo '<p><label><input type="checkbox" name="blog_enabled" value="1"'.(in_array('blog',$c['scopes'],true)?' checked':'').'> Blog drafts &amp; WebP cover images</label><br>';
   echo '<label><input type="checkbox" name="blog_auto_publish" value="1"'.(!empty($c['blog_auto_publish'])?' checked':'').'> Allow automatic publication of new blog articles</label></p>';
   echo '<p class="description">Blog access is restricted to new articles. To enable it, uncheck the other optional permissions and select With approvals. Automatic publication is off by default and bypasses per-article approval when enabled. Blog permissions control draft and publication status in this mode.</p></fieldset>';
  }
  echo '<p><label><input type="checkbox" name="draft_only" value="1"'.(!empty($c['draft_only'])?' checked':'').'> Restrict general content changes to drafts</label></p>';
  self::access_mode_fields($full);
  submit_button('Save permissions','primary','submit',false);echo '</form>';
 }
 private static function save_connection_permissions(string $id): void {
  $c=Store::get($id);
  if(!$c||!isset($c['hash'])||!Policy::allowed($c,'read'))throw new ConnectorError('An active connection is required.');
  if((int)$c['user_id']!==get_current_user_id())throw new ConnectorError('Only the connection owner can change permissions.');
  $revision=$_POST['permission_revision']??'';
  if(!is_string($revision)||!hash_equals(Policy::fingerprint($c),$revision))throw new ConnectorError('The connection changed. Review its current permissions and try again.');
  [$mode,$duration]=self::access_settings(true);
  $full=Policy::full_access($c);$next=$c;
  $next['draft_only']=($_POST['draft_only']??'')==='1';
  if(empty($c['oauth_only'])){
   $scopes=$_POST['scopes']??[];
   $valid=array_keys(self::SCOPE_LABELS);
   if(!is_array($scopes)||array_filter($scopes,static fn($scope)=>!is_string($scope)||!in_array($scope,$valid,true)))throw new ValidationError('Invalid permissions selection.');
   $blog=($_POST['blog_enabled']??'')==='1';$automatic=($_POST['blog_auto_publish']??'')==='1';
   if($automatic&&!$blog)throw new ValidationError('Enable blog drafts before selecting automatic publication.');
   if($blog&&($scopes||$mode==='full'))throw new ValidationError('Blog access requires With approvals and no other optional permissions.');
   $scopes=array_merge(['read'],array_values(array_intersect($valid,$scopes)),$blog?['blog']:[]);
   if(array_diff($scopes,$c['scopes'])||array_diff($c['scopes'],$scopes))$next['scopes']=$scopes;
   if($blog)$next['draft_only']=!$automatic;
   if($blog!==in_array('blog',$c['scopes'],true)||$automatic!==!empty($c['blog_auto_publish']))$next=Blog::permission_record($next,$blog,$automatic);
  }
  if($mode==='full'&&$duration==='keep'&&!$full)throw new ConnectorError('Full access has expired. Choose a new duration to turn it on again.');
  $changed=$next!==$c;
  if(!$changed&&(($mode==='manual'&&!$full)||($mode==='full'&&$duration==='keep')))return;
  if($changed)$next['maintenance_until']=0;
  $next=self::approval_record($next,$mode,$duration);
  $next['permissions_revision']=bin2hex(random_bytes(16));
  Store::audit('human:'.get_current_user_id(),'connection.permissions.saved',$id);
  Access::revoke_sessions($id);
  Store::put($id,'client',$next);
 }
 private static function connection_permissions_result(string $id,bool $ok,string $message): void {
  $receipt=bin2hex(random_bytes(12));
  set_transient('nsc_permissions_'.get_current_user_id().'_'.$receipt,['id'=>$id,'ok'=>$ok,'message'=>$message],300);
  wp_safe_redirect(admin_url('tools.php?page=nsc&tab=connections&nsc_permission_result='.$receipt.'#nsc-connection-'.$id),303);exit;
 }
 private static function proposals(): void {
  echo '<section class="nsc-step">';
  echo '<h2>Recent proposed changes</h2><p>Review the exact arguments and previous state. Approvals expire 30 minutes after proposal creation. Order status changes may send emails; PHP can have irreversible side effects.</p>';
  echo '<form id="nsc-batch-review" method="post" action="'.esc_url(admin_url('admin-post.php')).'">';wp_nonce_field('nsc_action');echo '<input type="hidden" name="action" value="nsc_action"><input type="hidden" name="operation" value="approve_batch"><p>Read each exact change below, select it, then <button class="button" type="submit">Approve selected changes</button>. Each executes separately after approval; this is not an atomic transaction.</p></form>';
  foreach(Store::all('proposal') as $p){
   $review=$p['arguments'];if($p['operation']==='blog_create'&&isset($review['image']['base64'])){unset($review['image']['base64']);}

   echo '<details style="border:1px solid #ccc;padding:12px;margin:8px 0"><summary>'.esc_html($p['operation'].' — '.$p['state'].' — '.$p['id']).'</summary><p>Client: '.esc_html($p['client_id']).' | Expires: '.esc_html(gmdate('Y-m-d H:i:s',$p['expires'])).' UTC</p><pre style="white-space:pre-wrap;max-height:350px;overflow:auto">'.esc_html(wp_json_encode(['arguments'=>$review,'before'=>$p['before']],JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE)).'</pre>';
   if(isset($p['result']['job_id'])&&($job=Store::get('job_'.$p['result']['job_id']))&&($job['kind']??'')==='bulk'){
    $progress=Bulk::progress($job);
    echo '<p>'.esc_html('Bulk job: '.$progress['state'].' | '.$progress['processed'].'/'.$progress['total'].' processed').'</p>';
    echo '<pre>'.esc_html(wp_json_encode(['batch_hash'=>$progress['batch_hash'],'counts'=>$progress['counts'],'error'=>$progress['error']??null],JSON_PRETTY_PRINT)).'</pre>';
   }
   echo wp_kses_post(ProposalReview::render($p));
   if($p['state']==='pending'&&$p['expires']>time()){
    if($p['operation']!=='blocks_batch')echo '<p><label><input form="nsc-batch-review" type="checkbox" name="proposals['.esc_attr($p['id']).']" value="'.esc_attr($p['digest']).'"> Select this exact change for batch approval</label></p>';
    if($p['operation']==='blocks_batch'){
     echo '<form method="post" action="'.esc_url(admin_url('admin-post.php')).'" data-nsc-blocks="'.esc_attr(wp_json_encode($p['arguments']['targets'])).'">';wp_nonce_field('nsc_action');
     echo '<input type="hidden" name="action" value="nsc_action"><input type="hidden" name="operation" value="approve_blocks"><input type="hidden" name="id" value="'.esc_attr($p['id']).'"><input type="hidden" name="serialized" value=""><button type="submit" class="button" disabled>Validate in native editor and approve</button><p role="status"></p></form>';
    }else self::form('approve',$p['id'],'Approve this exact change');
    self::form('reject',$p['id'],'Reject');
   }
   echo '</details>';
  }

  if (!Store::all('proposal')) echo '<p>No proposed changes to review.</p>';
  echo '</section>';
 }
 private static function activity(): void {
  global $wpdb;
  $rows=$wpdb->get_results($wpdb->prepare('SELECT * FROM %i ORDER BY id DESC LIMIT 50',Store::table('audit')),ARRAY_A);
  echo '<section class="nsc-step"><h2>Recent activity</h2><p>The latest 50 events. Times are UTC.</p>';
  if (!$rows) echo '<p>No activity recorded yet.</p>';
  else {
   echo '<div class="nsc-table-scroll"><table class="widefat striped"><thead><tr><th>Time (UTC)</th><th>Event</th><th>Connection / administrator</th><th>Reference</th></tr></thead><tbody>';
   foreach ($rows as $row) {
    echo '<tr>';
    foreach (['happened_at','event','client_id','reference_id'] as $field) echo '<td>'.esc_html((string)($row[$field]??'')).'</td>';
    echo '</tr>';
   }
   echo '</tbody></table></div>';
  }
  echo '<p class="description">Activity is stored locally. A full administrator can modify local records.</p></section>';
 }
 private static function update_settings(): void {
  $config=Updater::configuration();$last=$config['last'];
  if(($config['channel']??'')==='public'){
   echo '<h2>Plugin updates</h2><p><strong>Automatic public updates are enabled.</strong> No GitHub account, access key or repository invitation is needed. Every download is verified with the built-in public signing identity before installation.</p><p>For unattended installation, enable auto-updates for NexPilot on the Plugins screen. Otherwise use Update now when a signed release is available.</p>';
   echo '<p><a href="'.esc_url(Updater::PUBLIC_BASE.'/').'" target="_blank" rel="noopener noreferrer">Download and installation guide</a></p>';
   if(current_user_can('update_plugins'))self::form('updater_check','','Check updates and verify download');
   $states=['available'=>'A newer signed version is available. Install it from Plugins after staging review.','current'=>'This site is running the latest signed release.','ahead'=>'The installed candidate is newer than the latest Stable release.','unavailable'=>'The public update service could not be verified. Retry later.'];
   if($last){echo '<p role="status">'.esc_html($states[$last['state']??'']??'Run an update check.').'</p>';if(isset($last['latest']))echo '<p>Latest signed version: '.esc_html($last['latest']).'</p>';if(!empty($last['checked_at']))echo '<p>Last check: '.esc_html(gmdate('Y-m-d H:i:s',(int)$last['checked_at'])).' UTC.</p>';if(!empty($last['download_verified']))echo '<p>Signed download verified. No plugin files were installed or changed.</p>';}
   echo '<details><summary>Signing identity</summary><p>Public key SHA256: <code>'.esc_html($config['public_key_sha256']).'</code></p></details>';return;
  }
  echo '<h2>Plugin updates</h2><p>Keep NexPilot up to date from the private release service. The signing identity is built in; no file paths are needed.</p>';
  echo '<p><strong>'.esc_html($config['configured']?'Connected':'Not connected').'</strong> — '.esc_html($config['managed']?'Managed by your server administrator.':'Access is stored encrypted on this WordPress site. It is never included in the plugin ZIP or Git.').'</p>';
  if(!current_user_can('update_plugins')){echo '<p>An update administrator must configure this connection.</p>';return;}
  if(!$config['managed']){
   echo '<ol><li>Approve a read-only GitHub key. Choose <strong>Only select repositories → NexPilot</strong>, keep <strong>Contents: read</strong>, and choose an expiry.</li><li>Paste the key below once and save. NexPilot checks the signed release before storing it.</li></ol>';
   $url='https://github.com/settings/personal-access-tokens/new?name=NexPilot%20updates&description=Read%20NexPilot%20private%20releases&target_name=nexdev-team&expires_in=30&contents=read';
   echo '<p><a class="button" href="'.esc_url($url).'" target="_blank" rel="noopener noreferrer">Create read-only update key on GitHub</a></p>';
   echo '<form method="post" action="'.esc_url(admin_url('admin-post.php')).'">';wp_nonce_field('nsc_action');
   echo '<input type="hidden" name="action" value="nsc_action"><input type="hidden" name="operation" value="updater_save"><label>GitHub update key <input name="update_key" type="password" autocomplete="new-password" maxlength="4096" required></label>';
   submit_button('Save and verify update connection');echo '</form>';
   if($config['configured'])self::form('updater_disconnect','','Disconnect updates');
  }
  if($config['configured'])self::form('updater_check','','Check updates and verify download');
  if($last){
   $states=['available'=>'A newer signed version is available. Install it from Plugins after staging review.','current'=>'This site is running the latest signed release.','ahead'=>'The installed candidate is newer than the latest Stable release.','unavailable'=>'The update service could not be verified. Check the key, access approval, expiry and signed release, then retry.'];
   echo '<p role="status">'.esc_html($states[$last['state']??'']??'Run an update check.').'</p>';
   if(isset($last['latest']))echo '<p>Latest signed version: '.esc_html($last['latest']).'</p>';
   if(!empty($last['checked_at']))echo '<p>Last check: '.esc_html(gmdate('Y-m-d H:i:s',(int)$last['checked_at'])).' UTC.</p>';
   if(!empty($last['download_verified']))echo '<p>Signed download verified. No plugin files were installed or changed.</p>';
  }
  echo '<details><summary>Signing identity</summary><p>Public key SHA256: <code>'.esc_html($config['public_key_sha256']).'</code></p></details>';
 }
 private static function settings(): void {
  echo '<section class="nsc-step"><h2>Advanced settings</h2><p>MCP endpoint: <code>'.esc_html(rest_url('nexdev-connector/v1/mcp')).'</code></p>';
  echo '<h2 id="nsc-site-maintenance">Public site maintenance</h2><p>Visitors see the NexPilot maintenance page while this is on. WordPress administrators can still access the site and switch it off here.</p>';
  $maintenance=Maintenance::site_status();
  echo '<p>Status: <strong>'.($maintenance['enabled']?'On':'Off').'</strong></p>';
  self::form($maintenance['enabled']?'site_maintenance_off':'site_maintenance_on','',$maintenance['enabled']?'Turn off public maintenance':'Turn on public maintenance');
  self::update_settings();
  echo '<h2>OAuth connections</h2><p>Administrator consent and PKCE required. Enabling OAuth allows public client registration; every connection still requires your consent.</p>';
  self::form(get_option('nsc_oauth_enabled',false)?'oauth_disable':'oauth_enable','',get_option('nsc_oauth_enabled',false)?'Disable OAuth':'Enable OAuth');
  self::form('prune','','Remove expired records older than 30 days');
  echo '<h2>Uninstall data policy</h2><p>Default: keep connector records and audit after deletion. Optional removal deletes connections, proposals, libraries and audit on uninstall. Site content, uploads and sandbox files remain. Network uninstall retains data.</p>';
  self::form(get_option('nsc_delete_on_uninstall',false)?'retain_data':'delete_data','',get_option('nsc_delete_on_uninstall',false)?'Keep data on uninstall':'Remove connector data on uninstall');
  echo '</section>';
 }
 public static function approve_batch(array $selected): void {
  self::guard();if(!$selected||count($selected)>20)throw new ValidationError('Select between 1 and 20 exact changes.');
  $records=[];foreach($selected as $id=>$digest){
   if(!is_string($id)||!preg_match('/^[a-f0-9]{32}$/D',$id)||!is_string($digest))throw new ValidationError('Invalid selection.');
   $p=Store::get($id);if(!$p||($p['state']??'')!=='pending'||$p['expires']<=time()||$p['operation']==='blocks_batch'||!hash_equals($p['digest'],$digest)||!hash_equals($p['digest'],Policy::fingerprint([$p['operation'],$p['arguments'],$p['before']['revision']])))throw new ConnectorError('Selection changed or expired. Review all changes again.');
   $records[]=$p;
  }
  foreach($records as $p)self::guard_owner_approval($p);
  foreach($records as $p){Store::audit('human:'.get_current_user_id(),'admin.approve_batch',$p['id']);$p['state']='approved';$p['approved_by']=get_current_user_id();Store::put($p['id'],'proposal',$p);}
 }
 private static function guard_owner_approval(array $proposal): void {
  if(Tools::requires_owner_approval($proposal['operation'])&&(int)($proposal['owner_id']??0)!==get_current_user_id())throw new ConnectorError('Only the connection owner can approve this operation.');
 }
 public static function action(): void {
  self::guard();check_admin_referer('nsc_action');
  try {
   $op=sanitize_key($_POST['operation']??'');$id=sanitize_text_field(wp_unslash($_POST['id']??''));
   if(in_array($op,['site_maintenance_on','site_maintenance_off'],true)){
    Store::locked(static function()use($op){
     Store::audit('human:'.get_current_user_id(),'admin.'.$op);
     Maintenance::set_site_enabled($op==='site_maintenance_on');
    });
    wp_safe_redirect(admin_url('tools.php?page=nsc&tab=settings#nsc-site-maintenance'),303);exit;
   }
   if(in_array($op,['updater_save','updater_check','updater_disconnect'],true)){
    if($op==='updater_save'){$key=wp_unslash($_POST['update_key']??'');if(!is_string($key))throw new ConnectorError('Invalid update key.');Updater::save_credential($key);}
    elseif($op==='updater_disconnect')Updater::disconnect();
    else Updater::check(true);
    wp_safe_redirect(admin_url('tools.php?page=nsc&tab=settings'));exit;
   }
   if($op==='bulk_limits'&&preg_match('/^[a-f0-9]{32}$/D',$id)){
    try{
     $batch=$_POST['per_batch']??null;$hour=$_POST['per_hour']??null;
     if(!is_string($batch)||!is_string($hour)||!ctype_digit($batch)||!ctype_digit($hour))throw new ValidationError('Enter numeric bulk limits.');
     Store::locked(static fn()=>Bulk::set_limits($id,(int)$batch,(int)$hour));
    }catch(ConnectorError|ValidationError $e){self::connection_permissions_result($id,false,$e->getMessage());}
    self::connection_permissions_result($id,true,'Bulk limits saved.');
   }
   if($op==='connection_permissions'&&preg_match('/^[a-f0-9]{32}$/D',$id)){
    try{Store::locked(static fn()=>self::save_connection_permissions($id));}
    catch(ConnectorError|ValidationError $e){self::connection_permissions_result($id,false,$e->getMessage());}
    catch(\Throwable $e){self::connection_permissions_result($id,false,'Could not save permissions. Review the current settings and try again.');}
    self::connection_permissions_result($id,true,'Permissions saved.');
   }
   if($op==='connection_test'){nocache_headers();wp_die(wp_kses_post(Diagnostics::render(Diagnostics::run())),'Connection test',['response'=>200]);}
   if($op==='diagnostics'){
    $checks=[];
    $probe=static function($name,$fn)use(&$checks){try{$checks[$name]=['status'=>'ok','result'=>$fn()];}catch(\Throwable $e){$checks[$name]=['status'=>'unavailable','message'=>$e instanceof ConnectorError?$e->getMessage():'Integration check failed.'];}};
    $probe('storage_mutex',static fn()=>Store::locked(static fn()=>['backend'=>defined('NSC_SQLITE_LOCK_FILE')?'sqlite-single-host':'mysql-advisory','schema'=>(int)get_option('nsc_schema_version',0),'sodium'=>function_exists('sodium_crypto_secretbox')]));
    foreach(['bundle','composite'] as $kind)$probe($kind,static function()use($kind){$rows=Integrations::commerce(['kind'=>$kind]);return ['products_read'=>count($rows),'detail_records'=>array_sum(array_map(static fn($r)=>count($r[$kind==='bundle'?'items':'components']??[]),$rows))];});
    $probe('minmax',static function(){ $rules=Integrations::commerce(['kind'=>'minmax']);$products=wc_get_products(['limit'=>1,'type'=>'simple']);if($products)$rules=Integrations::commerce(['kind'=>'minmax','id'=>$products[0]->get_id()]);return ['stored_rule_count'=>count($rules['stored_rules']),'classic_quantity_input'=>$rules['classic_quantity_input']];});
    $probe('wpforms',static function(){$forms=Integrations::forms(['action'=>'list']);if($forms)Integrations::forms(['action'=>'get','id'=>$forms[0]['id']]);return ['forms_read'=>count($forms)];});
    $probe('wpforms_entry_schema',static fn()=>Integrations::forms(['action'=>'stats','form_id'=>2147483647]));
    nocache_headers();wp_die('<h1>Read-only integration checks</h1><p>No products, forms, entries or settings were changed. No customer data is displayed. A successful zero-record check verifies availability, not populated data.</p><pre>'.esc_html(wp_json_encode($checks,JSON_PRETTY_PRINT)).'</pre><p><a href="'.esc_url(admin_url('tools.php?page=nsc')).'">Back to connector</a></p>','Integration checks',['response'=>200]);
   }
   if(in_array($op,['create','rotate','open','oauth_enable','access_mode'],true)&&!Policy::accepted())throw new ConnectorError('Accept the use-at-your-own-risk agreement first.');
   if(in_array($op,['create','rotate'],true)){
    if(!is_ssl()&&!(wp_get_environment_type()==='local'&&defined('NSC_ALLOW_LOCAL_HTTP')&&NSC_ALLOW_LOCAL_HTTP))throw new ConnectorError('HTTPS is required for connection credentials.');
    $scopes=['read'];foreach(array_map('sanitize_key',(array)wp_unslash($_POST['scopes']??[])) as $s)if(isset(self::SCOPE_LABELS[$s]))$scopes[]=$s;
    [$mode,$duration]=self::access_settings();
    if($op==='create'&&$mode==='full'&&(!empty($_POST['draft_only'])||!array_intersect(['content','commerce','maintenance'],$scopes)))throw new ConnectorError('Full access needs a write scope and Draft-only off.');
    $result=Store::locked(static function()use($op,$id,$scopes,$mode,$duration){
     $result=$op==='rotate'?Store::rotate_client($id):Store::create_client(sanitize_text_field(wp_unslash($_POST['label']??'')),$scopes,get_current_user_id(),!empty($_POST['draft_only']));
     if($op==='create'&&$mode==='full')$result['client']=self::set_access_mode($result['client'],$mode,$duration);
     return $result;
    });
    nocache_headers();header('Referrer-Policy: no-referrer');
    if(str_contains($_SERVER['HTTP_ACCEPT']??'','application/json'))wp_send_json_success(['token'=>$result['token'],'id'=>$result['client']['id'],'expires'=>$result['client']['expires'],'scopes'=>$result['client']['scopes']]);
    wp_die('<h1>Connection created</h1><p>Copy this credential now. It is displayed only once. Store it in a local token file with owner-only permissions; never put it in a URL or chat.</p><textarea readonly rows="3" cols="100">'.esc_textarea($result['token']).'</textarea><p><a href="'.esc_url(admin_url('tools.php?page=nsc')).'">Back to connector</a></p>','Connection created',['response'=>200]);
   }
   // Keep nonce-protected input decoding outside the storage callback. Preserve markup bytes.
   $serialized = $op === 'approve_blocks' ? wp_unslash($_POST['serialized'] ?? '') : '';
   if (!is_string($serialized) || strlen($serialized) > 131072) throw new ValidationError('Invalid serialized batch.');
   $targets = $serialized === '' ? null : json_decode($serialized, true);
   $confirmed = !empty($_POST['accept_risk_confirm']);
   $selected=wp_unslash($_POST['proposals']??[]);
   [$mode,$duration]=self::access_settings();
   Store::locked(static function()use($op,$id,$targets,$confirmed,$selected,$mode,$duration){
    if($op==='approve_batch'){self::approve_batch($selected);return;}
    if($op==='accept_risk'){if(!$confirmed)throw new ConnectorError('Tick the box to accept the agreement.');update_option('nsc_risk_accepted',['user'=>get_current_user_id(),'time'=>time(),'version'=>NSC_VERSION],false);Store::audit('human:'.get_current_user_id(),'risk.accepted');return;}
    if($op==='withdraw_risk'){delete_option('nsc_risk_accepted');foreach(Store::records('client') as $c){$c['revoked']=true;$c['maintenance_until']=0;Store::put($c['id'],'client',$c);}Access::revoke_sessions();Store::audit('human:'.get_current_user_id(),'risk.withdrawn');return;}
    if(in_array($op,['retain_data','delete_data'],true)){Store::audit('human:'.get_current_user_id(),'retention.'.$op);update_option('nsc_delete_on_uninstall',$op==='delete_data',false);return;}
    if(in_array($op,['oauth_enable','oauth_disable'],true)){update_option('nsc_oauth_enabled',$op==='oauth_enable',false);if($op==='oauth_disable'){foreach(Store::records('client') as $c)if(!empty($c['oauth_only'])){$c['revoked']=true;$c['maintenance_until']=0;Store::put($c['id'],'client',$c);Access::revoke_sessions($c['id']);}}Store::audit('human:'.get_current_user_id(),'oauth.'.$op);return;}
    if($op==='prune'){Store::prune();Store::audit('human:'.get_current_user_id(),'retention.pruned');return;}
    if(in_array($op,['disable','enable'],true)){update_option('nsc_disabled',$op==='disable',false);if($op==='disable')Access::revoke_sessions();Store::audit('human:'.get_current_user_id(),'connector.'.$op);return;}
    if($op==='blog_permissions'){Blog::configure($id,($_POST['blog_enabled']??'')==='1',($_POST['blog_auto_publish']??'')==='1');return;}
    $record=Store::get($id);if(!$record)throw new ConnectorError('Record not found.');
    if($op==='access_mode'){self::set_access_mode($record,$mode,$duration);return;}
    if(in_array($op,['revoke','open','close','draft_on','draft_off'],true)){
     if(!isset($record['hash']))throw new ConnectorError('Not a connection.');
     if($op==='draft_on'||$op==='draft_off'){$record['draft_only']=$op==='draft_on';if($op==='draft_on'){$record['approval_until']=0;$record['approval_grant']='';$record['maintenance_until']=0;Access::revoke_sessions($id);}}
     if($op==='revoke'){Access::revoke_sessions($id);$record['revoked']=true;$record['maintenance_until']=0;}
     if($op==='open'){if(!empty($record['draft_only']))throw new ConnectorError('Disable draft-only before opening full maintenance.');Policy::require_scope($record,'maintenance');$record['maintenance_until']=time()+600;}
     if($op==='close'){$record['approval_until']=0;$record['approval_grant']='';$record['maintenance_until']=0;Access::revoke_sessions($id);}
     Store::put($id,'client',$record);
    }elseif(in_array($op,['approve','approve_blocks','reject'],true)){
     if(($record['state']??'')!=='pending'||$record['expires']<=time())throw new ConnectorError('Proposal is no longer pending.');
     if($op==='approve')self::guard_owner_approval($record);
     if($record['operation']==='blocks_batch'&&$op==='approve')throw new ConnectorError('Use native editor validation for block batches.');
     if($op==='approve_blocks'){
      if($record['operation']!=='blocks_batch')throw new ConnectorError('Not a block batch.');
      if(!is_array($targets)||count($targets)!==count($record['arguments']['targets']))throw new ConnectorError('Invalid serialized batch.');
      Blocks::validate(['targets'=>$targets]);
      foreach($targets as $i=>$t){if($t['id']!==$record['arguments']['targets'][$i]['id'])throw new ConnectorError('Target mismatch.');}
      if(Policy::fingerprint($targets)!==Policy::fingerprint($record['arguments']['targets'])){
       // Re-serialization changed bytes. Store the normalized proposal but require a second human review.
       $record['arguments']['targets']=$targets;$record['digest']=Policy::fingerprint([$record['operation'],$record['arguments'],$record['before']['revision']]);$record['editor_validated']=true;
       Store::put($id,'proposal',$record);Store::audit('human:'.get_current_user_id(),'blocks.normalized_review_again',$id);return;
      }
      $record['editor_validated']=true;
     }
     $record['state']=in_array($op,['approve','approve_blocks'],true)?'approved':'rejected';$record['approved_by']=get_current_user_id();Store::put($id,'proposal',$record);
    }else throw new ConnectorError('Unknown admin action.');
    Store::audit('human:'.get_current_user_id(),'admin.'.$op,$id);
   });
   $return_tab = in_array($op, ['oauth_enable','oauth_disable','prune','retain_data','delete_data'], true) ? 'settings' : (in_array($op, ['revoke','open','close','draft_on','draft_off','access_mode'], true) ? 'connections' : (in_array($op, ['approve','approve_blocks','approve_batch','reject'], true) ? 'proposals' : 'setup'));
   wp_safe_redirect(admin_url('tools.php?page=nsc&tab='.$return_tab));exit;
  }catch(\Throwable $e){wp_die(esc_html('Action refused: '.$e->getMessage()),'Connector',['response'=>400]);}
 }
}
