<?php
namespace Nexdev\SiteConnector;

/** Code-only rollback for bounded, inactive, single-directory plugins. */
final class PluginBatch {
 private const MAX_BYTES=4194304;
 private const MAX_FILES=750;
 private const SNAPSHOT_TTL=7*86400;

 public static function select(array $client,array $args): array {
  self::allowed();
  if(array_key_exists('ids',$args)===array_key_exists('filter',$args))throw new ValidationError('Supply exactly one of ids or filter.');
  if(array_key_exists('ids',$args)){
   $ids=$args['ids'];
   if(!is_array($ids)||!array_is_list($ids)||!$ids)throw new ValidationError('Select exact plugin IDs.');
   foreach($ids as $id)self::identifier($id);
  }else{
   $filter=$args['filter'];
   if(!is_array($filter))throw new ValidationError('Plugin update filter must be an object.');
   Policy::fields($filter,['update_available','search','status'],['update_available']);
   if($filter['update_available']!==true)throw new ValidationError('update_available must be true.');
   if(isset($filter['status'])&&$filter['status']!=='inactive')throw new ValidationError('Only inactive plugins support bulk updates.');
   $search=$filter['search']??'';
   if(!is_string($search)||strlen($search)>200)throw new ValidationError('Plugin search must be text up to 200 bytes.');
   $rows=Resources::plugins_list()['items'];
   $ids=[];
   foreach($rows as $item){
    if($item['update_available']&&(!isset($filter['status'])||$item['status']==='inactive')&&stripos($item['plugin'].' '.$item['name'],$search)!==false)$ids[]=$item['plugin'];
   }
  }
  $cap=min(10,Bulk::limits($client)['per_batch']);
  if(count($ids)>$cap)throw new ValidationError('Plugin update cap is '.$cap.' items per batch.');
  if(count($ids)!==count(array_unique($ids)))throw new ValidationError('Plugin IDs must be unique.');
  sort($ids,SORT_STRING);
  return $ids;
 }
 private static function identifier(mixed $id): void {
  if(!is_string($id)||strlen($id)>150||!preg_match('~^[A-Za-z0-9_-]+/[A-Za-z0-9_-]+[.]php$~D',$id))throw new ValidationError('A plugin ID must identify a main PHP file in a plugin directory.');
 }
 private static function allowed(): void {
  if(is_multisite()||!current_user_can('update_plugins')||!class_exists(\ZipArchive::class)||!wp_is_file_mod_allowed('capability_update_core'))throw new ConnectorError('Plugin batches require a single site, plugin update rights, file modifications and ZipArchive.');
 }
 private static function path(string $id,bool $allowMissing=false): string {
  self::allowed();self::identifier($id);
  require_once ABSPATH.'wp-admin/includes/plugin.php';
  $root=WP_PLUGIN_DIR.'/'.dirname($id);
  $real=realpath($root);
  if(is_link($root)||is_link(WP_PLUGIN_DIR.'/'.$id)||($real!==false&&($real!==realpath(WP_PLUGIN_DIR).'/'.dirname($id)||!is_dir($root)))||(!$allowMissing&&($real===false||!is_file(WP_PLUGIN_DIR.'/'.$id))))throw new ConnectorError('Plugin path is unavailable or uses a symlink.');
  $sameFolder=array_filter(array_keys(get_plugins()),static fn($plugin)=>dirname($plugin)===dirname($id));
  if($sameFolder!==[]&&array_values($sameFolder)!==[$id])throw new ConnectorError('The plugin directory contains multiple plugin entry points.');
  if(is_plugin_active($id)||is_plugin_active_for_network($id)||dirname($id)==='nexdev-site-connector')throw new ConnectorError('Active plugins and NexPilot are excluded from bulk updates.');
  return $root;
 }
 private static function safe_entry(string $path): bool {
  return strlen($path)<=240&&preg_match('~^(?:[A-Za-z0-9_@+-][A-Za-z0-9_@+.-]*/)*[A-Za-z0-9_@+-][A-Za-z0-9_@+.-]*$~D',$path);
 }
 private static function tree(string $id,?\ZipArchive $backup=null): array {
  $root=self::path($id);$slug=dirname($id);
  $iterator=new \RecursiveIteratorIterator(new \RecursiveDirectoryIterator($root,\FilesystemIterator::SKIP_DOTS),\RecursiveIteratorIterator::SELF_FIRST);
  $manifest=[];$bytes=0;
  foreach($iterator as $entry){
   $relative=substr($entry->getPathname(),strlen($root)+1);
   if(!self::safe_entry($relative)||$entry->isLink()||count($manifest)>=self::MAX_FILES)throw new ConnectorError('Plugin tree has unsupported paths or exceeds the snapshot file cap.');
   if($entry->isDir()){
    $manifest[$relative.'/']='directory';
    if($backup&&!$backup->addEmptyDir($slug.'/'.$relative))throw new ConnectorError('Plugin directory could not be archived.');
    continue;
   }
   if(!$entry->isFile()||($bytes+=$entry->getSize())>self::MAX_BYTES)throw new ConnectorError('Plugin tree exceeds the 4 MiB snapshot cap or has an unsupported file.');
   $data=file_get_contents($entry->getPathname(),false,null,0,self::MAX_BYTES+1);
   if($data===false||strlen($data)!==$entry->getSize())throw new ConnectorError('Plugin file changed while being inspected.');
   $manifest[$relative]=hash('sha256',$data);
   if($backup&&!$backup->addFromString($slug.'/'.$relative,$data))throw new ConnectorError('Plugin file could not be archived.');
  }
  return $manifest;
 }
 private static function offer(string $id): ?array {
  $update=get_site_transient('update_plugins')->response[$id]??null;
  $url=$update->package??'';
  if(!is_string($url)||strlen($url)>2048||!str_starts_with($url,'https://')||!is_string($update->new_version??null)||strlen($update->new_version)>80)return null;
  $parts=wp_parse_url($url);
  if(!$parts||empty($parts['host'])||isset($parts['user'])||isset($parts['pass'])||isset($parts['fragment']))return null;
  $checksum=$update->sha256??null;
  if($checksum!==null&&(!is_string($checksum)||!preg_match('/^[a-f0-9]{64}$/iD',$checksum)))return null;
  return ['version'=>$update->new_version,'package_fingerprint'=>hash('sha256',$url),'sha256'=>$checksum===null?null:strtolower($checksum),'url'=>$url];
 }
 public static function current(string $id,bool $withOffer): array {
  clearstatcache();
  $files=self::tree($id);
  $header=get_file_data(WP_PLUGIN_DIR.'/'.$id,['version'=>'Version']);
  if($header['version']==='')throw new ConnectorError('Plugin version could not be verified.');
  $current=['version'=>$header['version'],'tree'=>Policy::fingerprint($files)];
  if($withOffer){
   $offer=self::offer($id);
   $current['offer']=$offer?array_diff_key($offer,['url'=>true]):null;
  }
  return $current;
 }
 public static function target(string $id): array {
  try{
   $before=self::current($id,true);
   if(!$before['offer']||version_compare($before['offer']['version'],$before['version'],'<='))throw new ConnectorError('No newer HTTPS update is cached for this plugin.');
   return ['id'=>$id,'before'=>$before,'after'=>$before['offer'],'revision'=>Policy::fingerprint($before)];
  }catch(ConnectorError|ValidationError $e){return ['id'=>$id,'reason'=>$e->getMessage()];}
 }
 private static function temporary(): string {
  $root=realpath(get_temp_dir());
  $webRoot=realpath(ABSPATH);
  $content=realpath(WP_CONTENT_DIR);
  $document=empty($_SERVER['DOCUMENT_ROOT'])?false:realpath($_SERVER['DOCUMENT_ROOT']);
  if(!$root)throw new ConnectorError('A private temporary directory is required.');
  foreach([$webRoot,$content,$document] as $public){
   if($public&&($root===$public||str_starts_with($root,$public.'/')))throw new ConnectorError('The plugin temporary directory must be outside the web root.');
  }
  $path=tempnam($root,'nsc-plugin-');
  if(!$path)throw new ConnectorError('Could not allocate plugin package.');
  if(realpath(dirname($path))!==$root||!chmod($path,0600)){unlink($path);throw new ConnectorError('Could not secure the temporary plugin package.');}
  return $path;
 }
 private static function verify(string $file,string $id,string $version): string {
  if(filesize($file)>self::MAX_BYTES)throw new ConnectorError('Plugin ZIP exceeds the 4 MiB cap.');
  $zip=new \ZipArchive();
  if($zip->open($file,\ZipArchive::CHECKCONS)!==true)throw new ConnectorError('Plugin package is not a valid ZIP.');
  $prefix=dirname($id).'/';$files=[];$names=[];$total=0;$header=null;
  try{
   if($zip->numFiles>self::MAX_FILES+1)throw new ConnectorError('Plugin ZIP exceeds the file cap.');
   for($index=0;$index<$zip->numFiles;$index++){
    $stat=$zip->statIndex($index);
    $name=$stat['name']??'';
    if($name===$prefix)continue;
    $relative=substr($name,strlen($prefix));$directory=str_ends_with($relative,'/');
    $attributes=0;$system=0;
    $zip->getExternalAttributesIndex($index,$system,$attributes);
    $mode=($attributes>>16)&0170000;
    if(!str_starts_with($name,$prefix)||!self::safe_entry(rtrim($relative,'/'))||isset($names[$relative])||!in_array($mode,[0,$directory?0040000:0100000],true))throw new ConnectorError('Plugin ZIP contains unsafe paths, entry types or duplicates.');
    $names[$relative]=true;
    if($directory){$files[$relative]='directory';continue;}
    if(($total+=$stat['size'])>self::MAX_BYTES)throw new ConnectorError('Expanded plugin ZIP exceeds the 4 MiB cap.');
    $data=$zip->getFromIndex($index);
    if($data===false||strlen($data)!==$stat['size'])throw new ConnectorError('Plugin ZIP contains an unreadable file.');
    if(preg_match('/[.](?:php[0-9]?|phtml|phar)$/iD',$name))token_get_all($data,TOKEN_PARSE);
    if(dirname($relative)==='.'&&str_ends_with(strtolower($relative),'.php')){
     $candidate=substr($data,0,8192);
     if(self::header($candidate,'Plugin Name')!==''){
      if($name!==$id)throw new ConnectorError('Plugin package contains a second plugin entry point.');
      $header=$candidate;
     }
    }
    $files[$relative]=hash('sha256',$data);
    // ZIPs may omit directory entries. WordPress creates those directories on extraction.
    $parent=dirname($relative);
    while($parent!=='.'){$files[$parent.'/']='directory';$parent=dirname($parent);}
   }
   if($header===null||self::header($header,'Version')!==$version)throw new ConnectorError('Plugin ZIP version or entry point differs from the approved update.');
   if(!is_php_version_compatible(self::header($header,'Requires PHP'))||!is_wp_version_compatible(self::header($header,'Requires at least')))throw new ConnectorError('Plugin ZIP requires a newer PHP or WordPress version.');
   return Policy::fingerprint($files);
  }finally{$zip->close();}
 }
 private static function header(string $source,string $name): string {
  if(!preg_match('~^[ \t*#/]*'.preg_quote($name,'~').':[ \t]*([^\r\n]*)~mi',$source,$match))return '';
  return trim(preg_replace('~\s*(?:\*/|\?>).*$~','',$match[1]));
 }
 private static function install(string $file,string $id,string $version,string $tree,bool $restore=false): void {
  self::path($id,$restore);
  require_once ABSPATH.'wp-admin/includes/file.php';
  require_once ABSPATH.'wp-admin/includes/class-wp-upgrader.php';
  if(get_filesystem_method([],WP_PLUGIN_DIR)!=='direct')throw new ConnectorError('Plugin batches require the direct WordPress filesystem method.');
  $inject=static function($transient)use($id,$file,$version){
   $transient=is_object($transient)?clone $transient:new \stdClass();
   $transient->response[$id]=(object)['package'=>$file,'new_version'=>$version,'plugin'=>$id];
   return $transient;
  };
  add_filter('site_transient_update_plugins',$inject,PHP_INT_MAX);
  try{
   $upgrader=new \Plugin_Upgrader(new \WP_Ajax_Upgrader_Skin());
   $success=$upgrader->upgrade($id,['clear_update_cache'=>false]);
  }finally{remove_filter('site_transient_update_plugins',$inject,PHP_INT_MAX);}
  if($success!==true||self::current($id,false)!==['version'=>$version,'tree'=>$tree])throw new ConnectorError('WordPress did not confirm the expected plugin files and version.');
 }
 public static function update(string $id,array $target,array $job): array {
  $offer=self::offer($id);
  if(!$offer||Policy::fingerprint(array_diff_key($offer,['url'=>true]))!==Policy::fingerprint($target['after']))throw new ConnectorError('The approved plugin update is no longer available.');
  $download=self::temporary();$backup=null;
  try{
   $backup=self::temporary();
   $response=wp_safe_remote_get($offer['url'],['timeout'=>35,'redirection'=>0,'stream'=>true,'filename'=>$download,'limit_response_size'=>self::MAX_BYTES+1]);
   if(is_wp_error($response)||wp_remote_retrieve_response_code($response)!==200)throw new ConnectorError('Plugin package download failed.');
   if($offer['sha256']!==null&&!hash_equals($offer['sha256'],(string)hash_file('sha256',$download)))throw new ConnectorError('Plugin package checksum differs from the approved update.');
   $tree=self::verify($download,$id,$offer['version']);
   $archive=new \ZipArchive();
   if($archive->open($backup,\ZipArchive::CREATE|\ZipArchive::OVERWRITE)!==true)throw new ConnectorError('Could not create a plugin snapshot.');
   try{$oldTree=Policy::fingerprint(self::tree($id,$archive));}
   finally{$archive->close();}
   if($oldTree!==$target['before']['tree']||self::verify($backup,$id,$target['before']['version'])!==$oldTree)throw new ConnectorError('The plugin snapshot failed verification.');
   $snapshot=self::key($job['id'],$id);
   $data=file_get_contents($backup);
   if($data===false)throw new ConnectorError('Could not read plugin snapshot.');
   Store::put($snapshot,'plugin_snapshot',['client_id'=>$job['client_id'],'job_id'=>$job['id'],'plugin'=>$id,'tree'=>$oldTree,'version'=>$target['before']['version'],'expires'=>time()+self::SNAPSHOT_TTL,'archive'=>base64_encode($data)],true);
   try{self::install($download,$id,$offer['version'],$tree);}
   catch(\Throwable $error){
    $intact=false;
    try{$intact=self::current($id,false)===['version'=>$target['before']['version'],'tree'=>$oldTree];}
    catch(ConnectorError $check){}
    if($intact)throw new ConnectorError('Plugin update failed. Original files are intact.');
    try{self::install($backup,$id,$target['before']['version'],$oldTree,true);}
    catch(\Throwable $restore){throw new ConnectorError('Plugin update failed and original files could not be verified after automatic recovery.');}
    throw new ConnectorError('Plugin update failed and the original files were restored and verified.');
   }
   return ['before'=>['snapshot'=>$snapshot,'version'=>$target['before']['version'],'tree'=>$oldTree],'after'=>['version'=>$offer['version'],'tree'=>$tree]];
  }finally{
   if(is_file($download))unlink($download);
   if($backup&&is_file($backup))unlink($backup);
  }
 }
 public static function rollback(string $id,array $target,array $job): void {
  $source=self::snapshot_record($target['after'],$job['client_id'],$id);
  $tmp=self::temporary();
  try{
   $bytes=base64_decode($source['archive'],true);
   if($bytes===false||file_put_contents($tmp,$bytes)!==strlen($bytes)||self::verify($tmp,$id,$source['version'])!==$source['tree'])throw new ConnectorError('Plugin snapshot integrity check failed.');
   self::install($tmp,$id,$source['version'],$source['tree']);
  }finally{unlink($tmp);}
 }
 public static function snapshot_record(array $descriptor,string $client,string $id): array {
  $source=Store::get($descriptor['snapshot']);
  if(!$source||$source['client_id']!==$client||$source['plugin']!==$id||$source['expires']<=time()||$source['tree']!==$descriptor['tree']||$source['version']!==$descriptor['version'])throw new ConnectorError('The original plugin snapshot is unavailable or expired.');
  return $source;
 }
 private static function key(string $job,string $id): string {
  return 'ps_'.substr(hash('sha256',$job.':'.$id),0,60);
 }
}
