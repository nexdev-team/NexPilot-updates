<?php
namespace Nexdev\SiteConnector;

/** Approved batches use the normal proposal mutex and checkpoint before every side effect. */
final class Bulk {
 public const HOOK='nsc_bulk_tick';
 public const MAX_ITEMS=1000;
 private const CHUNK=20;
 private const MAX_AGE=3600;

 public static function scope(string $operation): ?string {
  return match($operation){'users_delete'=>'accounts_delete','bulk_revert'=>'read',default=>BulkChanges::specs()[$operation][0]??null};
 }
 public static function owner_approval(string $op): bool {
  return in_array($op,['users_delete','bulk_revert'],true)||(isset(BulkChanges::specs()[$op])&&!BulkChanges::specs()[$op][1]&&$op!=='cache_purge');
 }
 public static function definitions(array $client): array {
  $result=[];
  foreach(array_keys(BulkChanges::specs()+['users_delete'=>null,'bulk_revert'=>null]) as $operation){
   $scope=self::scope($operation);
   if(!Policy::allowed($client,$scope))continue;
   $result[$operation]=['scope'=>$scope,'dry_run'=>$operation==='users_delete'?'users_delete_preview':'bulk_preview','approval'=>(self::owner_approval($operation)||$scope==='maintenance')?'explicit connection-owner approval':'connection approval mode','limits'=>self::limits($client),'status'=>'job_get','resume'=>'job_resume'];
   if(isset(BulkChanges::specs()[$operation])){
    $result[$operation]['filters']=BulkChanges::specs()[$operation][2];
    $result[$operation]['reversible']=BulkChanges::specs()[$operation][1];
   }
  }
  return $result;
 }
 public static function limits(array $client): array {
  $limits=$client['bulk_limits']??[];
  return ['per_batch'=>$limits['per_batch']??100,'per_hour'=>$limits['per_hour']??100];
 }
 public static function set_limits(string $id,int $batch,int $hour): void {
  $client=Store::get($id);
  if(!$client||!isset($client['scopes'])||(int)$client['user_id']!==get_current_user_id())throw new ConnectorError('Only the connection owner can change bulk limits.');
  if($batch<1||$batch>self::MAX_ITEMS||$hour<$batch||$hour>10000)throw new ValidationError('Batch limit must be 1–1000. The hourly limit must be at least the batch limit and at most 10000.');
  Store::audit('human:'.get_current_user_id(),'bulk.limits',$id);
  $client['bulk_limits']=['per_batch'=>$batch,'per_hour'=>$hour];
  $client['permissions_revision']=bin2hex(random_bytes(16));
  Store::put($id,'client',$client);
 }
 public static function validate(string $operation,array $args): void {
  if($operation==='users_delete')Policy::fields($args,['ids','filter','expected_count','batch_hash'],['expected_count','batch_hash']);
  else BulkChanges::validate($operation,$args);
  if(!is_int($args['expected_count']??null)||$args['expected_count']<1||$args['expected_count']>self::MAX_ITEMS||!is_string($args['batch_hash']??null)||!preg_match('/^[a-f0-9]{64}$/D',$args['batch_hash']))throw new ValidationError('A positive expected_count and the dry-run batch_hash are required.');
 }
 public static function preview(array $client,string $op,array $args): array {
  $scope=self::scope($op);
  if($scope===null)throw new ValidationError('Unsupported bulk operation.');
  Policy::require_scope($client,$scope);
  if($scope==='maintenance')Policy::maintenance($client);
  if(in_array($op,['users_delete','users_update'],true)&&is_multisite())throw new ConnectorError('Bulk account changes are unavailable on WordPress Multisite.');
  if($op==='users_delete'){
   Policy::fields($args,['ids','filter']);
   return Resources::users_delete_preview($client,$args);
  }
  BulkChanges::validate($op,$args);
  if($op==='bulk_revert')return self::revert_preview($client,$args['revert_id']);
  if($op==='plugins_apply')return self::preview_rows(array_map([PluginBatch::class,'target'],PluginBatch::select($client,$args)),true,$op);
  if($op==='cache_purge')return self::preview_rows(array_map([CacheBatch::class,'target'],CacheBatch::select($client,$args)),false,$op);
  $ids=BulkChanges::select($client,$op,$args);
  if($op==='products_import'){
   $csv=BulkChanges::csv($args['csv']);
   $csvIds=array_keys($csv);sort($csvIds,SORT_NUMERIC);
   if($csvIds!==$ids)throw new ValidationError('CSV rows must match the exact selected product IDs.');
   $rows=array_map(static fn(int $id): array=>BulkChanges::target('products_update',$id,$csv[$id]),$ids);
   return self::preview_rows($rows,true,'products_update');
  }
  $rows=array_map(static fn(int $id): array=>BulkChanges::target($op,$id,$args['fields']??[]),$ids);
  return self::preview_rows($rows,BulkChanges::specs()[$op][1],$op);
 }
 private static function preview_rows(array $rows,bool $reversible,string $op): array {
  $eligible=[];$skipped=[];
  foreach($rows as $row){
   if(isset($row['reason']))$skipped[]=$row;
   else $eligible[]=$row;
  }
  return ['dry_run'=>true,'operation'=>$op,'count'=>count($rows),'sample'=>array_slice($rows,0,5),'batch_hash'=>Policy::fingerprint(array_column($rows,'id')),'reversible'=>$reversible,'eligible'=>$eligible,'skipped'=>$skipped];
 }
 private static function revert_preview(array $client,string $id): array {
  $source=Store::get('job_'.$id);
  if(!$source||$source['client_id']!==$client['id']||empty($source['reversible'])||$source['state']!=='done')throw new ConnectorError('Completed reversible batch not found.');
  $op=$source['operation'];
  Policy::require_scope($client,self::scope($op));
  if(self::scope($op)==='maintenance')Policy::maintenance($client);
  $rows=[];
  foreach($source['result']['done'] as $item){
   if($op==='plugins_apply'){
    try{
     PluginBatch::snapshot_record($item['before'],$client['id'],$item['id']);
     $current=PluginBatch::current($item['id'],false);
    }catch(ConnectorError $e){
     $rows[]=['id'=>$item['id'],'reason'=>$e->getMessage()];continue;
    }
   }else{$current=BulkChanges::values($op,$item['id']);}
   $actual=$current===null?null:array_intersect_key($current,$item['after']);
   $rows[]=$actual===null||Policy::fingerprint($actual)!==Policy::fingerprint($item['after'])
    ?['id'=>$item['id'],'reason'=>'Object changed since the original batch.']
    :['id'=>$item['id'],'before'=>$actual,'after'=>$item['before'],'revision'=>Policy::fingerprint($actual)];
  }
  if(count($rows)>self::limits($client)['per_batch'])throw new ConnectorError('Revert exceeds the current bulk cap.');
  return self::preview_rows($rows,false,$op);
 }
 public static function snapshot(array $client,string $op,array $args): array {
  $preview=self::preview($client,$op,array_diff_key($args,['expected_count'=>true,'batch_hash'=>true]));
  if($preview['count']!==$args['expected_count']||!hash_equals($preview['batch_hash'],$args['batch_hash']))throw new ConnectorError('Batch targets changed. Run a new dry run.');
  return $preview+['revision'=>Policy::fingerprint($preview)];
 }
 private static function reserve(array $client,array $proposal): void {
  $key='bulk_quota_'.$client['id'];
  $now=time();
  $quota=array_filter(Store::get($key)??[],static fn(array $entry): bool=>$entry['time']>$now-HOUR_IN_SECONDS);
  if(isset($quota[$proposal['id']]))return;
  $count=$proposal['before']['count'];
  $limit=self::limits($client)['per_hour'];
  if(array_sum(array_column($quota,'count'))+$count>$limit)throw new ConnectorError('Bulk hourly cap is '.$limit.' items per connection.');
  $quota[$proposal['id']]=['time'=>$now,'count'=>$count];
  Store::put($key,'bulk_quota',$quota);
 }
 private static function schedule(string $id): void {
  if(!wp_next_scheduled(self::HOOK,[$id])&&wp_schedule_single_event(time()+5,self::HOOK,[$id],true)!==true&&!wp_next_scheduled(self::HOOK,[$id]))throw new ConnectorError('Could not schedule bulk job. Try resuming the existing job.');
 }
 public static function start(array $client,array $proposal): array {
  $id=$proposal['id'];
  $key='job_'.$id;
  $job=Store::get($key);
  if(!$job){
   self::reserve($client,$proposal);
   $before=$proposal['before'];
   $targets=[];
   foreach(array_merge($before['eligible'],$before['skipped']) as $row)$targets[$row['id']]=array_intersect_key($row,['id'=>true,'reason'=>true,'revision'=>true,'before'=>true,'after'=>true]);
   $ids=array_column(array_merge($before['eligible'],$before['skipped']),'id');
   sort($ids,$proposal['operation']==='users_delete'?SORT_NUMERIC:SORT_REGULAR);
   $targets=array_map(static fn($id)=>$targets[$id],$ids);
   $job=['id'=>$id,'kind'=>'bulk','operation'=>$before['operation']??$proposal['operation'],'reversible'=>$before['reversible'],'client_id'=>$client['id'],'owner_id'=>$client['user_id'],'credential_hash'=>$client['hash'],'permissions_revision'=>$proposal['permissions_revision'],'approval_grant'=>$proposal['approval_grant']??null,'oauth_access_id'=>$client['_oauth_access_id']??null,'state'=>'queued','created'=>time(),'expires'=>min(time()+self::MAX_AGE,$client['expires']),'targets'=>array_values($targets),'batch_hash'=>$before['batch_hash'],'filter'=>$proposal['arguments']['filter']??null,'total'=>$before['count'],'processed'=>0,'inflight'=>null,'result'=>['done'=>[],'skipped'=>[],'failed'=>[]]];
   Store::audit($client['id'],'bulk.queued',$id);
   Store::put($key,'job',$job,true);
  }
  // The persisted job can be recovered even when scheduling is unavailable.
  try{self::schedule($id);}
  catch(ConnectorError $e){$job['error']=$e->getMessage();Store::put($key,'job',$job);}
  return ['job_id'=>$id,'state'=>$job['state'],'total'=>$job['total'],'reversible'=>$job['reversible']];
 }
 private static function authorize(array $job,?array $presented=null): array {
  if(get_option('nsc_disabled',false)||$job['expires']<=time())throw new ConnectorError('Bulk job expired or NexPilot is disabled.');
  $identity=['id'=>$job['client_id'],'hash'=>$job['credential_hash'],'user_id'=>$job['owner_id']];
  $oauth=$presented['_oauth_access_id']??$job['oauth_access_id'];
  $client=$oauth?OAuth::reauthorize($identity+['_oauth_access_id'=>$oauth]):Store::reauthorize($identity);
  if($client['id']!==$job['client_id']||($client['permissions_revision']??'')!==$job['permissions_revision']||!empty($client['draft_only']))throw new ConnectorError('Bulk job permissions changed.');
  Policy::capability_binding($job,$client);
  $scope=self::scope($job['operation']);
  Policy::require_scope($client,$scope);
  if($scope==='maintenance')Policy::maintenance($client);
  if(in_array($job['operation'],['users_delete','users_update'],true)&&$job['filter']!==null)Policy::require_scope($client,'accounts_read');
  return $client;
 }
 public static function resume(array $client,string $id): array {
  return Store::locked(static function()use($client,$id){
   $job=Store::get('job_'.$id);
   if(!$job||($job['kind']??null)!=='bulk'||$job['client_id']!==$client['id'])throw new ConnectorError('Bulk job not found.');
   if($job['state']==='done')return self::progress($job);
   self::authorize($job,$client);
   $job['oauth_access_id']=$client['_oauth_access_id']??null;
   $job['state']='queued';
   unset($job['error']);
   Store::put('job_'.$id,'job',$job);
   self::schedule($id);
   return self::progress($job);
  });
 }
 public static function tick(string $id): void {
  if(!preg_match('/^[a-f0-9]{32}$/D',$id))return;
  $key='job_'.$id;
  $job=Store::get($key);
  if(!$job||($job['kind']??null)!=='bulk'||!in_array($job['state'],['queued','running'],true))return;
  // Queue the next tick before taking the lock, so a lock conflict or killed worker can recover.
  self::schedule($id);
  try{Store::locked(static function()use($id,$key){
   $job=Store::get($key);
   if(!$job||!in_array($job['state'],['queued','running'],true))return;
   $previous=get_current_user_id();
   try{
    $client=self::authorize($job);
    wp_set_current_user($client['user_id']);
    $quotaKey='bulk_quota_'.$job['client_id'];
    $quota=Store::get($quotaKey)??[];
    if(isset($quota[$id])){
     $quota[$id]['time']=time();
     Store::put($quotaKey,'bulk_quota',$quota);
    }
    for($i=0;$i<self::CHUNK&&$job['processed']<$job['total'];$i++){
     $client=self::authorize($job);
     self::step($job,$client);
    }
    if($job['processed']===$job['total']){
     Store::audit($job['client_id'],'bulk.completed',$id);
     $job['state']='done';
     Store::put($key,'job',$job);
    }
   }catch(ConnectorError $e){
    $job=Store::get($key);
    if($job&&$job['state']!=='done'){
     $job['state']='paused';$job['error']=$e->getMessage();
     Store::put($key,'job',$job);
    }
   }finally{wp_set_current_user($previous);}
  });}catch(ConnectorError $e){
   // The next tick is already queued, including when the shared mutex is busy.
  }
 }
 private static function step(array &$job,array $client): void {
  $target=$job['targets'][$job['processed']];
  $id=$target['id'];$key='job_'.$job['id'];
  $reference=$job['id'].':'.(is_int($id)?$id:substr(hash('sha256',$id),0,24));
  $state='skipped';
  $reason=$target['reason']??null;
  $result=[];
  $op=$job['operation'];
  if($job['inflight']===$id){
   $state='failed';
   $reason='Interrupted during this item. It was not retried; inspect the object before any new attempt.';
  }elseif($reason===null){
   if($op==='users_delete'){
    $current=Resources::account_delete_item($client,$id);
    $reason=$current['reason']??null;
    $revision=$current['revision']??'';
   }else{
    try{
     $current=match($op){
      'plugins_apply'=>PluginBatch::current($id,$job['reversible']),
      'cache_purge'=>CacheBatch::current($id),
      default=>BulkChanges::values($op,$id),
     };
     $revision=$current===null?'':Policy::fingerprint(array_intersect_key($current,$target['before']));
    }catch(ConnectorError $e){$reason=$e->getMessage();$revision='';}
   }
   if($reason===null&&!hash_equals($target['revision'],$revision))$reason='Object changed after approval.';
   if($reason===null){
    Store::audit($job['client_id'],'bulk.item.started',$reference);
    $job['state']='running';$job['inflight']=$id;
    Store::put($key,'job',$job);
    try{
     if($op==='users_delete'){
      require_once ABSPATH.'wp-admin/includes/user.php';
      // Reassign authored content to the connection owner.
      $ok=wp_delete_user($id,$client['user_id']);
     }elseif($op==='plugins_apply'){
      if($job['reversible'])$result=PluginBatch::update($id,$target,$job);
      else PluginBatch::rollback($id,$target,$job);
      $ok=true;
     }elseif($op==='cache_purge'){
      $ok=CacheBatch::apply($id);
     }else{
      $ok=BulkChanges::apply($op,$id,$target['after']);
      if($ok&&$job['reversible']){
       $after=BulkChanges::values($op,$id);
       $ok=$after!==null;
       if($ok)$result=['before'=>$target['before'],'after'=>array_intersect_key($after,$target['before'])];
      }
     }
     $state=$ok?'done':'failed';
     $reason=$ok?'Operation completed.':'WordPress did not confirm the operation.';
    }catch(ConnectorError $e){$state='failed';$reason=$e->getMessage();}
    catch(\Throwable $e){$state='failed';$reason='Operation outcome is uncertain. Inspect before retrying.';}
   }
  }
  Store::audit($job['client_id'],'bulk.item.'.$state,$reference);
  $job['result'][$state][]=['id'=>$id,'reason'=>$reason]+$result;
  $job['processed']++;
  $job['inflight']=null;
  $job['state']='running';
  Store::put($key,'job',$job);
 }
 public static function progress(array $job): array {
  return array_intersect_key($job,array_flip(['id','operation','state','created','expires','processed','total','result','error','batch_hash']))+['counts'=>array_map('count',$job['result']),'reversible'=>$job['reversible'],'revert_id'=>$job['state']==='done'&&$job['reversible']&&$job['result']['done']?$job['id']:null];
 }
}
