<?php
namespace Nexdev\SiteConnector;
/** Conditional adapters: never invent data when a commercial dependency is absent. */
final class Integrations {
 public static function forms(array $a): array {
  if(!function_exists('wpforms'))throw new ConnectorError('WPForms is not installed/active.');
  $action=$a['action'];
  if($action==='list'){
   $enhanced=array_diff_key($a,['action'=>true,'page'=>true]);
   if(!$enhanced)return array_map(static fn($p)=>['id'=>$p->ID,'title'=>$p->post_title],get_posts(['post_type'=>'wpforms','post_status'=>'any','posts_per_page'=>50,'paged'=>$a['page']??1]));
   $page=min(10000,$a['page']??1);$limit=min(100,$a['per_page']??20);
   $fields=Tools::fields_selection($a['fields']??null,['id','title','status','modified'],['id','title','status','modified']);
   $sort=self::sort($a,['id'=>'ID','title'=>'title','modified'=>'modified','date'=>'date'],'date');
   $query=new \WP_Query(['post_type'=>'wpforms','post_status'=>'any','posts_per_page'=>$limit,'paged'=>$page,'s'=>self::search($a)]+$sort);
   $items=array_map(static fn($p)=>array_intersect_key(['id'=>$p->ID,'title'=>$p->post_title,'status'=>$p->post_status,'modified'=>$p->post_modified_gmt],$fields),$query->posts);
   return Tools::pagination(['per_page'=>$limit],$items,(int)$query->found_posts,$page,$limit);
  }
  if($action==='get'){$p=get_post(Policy::id($a['id']??null));if(!$p||$p->post_type!=='wpforms')throw new ConnectorError('Form not found.');return ['id'=>$p->ID,'title'=>$p->post_title,'configuration'=>json_decode($p->post_content,true)];}
  global $wpdb;$table=$wpdb->prefix.'wpforms_entries';
  if($wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s',$wpdb->esc_like($table)))!==$table)throw new ConnectorError('Local WPForms entry storage unavailable. WPForms Lite may not store entries locally.');
  $columns=$wpdb->get_col($wpdb->prepare('SHOW COLUMNS FROM %i',$table),0);
  if(array_diff(['entry_id','form_id','fields'],$columns))throw new ConnectorError('Unsupported WPForms entry schema.');
  if(!in_array($action,['entries','entry','stats','search'],true))throw new ValidationError('Unsupported WPForms action.');
  $form=isset($a['form_id'])?Policy::id($a['form_id']):0;
  $entry=$action==='entry'?Policy::id($a['id']??null):0;
  $search='%'.$wpdb->esc_like(self::search($a)).'%';
  $page=min(10000,$a['page']??1);
  $enhanced=$action!=='entry'&&array_intersect_key($a,array_fill_keys(['orderby','order','fields','per_page'],true));
  $limit=$enhanced?min(100,$a['per_page']??20):50;
  $where=$wpdb->prepare('FROM %i WHERE (%d=0 OR form_id=%d) AND (%d=0 OR entry_id=%d) AND (%d=0 OR fields LIKE %s)',$table,$form,$form,$entry,$entry,isset($a['search'])?1:0,$search);
  if($action==='stats'||$enhanced){
   $total=(int)$wpdb->get_var('SELECT COUNT(*) '.$where);
   if($wpdb->last_error)throw new ConnectorError('WPForms count query failed.');
   if($action==='stats')return ['count'=>$total];
  }
  $keys=['id'=>'entry_id','form_id'=>'form_id','date'=>'date'];
  $keys=array_intersect($keys,$columns);
  $sort=self::sort($enhanced?$a:[],$keys,'id');
  $order=$sort['order'];
  $orderSql=$wpdb->prepare(' ORDER BY %i '.$order.', entry_id '.$order.' LIMIT %d OFFSET %d',$sort['orderby'],$limit,($page-1)*$limit);
  $rows=$wpdb->get_results('SELECT * '.$where.$orderSql,ARRAY_A);
  if($wpdb->last_error)throw new ConnectorError('WPForms query failed.');
  $rows=Resources::redact($rows);
  if(!$enhanced)return $rows;
  $selected=Tools::fields_selection($a['fields']??null,$columns,$columns);
  return Tools::pagination(['per_page'=>$limit],array_map(static fn(array $row)=>array_intersect_key($row,$selected),$rows),$total,$page,$limit);
 }
 private static function search(array $a): string {
  $value=$a['search']??'';
  if(strlen($value)>200)throw new ValidationError('Integration search is limited to 200 bytes.');
  return $value;
 }
 private static function sort(array $a,array $choices,string $default): array {
  $key=$a['orderby']??$default;$direction=strtoupper($a['order']??'DESC');
  if(!isset($choices[$key])||!in_array($direction,['ASC','DESC'],true))throw new ValidationError('Unsupported integration ordering.');
  return ['orderby'=>$choices[$key],'order'=>$direction];
 }
 public static function commerce(array $a): array {
  if(!function_exists('wc_get_product'))throw new ConnectorError('WooCommerce is inactive.');
  $kind=$a['kind'];
  if(in_array($kind,['bundle','composite'],true)){
   if(!class_exists($kind==='bundle'?'WC_Product_Bundle':'WC_Product_Composite'))throw new ConnectorError('Required commercial WooCommerce extension is inactive.');
   $enhanced=!isset($a['id'])&&array_intersect_key($a,array_fill_keys(['search','orderby','order','fields','per_page','category_id'],true));
   $columns=['id','type','name','data','components','scenarios','items'];
   $fields=$enhanced?Tools::fields_selection($a['fields']??null,$columns,$columns):array_fill_keys($columns,true);
   if($enhanced){
    $page=min(10000,$a['page']??1);$limit=min(100,$a['per_page']??20);
    $sort=self::sort($a,['id'=>'id','name'=>'title','date'=>'date','modified'=>'modified'],'date');
    $params=['type'=>$kind,'search'=>self::search($a),'page'=>$page,'per_page'=>$limit,'orderby'=>$sort['orderby'],'order'=>strtolower($sort['order'])];
    if(isset($a['category_id']))$params['category']=Policy::id($a['category_id']);
    $result=Resources::product_collection($params);
    $products=array_map('wc_get_product',array_column($result['items'],'id'));
   }else{$products=isset($a['id'])?[wc_get_product(Policy::id($a['id']))]:wc_get_products(['type'=>$kind,'limit'=>25,'page'=>$a['page']??1]);}
   $out=[];
   foreach($products as $p){
    if(!$p||!$p->is_type($kind))continue;
    $data=['id'=>$p->get_id(),'type'=>$kind];
    if($enhanced&&isset($fields['name']))$data['name']=$p->get_name();
    if(isset($fields['data']))$data['data']=$p->get_data();
    if(isset($fields['components'])&&$kind==='composite'&&is_callable([$p,'get_composite_data']))$data['components']=$p->get_composite_data();
    if(isset($fields['scenarios'])&&$kind==='composite'&&is_callable([$p,'get_scenario_data']))$data['scenarios']=$p->get_scenario_data();
    if(isset($fields['items'])&&$kind==='bundle'&&is_callable([$p,'get_bundled_items'])){
     $data['items']=[];
     foreach($p->get_bundled_items() as $key=>$item)$data['items'][]=['id'=>$key,'product_id'=>is_callable([$item,'get_product_id'])?$item->get_product_id():null,'data'=>is_callable([$item,'get_data'])?$item->get_data():null];
    }
    $out[]=array_intersect_key($data,$fields);
   }
   $out=Resources::redact($out);
   return $enhanced?Tools::pagination(['per_page'=>$limit],$out,$result['total'],$page,$limit):$out;
  }
  if($kind!=='minmax')throw new ValidationError('Unknown integration.');
  if(!class_exists('WC_Min_Max_Quantities')&&!defined('WC_MIN_MAX_QUANTITIES_VERSION'))throw new ConnectorError('Min/Max Quantities extension is inactive.');
  // Return explicit stored values; do not claim effective/inherited rules without the installed version's resolver.
  if(isset($a['id']))$meta=get_post_meta(Policy::id($a['id']));
  elseif(isset($a['category_id']))$meta=get_term_meta(Policy::id($a['category_id']));
  else {global $wpdb;$rows=$wpdb->get_results($wpdb->prepare("SELECT option_name,option_value FROM {$wpdb->options} WHERE option_name LIKE %s OR option_name LIKE %s OR option_name LIKE %s LIMIT 100",'%'.$wpdb->esc_like('min_max').'%', $wpdb->esc_like('woocommerce_minimum').'%', $wpdb->esc_like('woocommerce_maximum').'%'),ARRAY_A);$meta=array_column($rows,'option_value','option_name');}
  $effective=null;$resolved=null;
  if(isset($a['id'])){
   $product=wc_get_product($a['id']);
   if($product){if(class_exists('WC_Min_Max_Quantities_Quantity_Rules'))$resolved=(new \WC_Min_Max_Quantities_Quantity_Rules($product))->get();$html=woocommerce_quantity_input([],$product,false);$parser=new \WP_HTML_Tag_Processor($html);while($parser->next_tag(['tag_name'=>'INPUT'])){if($parser->get_attribute('name')==='quantity'){$effective=['min'=>$parser->get_attribute('min'),'max'=>$parser->get_attribute('max'),'step'=>$parser->get_attribute('step')];break;}}}
  }
  return ['resolved_product_rules'=>$resolved,'classic_quantity_input'=>$effective,'stored_rules'=>array_filter($meta,static fn($k)=>preg_match('/min|max|group_of|quantity/i',$k),ARRAY_FILTER_USE_KEY),'interpretation'=>'Resolved product rules use the installed extension resolver when available, including category/variation inheritance. Classic quantity controls are produced by active WooCommerce filters and may include stock limits. Cart/order checkout validation is context-dependent; stored rules are included separately.'];
 }
}
