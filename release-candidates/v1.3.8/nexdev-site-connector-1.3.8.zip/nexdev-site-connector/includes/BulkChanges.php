<?php
namespace Nexdev\SiteConnector;

/** Field-bounded bulk adapters. Each adapter owns its selection and before/after semantics. */
final class BulkChanges {
 private const SPECS=[
  'plugins_apply'=>['maintenance',true,['update_available','status','search']],
  'cache_purge'=>['content',false,['urls','all']],
  'users_update'=>['maintenance',true,['registered_after','registered_before','email_glob','role','has_orders','has_name','search']],
  'products_import'=>['commerce',true,[]],
  'posts_update_status'=>['content',true,['type','status','search','modified_after','modified_before']],
  'media_bulk_update'=>['content',true,['empty_alt','search']],
  'products_update'=>['commerce',true,['category','stock_status','type','status','search','modified_after']],
  'orders_update_status'=>['commerce',false,['status','after','before','payment_method','search']],
  'coupons_delete'=>['commerce',false,['expired_before','search']],
 ];
 public static function specs(): array {return self::SPECS;}
 public static function validate(string $op,array $a): void {
  if($op==='bulk_revert'){
   Policy::fields($a,['revert_id','expected_count','batch_hash'],['revert_id']);
   if(!is_string($a['revert_id'])||!preg_match('/^[a-f0-9]{32}$/D',$a['revert_id']))throw new ValidationError('Invalid revert ID.');
   return;
  }
  if($op==='products_import'){
   Policy::fields($a,['ids','csv','expected_count','batch_hash'],['ids','csv']);
   self::csv($a['csv']);
   return;
  }
  $keys=['ids','filter','expected_count','batch_hash'];
  $noFields=in_array($op,['coupons_delete','plugins_apply','cache_purge'],true);
  $required=$noFields?[]:['fields'];
  Policy::fields($a,array_merge($keys,$required),$required);
  if($noFields)return;
  if(!is_array($a['fields'])||!$a['fields'])throw new ValidationError('Bulk fields must be a nonempty object.');
  $allowed=match($op){
   'posts_update_status','orders_update_status'=>['status'],
   'media_bulk_update'=>['alt_text'],
   'users_update'=>['first_name','last_name','display_name','role'],
   'products_update'=>['regular_price','stock_quantity','stock_status','status','price_percent'],
  };
  Policy::fields($a['fields'],$allowed);
  foreach($a['fields'] as $key=>$value){
   $valid=match($key){
    'status'=>is_string($value)&&($op==='orders_update_status'?(function_exists('wc_get_order_statuses')&&isset(wc_get_order_statuses()['wc-'.$value])):in_array($value,['draft','pending','private','publish'],true)),
    'role'=>is_string($value)&&in_array($value,['subscriber','customer'],true)&&wp_roles()->is_role($value),
    'first_name','last_name','display_name'=>is_string($value)&&strlen($value)<=100&&sanitize_text_field($value)===$value&&($key!=='display_name'||$value!==''),
    'alt_text'=>is_string($value)&&strlen($value)<=500&&sanitize_text_field($value)===$value,
    'regular_price'=>is_string($value)&&preg_match('/^\d{1,9}(?:\.\d{1,6})?$/D',$value),
    'stock_quantity'=>is_int($value)&&$value>=0&&$value<=100000000,
    'stock_status'=>in_array($value,['instock','outofstock','onbackorder'],true),
    'price_percent'=>(is_int($value)||is_float($value))&&is_finite((float)$value)&&$value>=-100&&$value<=1000,
   };
   if(!$valid)throw new ValidationError('Invalid bulk field '.$key.'.');
  }
  if(isset($a['fields']['regular_price'],$a['fields']['price_percent']))throw new ValidationError('Set a price or a percentage, not both.');
 }
 public static function select(array $client,string $op,array $a): array {
  $cap=Bulk::limits($client)['per_batch'];
  if(array_key_exists('ids',$a)===array_key_exists('filter',$a))throw new ValidationError('Supply exactly one of ids or filter.');
  if(array_key_exists('ids',$a)){
   $ids=$a['ids'];
   if(!is_array($ids)||!array_is_list($ids)||!$ids)throw new ValidationError('Select at least one exact ID.');
   foreach($ids as $id)Policy::id($id);
  }else{
   $filter=$a['filter'];
   if(!is_array($filter)||!$filter)throw new ValidationError('Bulk filters must be a nonempty object.');
   Policy::fields($filter,self::SPECS[$op][2]);
   $ids=self::filtered_ids($client,$op,$filter,$cap);
  }
  if(count($ids)>$cap)throw new ValidationError('Bulk cap is '.$cap.' items per batch.');
  if(count(array_unique($ids))!==count($ids))throw new ConnectorError('Bulk targets are duplicated or changed during selection.');
  sort($ids,SORT_NUMERIC);
  return $ids;
 }
 private static function filtered_ids(array $client,string $op,array $filter,int $cap): array {
  if(in_array($op,['posts_update_status','products_update','orders_update_status','users_update'],true)){
   $tool=match($op){'posts_update_status'=>'content_list','products_update'=>'products_list','orders_update_status'=>'orders_list','users_update'=>'users_query'};
   if($op==='posts_update_status'&&!isset($filter['type']))throw new ValidationError('Select post or page as the bulk content type.');
   $items=[];$page=1;
   do{
    $result=Tools::call($client,$tool,$filter+['page'=>$page,'per_page'=>min(100,$cap),'fields'=>'id','orderby'=>'id','order'=>'asc']);
    if($result['total']>$cap)throw new ValidationError('Bulk cap is '.$cap.' items per batch.');
    $items=array_merge($items,array_column($result['items'],'id'));
    $page=$result['next'];
   }while($page!==null);
   if(count($items)!==$result['total'])throw new ConnectorError('Bulk targets changed. Run the dry run again.');
   return $items;
  }
  $items=[];$page=1;
  do{
   $result=self::collection($op,$filter+['page'=>$page,'per_page'=>min(100,$cap),'fields'=>'id','orderby'=>'id','order'=>'asc']);
   if($result['total']>$cap)throw new ValidationError('Bulk cap is '.$cap.' items per batch.');
   $items=array_merge($items,array_column($result['items'],'id'));
   $page=$result['next'];
  }while($page!==null);
  if(count($items)!==$result['total'])throw new ConnectorError('Bulk targets changed. Run the dry run again.');
  return $items;
 }
 public static function collection(string $op,array $args): array {
  $media=$op==='media_bulk_update';
  $columns=$media?['id','title','alt_text','mime_type','modified']:['id','code','expires','status','modified'];
  Policy::fields($args,array_merge(['search','page','per_page','fields','orderby','order'],$media?['empty_alt']:['expired_before']));
  foreach(['search','fields','orderby','order'] as $key)if(array_key_exists($key,$args)&&!is_string($args[$key]))throw new ValidationError('Invalid collection argument.');
  $fields=Tools::fields_selection($args['fields']??null,$columns,$columns);
  $page=min(10000,Policy::id($args['page']??1));$limit=min(100,Policy::id($args['per_page']??20));
  $sort=$args['orderby']??'id';$direction=strtoupper($args['order']??'ASC');
  $ordering=['id'=>'ID','title'=>'title','modified'=>'modified','date'=>'date'];
  if(!isset($ordering[$sort])||!in_array($direction,['ASC','DESC'],true))throw new ValidationError('Unsupported collection ordering.');
  $params=['posts_per_page'=>$limit,'paged'=>$page,'orderby'=>[$ordering[$sort]=>$direction,'ID'=>$direction]];
  if(isset($args['search'])){
   if(strlen($args['search'])>200)throw new ValidationError('Search must be text up to 200 bytes.');
   $params['s']=$args['search'];
  }
  if($media){
   $params+=['post_type'=>'attachment','post_status'=>'inherit'];
   if(array_key_exists('empty_alt',$args)){
    if($args['empty_alt']!==true)throw new ValidationError('empty_alt must be true.');
    $params['post_mime_type']='image';
    $params['meta_query']=['relation'=>'OR',['key'=>'_wp_attachment_image_alt','compare'=>'NOT EXISTS'],['key'=>'_wp_attachment_image_alt','value'=>'']];
   }
  }else{
   $params+=['post_type'=>'shop_coupon','post_status'=>['publish','draft','pending','private']];
   if(array_key_exists('expired_before',$args)){
    $date=$args['expired_before'];
    if(!is_string($date)||!preg_match('/^(\d{4})-(\d{2})-(\d{2})$/D',$date,$parts)||!checkdate((int)$parts[2],(int)$parts[3],(int)$parts[1]))throw new ValidationError('Expiry date must use YYYY-MM-DD.');
    $params['meta_query']=[['key'=>'date_expires','value'=>[1,min(time()-1,strtotime($date.'T00:00:00Z')-1)],'compare'=>'BETWEEN','type'=>'NUMERIC']];
   }
  }
  $query=new \WP_Query($params);
  $items=[];
  foreach($query->posts as $post){
   $row=['id'=>$post->ID,'modified'=>$post->post_modified_gmt];
   if($media){
    $row+=['title'=>$post->post_title,'mime_type'=>$post->post_mime_type];
    if(isset($fields['alt_text']))$row['alt_text']=(string)get_post_meta($post->ID,'_wp_attachment_image_alt',true);
   }else{
    $row+=['code'=>$post->post_title,'status'=>$post->post_status];
    if(isset($fields['expires']))$row['expires']=(int)get_post_meta($post->ID,'date_expires',true)?:null;
   }
   $items[]=array_intersect_key($row,$fields);
  }
  return Tools::pagination(['per_page'=>$limit],$items,(int)$query->found_posts,$page,$limit);
 }
 public static function csv(mixed $input): array {
  if(!is_string($input)||$input===''||strlen($input)>65536||str_contains($input,"\0"))throw new ValidationError('CSV must be text up to 64 KiB.');
  $stream=fopen('php://memory','w+');
  fwrite($stream,$input);rewind($stream);
  try{
   $header=fgetcsv($stream,0,',','"','');
   $allowed=['id','regular_price','stock_quantity','stock_status','status','price_percent'];
   if(!$header||$header[0]!=='id'||count($header)<2||count(array_unique($header))!==count($header)||array_diff($header,$allowed))throw new ValidationError('CSV must start with id and supported product field columns.');
   $rows=[];
   while(($row=fgetcsv($stream,0,',','"',''))!==false){
    if($row===[null])continue;
    if(count($row)!==count($header)||!preg_match('/^[1-9][0-9]{0,17}$/D',$row[0]))throw new ValidationError('Invalid product CSV row.');
    $id=(int)$row[0];
    if(isset($rows[$id]))throw new ValidationError('Duplicate product ID in CSV.');
    $fields=array_filter(array_combine(array_slice($header,1),array_slice($row,1)),static fn($value)=>$value!=='');
    foreach(['stock_quantity','price_percent'] as $key)if(isset($fields[$key])){
     if(!preg_match($key==='stock_quantity'?'/^\d{1,9}$/D':'/^-?\d{1,4}(?:\.\d{1,6})?$/D',$fields[$key]))throw new ValidationError('Invalid numeric CSV field.');
     $fields[$key]=$key==='stock_quantity'?(int)$fields[$key]:(float)$fields[$key];
    }
    self::validate('products_update',['fields'=>$fields]);
    $rows[$id]=$fields;
    if(count($rows)>Bulk::MAX_ITEMS)throw new ValidationError('CSV exceeds the maximum batch size.');
   }
   if(!$rows)throw new ValidationError('CSV must include product rows.');
   return $rows;
  }finally{fclose($stream);}
 }
 public static function target(string $op,int $id,array $fields): array {
  if($op==='users_update'&&isset($fields['role'])){
   $user=get_user_by('id',$id);
   if(!$user||count($user->roles)!==1||!in_array(reset($user->roles),['subscriber','customer'],true)||!current_user_can('promote_user',$id))return ['id'=>$id,'reason'=>'Only subscriber and customer roles can be changed.'];
  }
  $current=self::values($op,$id);
  if($current===null)return ['id'=>$id,'reason'=>'Object unavailable or outside this operation.'];
  $before=array_intersect_key($current,$fields);
  $after=$fields;
  if(isset($fields['price_percent'])){
   if($current['regular_price']==='')return ['id'=>$id,'reason'=>'Product has no regular price.'];
   $before['regular_price']=$current['regular_price'];
   $after['regular_price']=wc_format_decimal((float)$current['regular_price']*(1+$fields['price_percent']/100),wc_get_price_decimals());
   unset($after['price_percent']);
  }
  if($op==='coupons_delete')$before=$current;
  if($op==='products_update'&&array_key_exists('stock_quantity',$fields)){
   if($current['stock_quantity']===null)return ['id'=>$id,'reason'=>'Product does not manage stock.'];
   $before['stock_status']=$current['stock_status'];
  }
  if(isset($after['status'])&&$after['status']==='publish'){
   $type=get_post_type_object(get_post_type($id));
   if(!$type||!current_user_can($type->cap->publish_posts))return ['id'=>$id,'reason'=>'WordPress does not permit publishing this object.'];
  }
  return ['id'=>$id,'before'=>$before,'after'=>$after,'revision'=>Policy::fingerprint($before)];
 }
 public static function values(string $op,int $id): ?array {
  if($op==='users_update'){
   $actor=['user_id'=>get_current_user_id()];
   $user=Resources::account_delete_item($actor,$id);
   if(isset($user['reason'])||!current_user_can('edit_user',$id))return null;
   return ['first_name'=>$user['first_name'],'last_name'=>$user['last_name'],'display_name'=>$user['name'],'role'=>count($user['roles'])===1?reset($user['roles']):null];
  }
  if($op==='orders_update_status'){
   $order=function_exists('wc_get_order')?wc_get_order($id):null;
   return $order&&$order->get_type()==='shop_order'&&current_user_can('edit_shop_orders')?['status'=>$order->get_status()]:null;
  }
  clean_post_cache($id);
  $post=get_post($id);
  if(!$post||!current_user_can($op==='coupons_delete'?'delete_post':'edit_post',$id))return null;
  return match($op){
   'posts_update_status'=>in_array($post->post_type,['post','page'],true)&&!in_array($post->post_status,['trash','auto-draft'],true)?['status'=>$post->post_status]:null,
   'media_bulk_update'=>$post->post_type==='attachment'&&wp_attachment_is_image($id)?['alt_text'=>(string)get_post_meta($id,'_wp_attachment_image_alt',true)]:null,
   'products_update'=>self::product_values($post),
   'coupons_delete'=>$post->post_type==='shop_coupon'?['status'=>$post->post_status,'modified'=>$post->post_modified_gmt,'expires'=>get_post_meta($id,'date_expires',true)]:null,
  };
 }
 private static function product_values(\WP_Post $post): ?array {
  $product=$post->post_type==='product'&&function_exists('wc_get_product')?wc_get_product($post->ID):null;
  if(!$product||!$product->is_type('simple')||!in_array($product->get_status(),['draft','pending','private','publish'],true))return null;
  return ['regular_price'=>$product->get_regular_price('edit'),'stock_quantity'=>$product->get_stock_quantity('edit'),'stock_status'=>$product->get_stock_status('edit'),'status'=>$product->get_status('edit')];
 }
 public static function apply(string $op,int $id,array $fields): bool {
  if(($fields['status']??null)==='publish'&&$op!=='orders_update_status'){
   $type=get_post_type_object(get_post_type($id));
   if(!$type||!current_user_can($type->cap->publish_posts))return false;
  }
  switch($op){
   case 'users_update':
    if(isset($fields['role'])&&(!in_array($fields['role'],['subscriber','customer'],true)||!current_user_can('promote_user',$id)))return false;
    return wp_update_user(['ID'=>$id]+wp_slash($fields))===$id;
   case 'posts_update_status':return wp_update_post(['ID'=>$id,'post_status'=>$fields['status']],true)===$id;
   case 'media_bulk_update':
    update_post_meta($id,'_wp_attachment_image_alt',wp_slash($fields['alt_text']));
    return get_post_meta($id,'_wp_attachment_image_alt',true)===$fields['alt_text'];
   case 'products_update':
    $product=wc_get_product($id);
    if(isset($fields['stock_quantity'])&&!$product->managing_stock())return false;
    foreach($fields as $field=>$value)$product->{'set_'.$field}($value);
    return $product->save()===$id;
   case 'orders_update_status':return wc_get_order($id)->update_status($fields['status']);
   case 'coupons_delete':return (bool)wp_delete_post($id,true);
  }
  return false;
 }
}
