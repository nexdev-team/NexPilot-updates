<?php
namespace Nexdev\SiteConnector;
/**
 * Read-only connection test. Explains why an MCP client cannot connect: transport, REST routing, firewall in front of the
 * site, stripped Authorization header, OAuth discovery. It changes nothing and never prints or stores a credential.
 * Analyzers take plain arrays so they can be tested without WordPress; only probe() and run() touch the site.
 */
final class Diagnostics {
 private const HTACCESS="# BEGIN NexPilot Authorization\n<IfModule mod_rewrite.c>\nRewriteEngine On\nRewriteRule .* - [E=HTTP_AUTHORIZATION:%{HTTP:Authorization}]\n</IfModule>\n# END NexPilot Authorization";

 public static function register_routes(): void {
  // Public on purpose: it only reports whether an Authorization header reached PHP and never returns the header value.
  register_rest_route('nexdev-connector/v1','/selftest',['methods'=>['POST'],'permission_callback'=>'__return_true','callback'=>[self::class,'selftest']]);
 }
 public static function selftest(\WP_REST_Request $request): \WP_REST_Response {
  $source=Server::authorization($request)[1];
  $response=new \WP_REST_Response(['authorization_seen'=>$source!=='none','source'=>$source],200);
  $response->header('Cache-Control','no-store');
  return $response;
 }

 private static function row(string $id,string $status,string $label,string $message,string $remedy=''): array {return ['id'=>$id,'status'=>$status,'label'=>$label,'message'=>$message,'remedy'=>$remedy];}
 private static function json(array $probe): ?array {$d=json_decode((string)($probe['body']??''),true);return is_array($d)?$d:null;}

 public static function check_transport(bool $ssl,bool $local_http): array {
  if($ssl)return self::row('transport','ok','HTTPS','The site is served over HTTPS.');
  if($local_http)return self::row('transport','info','HTTPS','Plain HTTP is allowed because NSC_ALLOW_LOCAL_HTTP is set on a local environment.');
  return self::row('transport','fail','HTTPS','NexPilot refuses plain HTTP, so every client is denied.','Serve the site over HTTPS (check Settings > General: both addresses must start with https://) and make sure the server tells WordPress the request is secure behind any proxy or CDN.');
 }
 public static function check_environment(bool $sodium,bool $pretty_permalinks,string $php): array {
  if(!$sodium)return self::row('environment','fail','PHP environment','PHP Sodium is missing; credentials cannot be sealed.','Enable the sodium PHP extension in your hosting panel.');
  if(!$pretty_permalinks)return self::row('environment','warn','PHP environment','Permalinks are set to Plain, so the connector URL uses ?rest_route= and some clients reject it.','Open Settings > Permalinks, choose any option other than Plain and save.');
  return self::row('environment','ok','PHP environment','PHP '.$php.' with Sodium and pretty permalinks.');
 }
 public static function check_connections(array $clients,bool $oauth,bool $disabled,int $now): array {
  if($disabled)return self::row('connections','fail','Connections','The connector is disabled; all connections are refused.','Use "Enable connector" on this page.');
  $active=array_values(array_filter($clients,static fn($c)=>empty($c['revoked'])&&($c['expires']??0)>$now));
  $soon=array_values(array_filter($active,static fn($c)=>$c['expires']-$now<7*86400));
  if(!$active&&!$oauth)return self::row('connections','warn','Connections','No active connection and OAuth is off, so no client can connect yet.','Create a connection (token or bridge), or enable OAuth and add the MCP URL in your client.');
  if($soon)return self::row('connections','warn','Connections',count($active).' active connection(s); '.count($soon).' expire within 7 days.','Rotate those credentials, or reconnect the client.');
  return self::row('connections','ok','Connections',count($active).' active connection(s)'.($oauth?'; OAuth is on.':'; OAuth is off.'));
 }
 public static function check_endpoint(array $probe): array {
  if(isset($probe['error']))return self::row('endpoint','warn','MCP endpoint','This server could not call its own endpoint ('.$probe['error'].'). That does not prove external clients fail.','Some hosts block calls from the server to its own public address. Test again from your MCP client.');
  $status=(int)$probe['status'];$data=self::json($probe);
  if(in_array($status,[401,403],true)&&($data['code']??'')==='nsc_access_denied'){
   $challenge=(string)($probe['headers']['www-authenticate']??'');
   if($status===401&&!str_contains($challenge,'resource_metadata'))return self::row('endpoint','warn','MCP endpoint','NexPilot answered, but the 401 carries no OAuth resource_metadata challenge, so OAuth clients cannot discover how to sign in.','A caching layer or proxy may be stripping response headers. Exclude /wp-json/nexdev-connector/ from caching and header rewriting.');
   return self::row('endpoint','ok','MCP endpoint','NexPilot answered HTTP '.$status.' without credentials, as expected.');
  }
  if($status===404)return self::row('endpoint','fail','MCP endpoint','The REST route was not found (HTTP 404).','Save Settings > Permalinks once, and check that no security plugin disables the REST API for visitors.');
  if(in_array($status,[401,403,406,429,503],true))return self::row('endpoint','fail','MCP endpoint','Something before NexPilot answered HTTP '.$status.' (not NexPilot\'s own response). A firewall, CDN rule, host protection or security plugin is blocking the request.','Allow /wp-json/nexdev-connector/ in that layer. For Cloudflare, check Security > Events for this path; for a security plugin, check its block log.');
  return self::row('endpoint','warn','MCP endpoint','Unexpected response HTTP '.$status.' without credentials.','Open the endpoint in a browser; it should return JSON with code nsc_access_denied.');
 }
 public static function check_header(array $probe): array {
  if(isset($probe['error']))return self::row('header','warn','Authorization header','The header test could not run ('.$probe['error'].').','Test again from your MCP client.');
  $data=self::json($probe);
  if((int)$probe['status']!==200||!is_array($data)||!array_key_exists('authorization_seen',$data))return self::row('header','warn','Authorization header','The header test route answered HTTP '.(int)$probe['status'].'.','A firewall or cache may be answering before WordPress. Allow /wp-json/nexdev-connector/selftest.');
  if(!$data['authorization_seen'])return self::row('header','fail','Authorization header','The web server does not pass the Authorization header to PHP, so every credential looks missing.','Add this above the "# BEGIN WordPress" block in .htaccess (Apache or LiteSpeed), or ask your host to enable CGIPassAuth / pass Authorization to PHP:\n\n'.self::HTACCESS);
  $source=(string)($data['source']??'');
  return self::row('header','ok','Authorization header',$source==='request'?'The Authorization header reaches PHP.':'The Authorization header reaches PHP through a fallback ('.$source.'); NexPilot reads it.');
 }
 public static function check_metadata(string $label,array $probe,string $issuer,string $home_host,bool $server_document): array {
  $id=$server_document?'oauth_server':'oauth_resource';
  if(isset($probe['error']))return self::row($id,'warn',$label,'Could not be requested ('.$probe['error'].').','Test again from your MCP client.');
  $data=self::json($probe);
  if((int)$probe['status']!==200||!is_array($data))return self::row($id,'fail',$label,'Expected JSON but received HTTP '.(int)$probe['status'].'.','Make sure OAuth is enabled here and that nothing in front of WordPress rewrites /.well-known/ requests.');
  if(!$server_document){
   if(!in_array($issuer,(array)($data['authorization_servers']??[]),true))return self::row($id,'fail',$label,'The resource metadata does not point at this site\'s authorization server.','Check that Home and Site addresses in Settings > General match the address clients use.');
   return self::row($id,'ok',$label,'Protected-resource metadata is published.');
  }
  if(($data['issuer']??'')!==$issuer)return self::row($id,'fail',$label,'The issuer in the metadata does not match '.$issuer.'.','Check that Home and Site addresses in Settings > General match the address clients use.');
  foreach(['authorization_endpoint','token_endpoint','registration_endpoint'] as $key){
   $host=wp_parse_url((string)($data[$key]??''),PHP_URL_HOST);
   if(!is_string($host)||strcasecmp($host,$home_host)!==0)return self::row($id,'fail',$label,'The '.$key.' is missing or points at another host.','Check Home and Site addresses in Settings > General.');
  }
  return self::row($id,'ok',$label,'Authorization-server metadata is published and consistent.');
 }
 public static function check_root_metadata(array $probe,string $issuer): array {
  $data=isset($probe['error'])?null:self::json($probe);
  if(!is_array($data)||(int)$probe['status']!==200||($data['issuer']??'')==='')return self::row('oauth_root','info','Site-root OAuth metadata','No other plugin publishes OAuth metadata at the site root.');
  if($data['issuer']===$issuer)return self::row('oauth_root','ok','Site-root OAuth metadata','Root metadata is NexPilot\'s.');
  return self::row('oauth_root','info','Site-root OAuth metadata','Another plugin publishes OAuth metadata at the site root (issuer '.$data['issuer'].'). NexPilot does not use it.','Clients should follow the resource_metadata challenge to NexPilot\'s own issuer. If a client signs in to the other plugin instead of NexPilot, connect it with the local bridge and a credential from this page.');
 }
 public static function check_edge(array $headers): array {
  $server=strtolower((string)($headers['server']??''));
  if(isset($headers['cf-ray'])||str_contains($server,'cloudflare'))return self::row('edge','info','CDN / firewall','The site is behind Cloudflare. Requests from AI clients arrive from outside your network.','If a client is refused while this test passes, check Cloudflare > Security > Events for /wp-json/nexdev-connector/ and allow it (a Managed Challenge cannot be solved by an automated client).');
  return self::row('edge','ok','CDN / firewall','No CDN or firewall fingerprint was seen on the response.');
 }

 /** @return array{status:int,headers:array<string,string>,body:string}|array{error:string} */
 private static function probe(string $method,string $url,array $headers=[],string $body=''): array {
  $response=wp_remote_request($url,['method'=>$method,'timeout'=>8,'redirection'=>0,'sslverify'=>wp_get_environment_type()!=='local','headers'=>$headers,'body'=>$body,'user-agent'=>'NexPilot-ConnectionTest']);
  if(is_wp_error($response))return ['error'=>$response->get_error_code()];
  $raw=wp_remote_retrieve_headers($response);
  $normalized=array_change_key_case(method_exists($raw,'getAll')?$raw->getAll():(array)$raw);
  return ['status'=>(int)wp_remote_retrieve_response_code($response),'headers'=>array_map(static fn($v)=>is_array($v)?implode(', ',$v):(string)$v,$normalized),'body'=>substr((string)wp_remote_retrieve_body($response),0,65536)];
 }
 /** @return list<array{id:string,status:string,label:string,message:string,remedy:string}> */
 public static function run(): array {
  $rows=[];$home=wp_parse_url(home_url(),PHP_URL_HOST);$home=is_string($home)?$home:'';
  $local=defined('NSC_ALLOW_LOCAL_HTTP')&&NSC_ALLOW_LOCAL_HTTP&&wp_get_environment_type()==='local';
  $rows[]=self::check_transport(is_ssl(),$local);
  $rows[]=self::check_environment(function_exists('sodium_crypto_secretbox'),!str_contains(rest_url(),'rest_route='),PHP_VERSION);
  $rows[]=self::check_connections(Store::all('client'),OAuth::enabled(),(bool)get_option('nsc_disabled',false),time());
  $endpoint=self::probe('POST',rest_url('nexdev-connector/v1/mcp'),['Content-Type'=>'application/json'],'{}');
  $rows[]=self::check_endpoint($endpoint);
  $rows[]=self::check_edge(isset($endpoint['headers'])?$endpoint['headers']:[]);
  $rows[]=self::check_header(self::probe('POST',rest_url('nexdev-connector/v1/selftest'),['Authorization'=>'Bearer '.str_repeat('0',64)]));
  if(OAuth::enabled()){
   $rows[]=self::check_metadata('OAuth resource metadata',self::probe('GET',rest_url('nexdev-connector/v1/oauth/resource')),OAuth::issuer(),$home,false);
   $path=(string)wp_parse_url(OAuth::issuer(),PHP_URL_PATH);
   $rows[]=self::check_metadata('OAuth server metadata',self::probe('GET',home_url('/.well-known/oauth-authorization-server'.$path)),OAuth::issuer(),$home,true);
   $rows[]=self::check_root_metadata(self::probe('GET',home_url('/.well-known/oauth-authorization-server')),OAuth::issuer());
  }
  return $rows;
 }
 public static function render(array $rows): string {
  $labels=['ok'=>'OK','info'=>'INFO','warn'=>'WARN','fail'=>'FAIL'];
  $count=array_count_values(array_column($rows,'status'));
  $html='<h1>Connection test</h1><p>Read-only. Nothing was changed and no credential is shown. '.esc_html((string)($count['fail']??0)).' failed, '.esc_html((string)($count['warn']??0)).' warnings.</p><table class="widefat striped"><thead><tr><th>Result</th><th>Check</th><th>Details</th></tr></thead><tbody>';
  foreach($rows as $r){
   $html.='<tr><td><strong>'.esc_html($labels[$r['status']]??$r['status']).'</strong></td><td>'.esc_html($r['label']).'</td><td>'.esc_html($r['message']);
   if($r['remedy']!=='')$html.='<br><em style="white-space:pre-wrap">'.esc_html($r['remedy']).'</em>';
   $html.='</td></tr>';
  }
  return $html.'</tbody></table><p><a href="'.esc_url(admin_url('tools.php?page=nsc')).'">Back to connector</a></p>';
 }
}
