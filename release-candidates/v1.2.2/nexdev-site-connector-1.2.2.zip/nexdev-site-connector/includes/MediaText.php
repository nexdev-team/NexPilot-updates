<?php
namespace Nexdev\SiteConnector;

/** Local-only, bounded page extraction. Binaries are configured by the server owner, never the AI. */
final class MediaText {
 public static function capabilities(): array {
  $out=[];foreach(['pdftotext'=>'NSC_PDFTOTEXT_BIN','pdftoppm'=>'NSC_PDFTOPPM_BIN','tesseract'=>'NSC_TESSERACT_BIN'] as $key=>$constant)$out[$key]=defined($constant)&&is_string(constant($constant))&&is_file(constant($constant))&&is_executable(constant($constant));
  $out['processes']=function_exists('proc_open');return $out;
 }
 private static function run(string $constant,array $args): string {
  if(!function_exists('proc_open')||!defined($constant)||!is_string(constant($constant))||!is_file(constant($constant))||!is_executable(constant($constant)))throw new ConnectorError('Local extraction binary unavailable. Ask the server administrator to configure PDF/OCR capabilities.');
  $pipes=[];$proc=proc_open(array_merge([constant($constant)],$args),[0=>['pipe','r'],1=>['pipe','w'],2=>['pipe','w']],$pipes,null,['PATH'=>'/usr/bin:/bin','OMP_THREAD_LIMIT'=>'1']);
  if(!is_resource($proc))throw new ConnectorError('Cannot start extraction.');
  fclose($pipes[0]);stream_set_blocking($pipes[1],false);stream_set_blocking($pipes[2],false);$out='';$bytes=0;$start=microtime(true);$exit=-1;
  try{
   do{
    $out.=stream_get_contents($pipes[1]);$bytes+=strlen(stream_get_contents($pipes[2]));
    if(strlen($out)>131072||$bytes>131072||microtime(true)-$start>15)throw new ConnectorError('Extraction exceeded time/output limit.');
    $status=proc_get_status($proc);if(!$status['running']){$exit=$status['exitcode'];break;}usleep(10000);
   }while(true);
   $out.=stream_get_contents($pipes[1]);if($exit!==0||strlen($out)>131072||!preg_match('//u',$out))throw new ConnectorError('Local extraction failed; check file format, page number and language installation.');
   return trim($out);
  }finally{if(proc_get_status($proc)['running'])proc_terminate($proc,9);fclose($pipes[1]);fclose($pipes[2]);proc_close($proc);}
 }
 public static function read(array $a): array {
  Policy::id($a['id']);$page=$a['page']??1;$mode=$a['mode']??'auto';$lang=$a['language']??'eng';
  if(!is_int($page)||$page<1||$page>1000||!in_array($mode,['auto','ocr'],true)||!preg_match('/^[a-z]{3}(\+[a-z]{3}){0,3}$/D',$lang))throw new ValidationError('Invalid extraction page, mode or language.');
  $p=get_post($a['id']);if(!$p||$p->post_type!=='attachment'||!current_user_can('edit_post',$a['id']))throw new ConnectorError('Attachment unavailable.');
  $path=realpath(get_attached_file($a['id'])?:'');$root=realpath(wp_upload_dir()['basedir']);
  if(!$path||!$root||!str_starts_with($path,$root.'/')||!is_file($path)||filesize($path)>16*1024*1024)throw new ConnectorError('Read only local attachments in uploads, up to 16 MiB.');
  $mime=get_post_mime_type($a['id']);if(!in_array($mime,['application/pdf','image/png','image/jpeg','image/webp'],true))throw new ConnectorError('Supported types: PDF, PNG, JPEG, WebP.');
  $hash=hash_file('sha256',$path);$caps=self::capabilities();
  if($mime==='application/pdf'&&$mode==='auto'&&$caps['pdftotext']){
   $text=self::run('NSC_PDFTOTEXT_BIN',['-f',(string)$page,'-l',(string)$page,'-enc','UTF-8','-nopgbrk',$path,'-']);
   if($text!=='')return ['id'=>$a['id'],'page'=>$page,'method'=>'pdf_text','text'=>$text,'revision'=>$hash,'untrusted_content'=>true];
  }
  if(!$caps['tesseract']||!$caps['processes']||($mime==='application/pdf'&&!$caps['pdftoppm']))return ['id'=>$a['id'],'page'=>$page,'text'=>'','status'=>'ocr_unavailable','capabilities'=>$caps,'revision'=>$hash];
  $temp=wp_tempnam('nexpilot-ocr');if(!$temp)throw new ConnectorError('Cannot create extraction workspace.');
  try{
   $image=$path;
   if($mime==='application/pdf'){
    self::run('NSC_PDFTOPPM_BIN',['-f',(string)$page,'-l',(string)$page,'-singlefile','-scale-to','2000','-png',$path,$temp]);$image=$temp.'.png';
   }else{
    $size=@getimagesize($path);if(!$size||$size[0]*$size[1]>16000000)throw new ConnectorError('OCR image exceeds 16 megapixels.');
   }
   $text=self::run('NSC_TESSERACT_BIN',[$image,'stdout','-l',$lang]);
   return ['id'=>$a['id'],'page'=>$page,'method'=>'ocr','text'=>$text,'revision'=>$hash,'untrusted_content'=>true,'warning'=>'OCR may contain errors; verify against the original.'];
  }finally{foreach([$temp,$temp.'.png'] as $file)if(is_file($file))wp_delete_file($file);}
 }
}
