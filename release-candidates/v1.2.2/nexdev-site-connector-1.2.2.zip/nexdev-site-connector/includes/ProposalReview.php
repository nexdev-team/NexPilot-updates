<?php
namespace Nexdev\SiteConnector;

final class ProposalReview {
 /** Display text only. WordPress diff escapes both sides; proposed HTML is never rendered. */
 public static function render(array $p): string {
  if (($p['operation']??'')!=='content_update') return '<p>Review the structured arguments and previous state below. A text comparison is unavailable for this operation.</p>';
  $out='';$before=$p['before'];
  foreach(($p['arguments']['fields']??[]) as $field=>$value) {
   if (!is_string($value) || !is_string($before[$field]??null)) continue;
   if (strlen($value)+strlen($before[$field])>131072) { $out.='<p>Large field: use the structured review below.</p>';continue; }
   $diff=wp_text_diff($before[$field],$value,['title_left'=>'Before','title_right'=>'Proposed','show_split_view'=>true]);
   if ($diff) $out.='<h3>'.esc_html($field).'</h3>'.$diff;
  }
  return $out?:'<p>No text changes to compare. Review the structured arguments below.</p>';
 }
}
