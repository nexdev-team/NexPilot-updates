// Private, user-run setup helper. No network calls or credential values in command arguments/logs.
import {readFile,writeFile,mkdir,chmod,lstat,rename,unlink,rmdir} from 'node:fs/promises';
import path from 'node:path';
import {homedir} from 'node:os';
import {spawnSync} from 'node:child_process';
import {randomBytes} from 'node:crypto';
import {createInterface} from 'node:readline';
import {Writable} from 'node:stream';
import {fileURLToPath,pathToFileURL} from 'node:url';
const here=path.dirname(fileURLToPath(import.meta.url));
async function optionalFile(p){try{const s=await lstat(p);if(!s.isFile()||s.isSymbolicLink())throw Error('Configuration must be a regular file.');return await readFile(p,'utf8');}catch(e){if(e.code==='ENOENT')return '';throw e;}}
export async function installConnection(profile,credential,options={}){
 if(Number(process.versions.node.split('.')[0])<20)throw Error('Node.js 20 or newer is required.');
 if(!profile||!/^[A-Za-z0-9_-]{1,40}$/.test(profile.name)||typeof profile.readOnly!=='boolean')throw Error('Invalid connection profile.');
 const endpoint=new URL(profile.endpoint);
 const local=profile.allowLocalHttp===true&&['127.0.0.1','localhost','[::1]'].includes(endpoint.hostname);
 if(endpoint.username||endpoint.password||endpoint.search||endpoint.hash||(endpoint.protocol!=='https:'&&!(local&&endpoint.protocol==='http:')))throw Error('An HTTPS site endpoint is required.');
 if(!/^[a-f0-9]{32}\.[a-f0-9]{64}$/.test(credential))throw Error('Invalid connection key format.');
 const config=options.configPath||path.join(process.env.CODEX_HOME||path.join(homedir(),'.codex'),'config.toml');
 const original=await optionalFile(config);
 const header=new RegExp('^\\[mcp_servers\\.(?:"'+profile.name+'"|'+profile.name+')(?:\\]|\\.)','m');
 if(header.test(original))throw Error('That server name already exists. Choose another name before downloading the package.');
 const base=options.installRoot||path.join(homedir(),'.nexpilot');
 const destination=path.join(base,profile.name);
 await mkdir(base,{recursive:true,mode:0o700});
 if((await lstat(base)).isSymbolicLink())throw Error('The private connection folder must not be a symbolic link.');
 await chmod(base,0o700);
 try{await lstat(destination);throw Error('A local connection folder already exists. Choose a new server name.');}catch(e){if(e.code!=='ENOENT')throw e;}
 await mkdir(destination,{mode:0o700});
 let configWritten=false,changed='';
 const bridge=path.join(destination,'nexdev-mcp.mjs'),token=path.join(destination,'connection.token'),backup=path.join(destination,'codex-config.before.toml');
 try{
  await writeFile(bridge,await readFile(path.join(here,'nexdev-mcp.mjs')),{mode:0o600,flag:'wx'});
  await writeFile(token,credential,{mode:0o600,flag:'wx'});
  await writeFile(backup,original,{mode:0o600,flag:'wx'});
  const env={NSC_ENDPOINT:endpoint.href,NSC_TOKEN_FILE:token,NSC_READ_ONLY:profile.readOnly?'1':'0'};
  if(local)env.NSC_ALLOW_LOCAL_HTTP='1';
  const lines=['[mcp_servers.'+profile.name+']','command = "node"','args = ['+JSON.stringify(bridge)+']','','[mcp_servers.'+profile.name+'.env]'];
  for(const [k,v] of Object.entries(env))lines.push(k+' = '+JSON.stringify(v));
  changed=original+(original.endsWith('\n')?'':'\n')+'\n'+lines.join('\n')+'\n';
  await mkdir(path.dirname(config),{recursive:true,mode:0o700});
  if(await optionalFile(config)!==original)throw Error('Configuration changed during setup. Retry after other edits finish.');
  const temp=config+'.nexpilot-'+randomBytes(8).toString('hex');
  try{await writeFile(temp,changed,{mode:0o600,flag:'wx'});await rename(temp,config);configWritten=true;}finally{try{await unlink(temp);}catch(e){if(e.code!=='ENOENT')throw e;}}
  const valid=options.validate?await options.validate(profile.name):spawnSync('codex',['mcp','get',profile.name,'--json'],{stdio:['ignore','pipe','pipe']}).status===0;
  if(!valid)throw Error('Codex could not validate the connection. Ensure the Codex CLI is installed.');
  await chmod(config,0o600);
  return {name:profile.name,credentialFile:token,existingConfigurationPreserved:true};
 }catch(e){
  if(configWritten){if(await optionalFile(config)!==changed)throw Error('Configuration changed during setup; local backup retained for review.');await writeFile(config,original,{mode:0o600});}
  for(const p of [bridge,token,backup])try{await unlink(p);}catch{}
  try{await rmdir(destination);}catch{}
  throw e;
 }
}
async function hiddenKey(){
 process.stdout.write('Paste your NexPilot connection key (hidden), then press Enter: ');
 const muted=new Writable({write(chunk,encoding,done){done();}});
 const rl=createInterface({input:process.stdin,output:muted,terminal:Boolean(process.stdin.isTTY)});
 try{return (await new Promise(resolve=>rl.question('',resolve))).trim();}finally{rl.close();process.stdout.write('\n');}
}
if(process.argv[1]&&import.meta.url===pathToFileURL(path.resolve(process.argv[1])).href){
 try{
  const profile=JSON.parse(await readFile(path.join(here,'profile.json'),'utf8'));
  const result=await installConnection(profile,await hiddenKey());
  console.log('NexPilot connection saved: '+result.name+'. Open Codex Settings → MCP servers and restart this server, then ask for site info.');
 }catch(e){console.error(e.message);process.exitCode=1;}
}
