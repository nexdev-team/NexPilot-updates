(function () {
 'use strict';
 var cfg = window.nscSetup || {};
 var root = document.getElementById('nsc-setup');
 if (!root || !cfg.endpoint) { return; }

 var TOOLS = [
  { id: 'claude-code', name: 'Claude Code', methods: ['stdio', 'http'] },
  { id: 'claude-desktop', name: 'Claude Desktop', methods: ['stdio', 'oauth'] },
  { id: 'codex', name: 'Codex (CLI and desktop)', methods: ['oauth', 'stdio'] },
  { id: 'cursor', name: 'Cursor', methods: ['stdio'] },
  { id: 'vscode', name: 'VS Code (Copilot)', methods: ['stdio'] },
  { id: 'windsurf', name: 'Windsurf', methods: ['stdio'] },
  { id: 'other', name: 'Other MCP client', methods: ['stdio', 'http'] }
 ];
 var METHODS = {
  oauth: { name: 'Sign in through your browser', desc: 'Add the site URL in your AI app and approve its access in WordPress. No bridge download or token file.' },
  stdio: { name: 'Connection key', desc: 'Generate a separate key for this AI tool, then download its setup package or use manual configuration.' },
  http: { name: 'Direct HTTP with a token', desc: 'For tools that can send an Authorization header. The token is stored in that tool’s own settings.' }
 };

 var state = { tool: null, method: null };
 var $ = function (id) { return document.getElementById(id); };
 var el = function (tag, attrs, text) {
  var n = document.createElement(tag);
  if (attrs) { Object.keys(attrs).forEach(function (k) { n.setAttribute(k, attrs[k]); }); }
  if (text !== undefined) { n.textContent = text; }
  return n;
 };

 if (!cfg.https) { $('nsc-https-warning').hidden = false; }
 $('nsc-f-name').value = (cfg.siteSlug || 'my-site').slice(0, 40);

 function name() { return ($('nsc-f-name').value || 'my-site').replace(/[^A-Za-z0-9_-]+/g, '-').replace(/^-+|-+$/g, '') || 'my-site'; }
 function bridge() { return $('nsc-f-bridge').value || '/absolute/path/to/nexdev-mcp.mjs'; }
 function tokenFile() { return $('nsc-f-token').value || '/absolute/path/to/' + name() + '.token'; }
 var deviceModeChosen = false;
 function readOnly() { return $('nsc-f-readonly').checked; }
 function syncDeviceAccess() {
  var writesRequested = !!document.querySelector('#nsc-token-create input[name="scopes[]"]:checked');
  if (!deviceModeChosen) $('nsc-f-readonly').checked = !writesRequested;
  var notice = $('nsc-device-access');
  if (notice) notice.textContent = readOnly() ? 'This device will only read. Proposal and execution tools are hidden, even if the connection has edit permissions.' : 'This device can request approved changes within its WordPress permissions. The approval mode selected in WordPress applies. Full access preauthorizes changes for its selected duration; maintenance permissions still apply.';
 }
 function envObj() {
  var e = { NSC_ENDPOINT: cfg.endpoint, NSC_TOKEN_FILE: tokenFile(), NSC_READ_ONLY: readOnly() ? '1' : '0' };
  return e;
 }
 function jsonConfig(rootKey, extra) {
  var server = Object.assign({}, extra || {}, { command: 'node', args: [bridge()], env: envObj() });
  var out = {}; out[rootKey] = {}; out[rootKey][name()] = server;
  return JSON.stringify(out, null, 2);
 }
 function tomlConfig() {
  var e = envObj();
  var lines = ['[mcp_servers.' + name() + ']', 'command = "node"', 'args = [' + JSON.stringify(bridge()) + ']', '', '[mcp_servers.' + name() + '.env]'];
  Object.keys(e).forEach(function (k) { lines.push(k + ' = ' + JSON.stringify(e[k])); });
  return lines.join('\n');
 }
 function shellQuote(value) { return "'" + String(value).replace(/'/g, String.fromCharCode(39, 92, 39, 39)) + "'"; }
 function claudeCodeCmd() {
  var e = envObj();
  var parts = ['claude mcp add ' + name()];
  Object.keys(e).forEach(function (k) { parts.push('  --env ' + shellQuote(k + '=' + e[k])); });
  parts.push('  -- node ' + shellQuote(bridge()));
  return parts.join(' \\\n');
 }
 function tokenCmd() {
  return 'umask 077\nmkdir -p ~/.nexpilot\nread -rs NEXPILOT_TOKEN && printf \'%s\' "$NEXPILOT_TOKEN" > ~/.nexpilot/' + name() + '.token && unset NEXPILOT_TOKEN\n# paste the token when asked, then press Enter (it is not shown or saved in shell history)';
 }

 function snippet(title, text) {
  var box = el('div', { 'class': 'nsc-snippet' });
  box.appendChild(el('h4', null, title));
  var pre = el('pre'); pre.appendChild(el('code', null, text)); box.appendChild(pre);
  var btn = el('button', { type: 'button', 'class': 'button button-small nsc-copy' }, 'Copy');
  btn.addEventListener('click', function () {
   try { navigator.clipboard.writeText(text).then(function () { btn.textContent = 'Copied'; setTimeout(function () { btn.textContent = 'Copy'; }, 1500); }); } catch (e) { btn.textContent = 'Select and copy'; }
  });
  box.appendChild(btn);
  return box;
 }

 function copyText(text, button) {
  if (!navigator.clipboard) { button.textContent = 'Copy is unavailable in this browser'; return; }
  navigator.clipboard.writeText(text).then(function () { button.textContent = 'Copied'; }, function () { button.textContent = 'Copy was blocked by the browser'; });
 }
 function quickConnect(t, m) {
  var wrap = $('nsc-quick-connect'); wrap.textContent = '';
  var supported = m === 'stdio' && (t.id === 'claude-desktop' || t.id === 'codex');
  var manual = $('nsc-manual-connect');
  manual.querySelector('summary').textContent = 'Manual configuration for ' + t.name;
  if (manual.dataset.mode !== t.id + ':' + m) { manual.open = !supported && m !== 'oauth'; manual.dataset.mode = t.id + ':' + m; }
  if (m === 'oauth') {
   var copy = el('button', {type:'button', 'class':'button button-primary nsc-connect-primary'}, 'Copy site URL');
   copy.addEventListener('click', function () { copyText(cfg.endpoint, copy); }); wrap.appendChild(copy);
   wrap.appendChild(el('p', null, 'Add this URL in your AI app, sign in through your browser and approve the connection in WordPress.'));
   if (!cfg.oauth) { var settings = el('a', {href:cfg.oauthSettingsUrl || '?page=nsc&tab=settings'}, 'Enable browser sign-in first'); wrap.appendChild(settings); }
  } else if (supported) {
   var downloadLabel = t.id === 'claude-desktop' ? 'Download .mcpb bundle' : 'Download Codex setup package';
   var download = el('button', {type:'button', 'class':'button button-primary nsc-connect-primary', 'aria-label':downloadLabel});
   download.appendChild(el('strong', null, downloadLabel));
   download.appendChild(el('small', null, t.id === 'claude-desktop' ? 'Ready to open with Claude Desktop' : 'Setup for macOS and Windows'));
   var status = el('p', {'role':'status'});
   download.addEventListener('click', async function () {
    download.disabled = true; status.textContent = 'Preparing your site connection…';
    try {
     if (!window.nscBundles) { throw new Error('Package setup is unavailable. Reload this page.'); }
     var result = await window.nscBundles.make(cfg, {tool:t.id, name:name(), readOnly:readOnly()});
     var url = URL.createObjectURL(result.blob), link = el('a', {href:url, download:result.filename});
     document.body.appendChild(link); link.click(); link.remove(); setTimeout(function () { URL.revokeObjectURL(url); }, 30000);
     status.textContent = 'Package ready. Open it and paste your separate connection key when the app asks.';
    } catch (error) { status.textContent = error.message || 'Could not prepare this package. Use manual configuration below.'; }
    finally { download.disabled = false; }
   });
   wrap.appendChild(download);
   wrap.appendChild(el('p', null, t.id === 'claude-desktop' ? 'Open with a Claude Desktop version that supports MCPB extensions. Paste the connection key once when prompted.' : 'Extract the package and open install.command on macOS or install.ps1 on Windows. Paste the key once; the helper handles the local files and settings.'));
   wrap.appendChild(el('p', {'class':'description'}, 'The package contains your site address and setup files. Your connection key is entered separately and is not included in the download.'));
   var prompt = el('button', {type:'button', 'class':'button-link'}, 'Copy setup instructions for my AI tool instead');
   prompt.addEventListener('click', function () {
    copyText('Help me install my NexPilot connection for ' + cfg.endpoint + '. I have downloaded the private setup package for ' + t.name + '. Ask me to select the file if you need its location. Keep my connection key in local protected storage and do not ask me to paste it into this chat. After setup, read site_info and health_check only. Do not change site content or open maintenance.', prompt);
   });
   wrap.appendChild(prompt); wrap.appendChild(status);
  }
 }
 function guide() {
  var t = state.tool, m = state.method;
  var steps = $('nsc-steps'), snips = $('nsc-snippets');
  steps.textContent = ''; snips.textContent = '';
  var add = function (html) { steps.appendChild(el('li', null, html)); };
  var addLink = function (before, href, label, after) {
   var li = el('li'); li.appendChild(document.createTextNode(before));
   var a = el('a', { href: href, target: '_blank', rel: 'noopener noreferrer' }, label); li.appendChild(a);
   li.appendChild(document.createTextNode(after || '')); steps.appendChild(li);
  };
  syncDeviceAccess();
  $('nsc-guide').hidden = false; $('nsc-guide-empty').hidden = true;
  $('nsc-f-bridge').closest('label').hidden = (m !== 'stdio');
  $('nsc-f-readonly').closest('label').hidden = (m !== 'stdio');
  $('nsc-f-token').closest('label').hidden = (m === 'oauth');
  if ($('nsc-token-create')) { $('nsc-token-create').hidden = (m === 'oauth'); }

  if (m === 'oauth') {
   if (!cfg.oauth) {
    addLink('First open ', cfg.oauthSettingsUrl || '?page=nsc&tab=settings', 'OAuth connection settings', ' and enable browser sign-in. This allows client registration; each connection still needs your WordPress approval.');
   }
   add(t.id === 'codex' ? 'In Codex open Settings → MCP servers → Add server and choose a remote server.' : 'In your AI app open its remote MCP connection settings and add a custom server.');
   add('Give it the name “' + name() + '”, paste the site URL below, then sign in.');
   snips.appendChild(snippet('Site URL', cfg.endpoint));
   add('In WordPress, review the app and requested access, then approve the connection. A separate credential is created for that app; you do not create or copy a token here.');
   add('Start with Read access. Content changes still need a separate WordPress approval; full maintenance also needs a short administrator-opened window.');
   if (t.id === 'codex') {
    add('If your Codex version uses a terminal for setup, use this command instead:');
    snips.appendChild(snippet('Codex terminal setup', 'codex mcp add ' + name() + ' --url ' + shellQuote(cfg.endpoint)));
   }
   add('If browser sign-in is unavailable in your client, choose Connection key above.');
  } else if (m === 'stdio') {
   add('Install Node.js 20 or newer on the computer where ' + t.name + ' runs.');
   addLink('Download the bridge file ', cfg.bridgeUrl, 'nexdev-mcp.mjs', ' and save it somewhere permanent. Put its full path in “Bridge file path” above.');
   add('Generate a connection key in step 3 for a connection named “' + name() + '” (start with Read only) and copy the token. It is shown only once.');
   add('Save the token in a private file (see the first code box). On Windows, save it in your user folder; the owner-only permission check is skipped there.');
   snips.appendChild(snippet('Save the token (macOS / Linux)', tokenCmd()));
   if (t.id === 'claude-code') {
    add('Run this command in a terminal:');
    snips.appendChild(snippet('Claude Code', claudeCodeCmd()));
   } else if (t.id === 'codex') {
    add('Add this to ~/.codex/config.toml, then restart Codex:');
    snips.appendChild(snippet('Codex config.toml', tomlConfig()));
   } else if (t.id === 'vscode') {
    add('Add this to .vscode/mcp.json in your workspace (or run “MCP: Open User Configuration”), then start the server:');
    snips.appendChild(snippet('VS Code mcp.json', jsonConfig('servers', { type: 'stdio' })));
   } else if (t.id === 'claude-desktop') {
    add('Open Settings > Developer > Edit Config, merge this into claude_desktop_config.json, then restart Claude Desktop:');
    snips.appendChild(snippet('claude_desktop_config.json', jsonConfig('mcpServers')));
   } else if (t.id === 'cursor') {
    add('Add this to ~/.cursor/mcp.json (or .cursor/mcp.json in a project), then restart Cursor:');
    snips.appendChild(snippet('Cursor mcp.json', jsonConfig('mcpServers')));
   } else if (t.id === 'windsurf') {
    add('Add this to ~/.codeium/windsurf/mcp_config.json, then refresh MCP servers in Windsurf:');
    snips.appendChild(snippet('Windsurf mcp_config.json', jsonConfig('mcpServers')));
   } else {
    add('Add this stdio server to your MCP client’s configuration (the file format can differ slightly between apps):');
    snips.appendChild(snippet('Generic MCP stdio configuration', jsonConfig('mcpServers')));
   }
  } else if (m === 'http') {
   add('Generate a connection key in step 3 for a connection named “' + name() + '” and copy the token (shown once).');
   add('Save the token in a private file (first code box). Putting it on a command line stores it in that tool’s settings, so use a connection that is read-only or short-lived.');
   snips.appendChild(snippet('Save the token (macOS / Linux)', tokenCmd()));
   if (t.id === 'claude-code') {
    add('Run this command in a terminal:');
    snips.appendChild(snippet('Claude Code (HTTP)', 'claude mcp add --transport http ' + name() + ' ' + shellQuote(cfg.endpoint) + ' \\\n  --header "Authorization: Bearer $(cat ' + shellQuote(tokenFile()) + ')"'));
   } else {
    add('In your MCP client choose a remote/HTTP server and enter:');
    snips.appendChild(snippet('Remote MCP server', 'URL:    ' + cfg.endpoint + '\nHeader: Authorization: Bearer <your token>'));
   }
  }
  quickConnect(t, m);
  add('Restart the AI tool if needed and ask it: “Use NexPilot to read the site info.” App menus change between versions; if a step differs, check your tool’s MCP documentation.');
 }

 function renderMethods() {
  var wrap = $('nsc-methods'); wrap.textContent = '';
  $('nsc-methods-empty').hidden = !!state.tool;
  if (!state.tool) { return; }
  state.tool.methods.forEach(function (key) {
   var label = el('label', { 'class': 'nsc-method' });
   var input = el('input', { type: 'radio', name: 'nsc-method', value: key });
   if (state.method === key) { input.checked = true; }
   input.addEventListener('change', function () { state.method = key; guide(); });
   label.appendChild(input);
   label.appendChild(el('strong', null, METHODS[key].name));
   label.appendChild(el('small', null, METHODS[key].desc));
   wrap.appendChild(label);
  });
 }

 function renderTools(filter) {
  var wrap = $('nsc-tools'); wrap.textContent = '';
  var q = (filter || '').toLowerCase();
  TOOLS.filter(function (t) { return !q || t.name.toLowerCase().indexOf(q) !== -1; }).forEach(function (t) {
   var b = el('button', { type: 'button', 'class': 'nsc-chip', 'aria-pressed': state.tool && state.tool.id === t.id ? 'true' : 'false' }, t.name);
   b.addEventListener('click', function () {
    state.tool = t; state.method = t.methods[0];
    var clientLabel = $('nsc-client-label');
    if (clientLabel && (!clientLabel.value || clientLabel.value === clientLabel.dataset.suggested)) { clientLabel.value = t.name; clientLabel.dataset.suggested = t.name; }
    renderTools($('nsc-tool-search').value); renderMethods(); guide();
   });
   wrap.appendChild(b);
  });
 }

 $('nsc-show-name').addEventListener('click', function () { $('nsc-manual-connect').open = true; $('nsc-f-name').focus(); });
 var createForm = $('nsc-client-label').closest('form');
 createForm.addEventListener('change', function () {
  syncDeviceAccess();
  if (state.tool && state.method) guide();
 });
 function chooseDeviceMode() { deviceModeChosen = true; syncDeviceAccess(); }
 $('nsc-f-readonly').addEventListener('input', chooseDeviceMode);
 $('nsc-f-readonly').addEventListener('change', chooseDeviceMode);
 syncDeviceAccess();
 createForm.addEventListener('submit', async function (event) {
  if (!window.fetch || !window.FormData) { return; }
  event.preventDefault();
  var button = createForm.querySelector('button[type="submit"], input[type="submit"]');
  var status = $('nsc-create-status'); button.disabled = true; status.textContent = 'Creating your connection…';
  try {
   var response = await fetch(createForm.getAttribute('action'), {method:'POST',credentials:'same-origin',cache:'no-store',redirect:'error',headers:{Accept:'application/json'},body:new FormData(createForm)});
   var data = await response.json();
   if (!response.ok || !data.success || !data.data || !/^[a-f0-9]{32}\.[a-f0-9]{64}$/.test(data.data.token)) { throw new Error('Connection creation was refused.'); }
   $('nsc-created-key-value').value = data.data.token; $('nsc-copy-key').textContent = 'Copy connection key'; $('nsc-created-key').hidden = false;
   syncDeviceAccess();
   if (state.tool && state.method) guide();
   status.textContent = 'Connection created. Expiry: ' + new Date(data.data.expires * 1000).toLocaleString() + '. Copy the key, then open the setup package for your AI tool.';
   if (button.tagName === 'INPUT') { button.value = 'Generate another connection key'; } else { button.textContent = 'Generate another connection key'; }
  } catch (error) { status.textContent = 'Could not create the connection. Check administrator access, the agreement and selected permissions, then retry.'; }
  finally { button.disabled = false; }
 });
 $('nsc-copy-key').addEventListener('click', function () { copyText($('nsc-created-key-value').value, $('nsc-copy-key')); });
 window.addEventListener('pagehide', function () { $('nsc-created-key-value').value = ''; });
 $('nsc-tool-search').addEventListener('input', function (e) { renderTools(e.target.value); });
 ['nsc-f-name', 'nsc-f-bridge', 'nsc-f-token', 'nsc-f-readonly'].forEach(function (id) {
  $(id).addEventListener('input', function () { if (state.tool && state.method) { guide(); } });
  $(id).addEventListener('change', function () { if (state.tool && state.method) { guide(); } });
 });
 renderTools('');
})();
