(function () {
 'use strict';
 var encode=function(s){return new TextEncoder().encode(s);};
 function crc32(bytes){var crc=0xffffffff;for(var i=0;i<bytes.length;i++){crc^=bytes[i];for(var j=0;j<8;j++){crc=(crc>>>1)^((crc&1)?0xedb88320:0);}}return (crc^0xffffffff)>>>0;}
 // ZIP STORE: no dependency, no executable user-supplied member paths, no credentials.
 function zip(files){
  var parts=[],directory=[],offset=0;
  files.forEach(function(file){
   if(!/^[A-Za-z0-9_./-]+$/.test(file.name)||file.name.indexOf('..')!==-1||file.name[0]==='/'){throw new Error('Invalid package path.');}
   var name=encode(file.name),data=encode(file.text),crc=crc32(data),head=new Uint8Array(30),view=new DataView(head.buffer);
   view.setUint32(0,0x04034b50,true);view.setUint16(4,20,true);view.setUint16(6,0x800,true);view.setUint16(12,33,true);view.setUint32(14,crc,true);view.setUint32(18,data.length,true);view.setUint32(22,data.length,true);view.setUint16(26,name.length,true);
   parts.push(head,name,data);
   var central=new Uint8Array(46),c=new DataView(central.buffer);
   c.setUint32(0,0x02014b50,true);c.setUint16(4,0x0314,true);c.setUint16(6,20,true);c.setUint16(8,0x800,true);c.setUint16(14,33,true);c.setUint32(16,crc,true);c.setUint32(20,data.length,true);c.setUint32(24,data.length,true);c.setUint16(28,name.length,true);c.setUint32(38,((file.executable?0o100700:0o100600)<<16)>>>0,true);c.setUint32(42,offset,true);
   directory.push(central,name);offset+=head.length+name.length+data.length;
  });
  var size=directory.reduce(function(n,p){return n+p.length;},0),end=new Uint8Array(22),e=new DataView(end.buffer);
  e.setUint32(0,0x06054b50,true);e.setUint16(8,files.length,true);e.setUint16(10,files.length,true);e.setUint32(12,size,true);e.setUint32(16,offset,true);
  return new Blob(parts.concat(directory,[end]),{type:'application/zip'});
 }
 function profile(cfg,options){
  var endpoint=new URL(cfg.endpoint),local=cfg.allowLocalHttp&&['127.0.0.1','localhost','[::1]'].indexOf(endpoint.hostname)!==-1;
  if(endpoint.username||endpoint.password||endpoint.search||endpoint.hash||(endpoint.protocol!=='https:'&&!(local&&endpoint.protocol==='http:'))){throw new Error('An HTTPS connection is required.');}
  var name=String(options.name||cfg.siteSlug||'my-site').replace(/[^A-Za-z0-9_-]+/g,'-').replace(/^-+|-+$/g,'').slice(0,40)||'my-site';
  return {name:name,endpoint:endpoint.href,readOnly:options.readOnly!==false,allowLocalHttp:!!local};
 }
 async function asset(cfg,url){
  if(new URL(url,location.href).origin!==new URL(cfg.endpoint).origin){throw new Error('The setup file must come from this site.');}
  var response=await fetch(url,{credentials:'same-origin',cache:'no-store',redirect:'error'});
  if(!response.ok){throw new Error('The setup file could not be downloaded.');}
  var text=await response.text();if(text.length>262144){throw new Error('The setup file is too large.');}return text;
 }
 function manifest(cfg,p){
  var env={NSC_ENDPOINT:p.endpoint,NSC_TOKEN:'${user_config.connection_key}',NSC_READ_ONLY:'${user_config.read_only}'};if(p.allowLocalHttp){env.NSC_ALLOW_LOCAL_HTTP='1';}
  var result={manifest_version:'0.3',name:'nexpilot-'+p.name.toLowerCase(),display_name:'NexPilot — '+p.name,version:cfg.version||'1.1.0',description:'A private NexPilot connection to your WordPress site.',author:{name:'Nexdev'},server:{type:'node',entry_point:'server/nexdev-mcp.mjs',mcp_config:{command:'node',args:['${__dirname}/server/nexdev-mcp.mjs'],env:env}},tools_generated:true,license:'GPL-2.0-or-later',compatibility:{platforms:['darwin','win32'],runtimes:{node:'>=20.0.0'}},user_config:{connection_key:{type:'string',title:'NexPilot connection key',description:'Paste the separate connection key generated for this AI tool.',sensitive:true,required:true},read_only:{type:'boolean',title:'Read-only access on this device',description:'When enabled, hides proposal and execution tools even if WordPress grants edit access. Turn off to allow changes under the approval mode selected in WordPress; permissions and access windows still apply. Restart this connection after changing it.',default:p.readOnly}}};
  if(cfg.privacyUrl){result.privacy_policies=[cfg.privacyUrl];}return result;
 }
 async function make(cfg,options){
  var p=profile(cfg,options),bridge=await asset(cfg,cfg.bridgeUrl),files,extension;
  if(options.tool==='claude-desktop'){
   extension='.mcpb';files=[{name:'manifest.json',text:JSON.stringify(manifest(cfg,p),null,2)},{name:'server/nexdev-mcp.mjs',text:bridge},{name:'README.txt',text:'Open this bundle with Claude Desktop. Paste your separate NexPilot connection key once when prompted. Your key is not included in this file. Use a separate connection for each AI tool.\n'}];
  }else if(options.tool==='codex'){
   extension='-codex.zip';files=[{name:'profile.json',text:JSON.stringify(p,null,2)},{name:'nexdev-mcp.mjs',text:bridge},{name:'install.mjs',text:await asset(cfg,cfg.installerUrl)},{name:'install.command',executable:true,text:'#!/bin/sh\nset -eu\nNEXPILOT_SETUP_DIR=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)\nif ! command -v node >/dev/null 2>&1; then echo "Install Node.js 20 or newer first."; exit 1; fi\nnode "$NEXPILOT_SETUP_DIR/install.mjs"\n'},{name:'install.ps1',text:'$ErrorActionPreference = "Stop"\nif (-not (Get-Command node -ErrorAction SilentlyContinue)) { throw "Install Node.js 20 or newer first." }\n& node (Join-Path $PSScriptRoot "install.mjs")\nif ($LASTEXITCODE -ne 0) { throw "NexPilot setup did not complete." }\n'},{name:'README.txt',text:'Extract this private site setup package. On macOS open install.command; on Windows run install.ps1. Paste the separate connection key when asked (input is hidden). Node.js 20+ and the Codex CLI are required. The helper stores the bridge/key in your private .nexpilot folder and adds a new server without replacing existing entries. Restart this server from Codex MCP settings, then ask for site info. No connection key is included in this package.\n'}];
  }else{throw new Error('No install package is available for this tool.');}
  return {blob:zip(files),filename:'nexpilot-'+p.name+extension};
 }
 window.nscBundles={make:make,manifest:manifest,profile:profile,zip:zip};
})();
